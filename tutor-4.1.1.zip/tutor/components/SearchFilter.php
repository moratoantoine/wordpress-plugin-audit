<?php
/**
 * SearchFilter Component Class.
 *
 * Responsible for rendering a search filter component
 * that handles server-side filtering via search param.
 *
 * @package Tutor\Components
 * @author Themeum
 * @link https://themeum.com
 * @since 4.0.0
 */

namespace Tutor\Components;

use Tutor\Components\Constants\Size;
use Tutor\Components\Constants\Color;
use TUTOR\Icon;
use TUTOR\Input;

defined( 'ABSPATH' ) || exit;

/**
 * Class SearchFilter
 *
 * Example Usage:
 * ```php
 * // Minimal search form (uses current URL, param name = 'search')
 * SearchFilter::make()
 *     ->render();
 *
 * // With custom placeholder and input name
 * SearchFilter::make()
 *     ->placeholder( 'Search students...' )
 *     ->input_name( 'student_search' )
 *     ->render();
 *
 * // With explicit action URL and hidden inputs to preserve context
 * SearchFilter::make()
 *     ->action( admin_url( 'admin.php?page=tutor-students' ) )
 *     ->input_name( 'search' )
 *     ->hidden_inputs( array( 'type' => 'enrolled', 'course_id' => $course_id ) )
 *     ->render();
 *
 * // Small-size search field
 * SearchFilter::make()
 *     ->placeholder( 'Search...' )
 *     ->size( Size::SMALL )
 *     ->render();
 *
 * // Large-size search field
 * SearchFilter::make()
 *     ->placeholder( 'Search courses...' )
 *     ->size( Size::LARGE )
 *     ->render();
 *
 * // Custom form ID (useful when multiple search forms exist on the same page)
 * SearchFilter::make()
 *     ->form_id( 'announcement-search-form' )
 *     ->placeholder( 'Search announcements...' )
 *     ->render();
 *
 * // POST method (e.g., for AJAX-backed searches)
 * SearchFilter::make()
 *     ->input_name( 'q' )
 *     ->method( 'POST' )
 *     ->render();
 *
 * // Retrieve HTML without echoing
 * $html = SearchFilter::make()->placeholder( 'Find a course...' )->get();
 * ```
 *
 * @since 4.0.0
 */
class SearchFilter extends BaseComponent {

	/**
	 * Form ID
	 *
	 * @var string
	 */
	protected $form_id = 'tutor-search-filter-form';

	/**
	 * Search Placeholder
	 *
	 * @var string
	 */
	protected $placeholder;

	/**
	 * Form Action URL
	 *
	 * @var string
	 */
	protected $action_url;

	/**
	 * Search Input Name
	 *
	 * @var string
	 */
	protected $input_name = 'search';

	/**
	 * Additional hidden inputs
	 *
	 * @var array
	 */
	protected $hidden_inputs = array();

	/**
	 * Input Size
	 *
	 * @var string
	 */
	protected $size = Size::MEDIUM;

	/**
	 * Form Method
	 *
	 * @var string
	 */
	protected $method = 'GET';


	/**
	 * Set form ID
	 *
	 * @param string $form_id form ID.
	 *
	 * @return self
	 */
	public function form_id( string $form_id ): self {
		$this->form_id = $form_id;
		return $this;
	}

	/**
	 * Set placeholder
	 *
	 * @param string $placeholder placeholder.
	 *
	 * @return self
	 */
	public function placeholder( string $placeholder ): self {
		$this->placeholder = $placeholder;
		return $this;
	}

	/**
	 * Set action URL
	 *
	 * @param string $url action URL.
	 *
	 * @return self
	 */
	public function action( string $url ): self {
		$this->action_url = $url;
		return $this;
	}

	/**
	 * Set input name
	 *
	 * @param string $name input name.
	 *
	 * @return self
	 */
	public function input_name( string $name ): self {
		$this->input_name = $name;
		return $this;
	}

	/**
	 * Add hidden inputs
	 *
	 * @param array $inputs Input array.
	 *
	 * @return self
	 */
	public function hidden_inputs( array $inputs ): self {
		$this->hidden_inputs = array_merge( $this->hidden_inputs, $inputs );
		return $this;
	}

	/**
	 * Set size of the input
	 *
	 * @param string $size size of the input.
	 *
	 * @return self
	 */
	public function size( string $size ): self {
		$this->size = $size;
		return $this;
	}

	/**
	 * Set form method
	 *
	 * @param string $method form method.
	 *
	 * @return self
	 */
	public function method( string $method ): self {
		$this->method = $method;
		return $this;
	}


	/**
	 * Get component content
	 *
	 * @return string
	 */
	public function get(): string {
		$form_id      = $this->form_id;
		$placeholder  = $this->placeholder ?? __( 'Search...', 'tutor' );
		$current_url  = $this->action_url ?? '';
		$input_name   = $this->input_name;
		$search_value = Input::get( $input_name, '' );
		$size         = Size::SMALL === $this->size ? 'tutor-input-sm' : ( Size::LARGE === $this->size ? 'tutor-input-lg' : '' );
		$icon_size    = Size::SMALL === $this->size ? 16 : ( Size::LARGE === $this->size ? 24 : 20 );
		$method       = $this->method;

		if ( empty( $current_url ) ) {
			// Fallback to current URL with preserved query args if not provided.
			global $wp;
			$current_url = add_query_arg( $_GET, home_url( $wp->request ) );
		}

		$clear_url = add_query_arg(
			array_merge(
				$this->hidden_inputs,
				array( 'paged' => 1 )
			),
			remove_query_arg( $input_name, $current_url )
		);

		$clear_action = 'GET' === strtoupper( $method )
			? 'window.location.href = ' . wp_json_encode( $clear_url )
			: 'setValue(' . wp_json_encode( (string) $input_name ) . ', \'\'); $el.closest(\'form\').submit();';

		$this->attributes = array_merge(
			array(
				'action'  => esc_url( $current_url ),
				'method'  => $method,
				'id'      => $form_id,
				'x-data'  => "tutorForm({ id: '" . esc_attr( $form_id ) . "', mode: 'onSubmit' })",
				'x-bind'  => 'getFormBindings()',
				'@submit' => 'handleSubmit((data) => { $el.submit(); })($event)',
			),
			$this->attributes
		);

		ob_start();
		?>
		<form <?php $this->render_attributes(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
			<input type="hidden" name="paged" value="1">

			<?php foreach ( $this->hidden_inputs as $name => $value ) : ?>
				<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>">
			<?php endforeach; ?>

			<div class="tutor-input-field">
				<div class="tutor-input-wrapper">
					<div class="tutor-input-content tutor-input-content-left">
						<?php
						SvgIcon::make()
							->name( Icon::SEARCH_2 )
							->size( $icon_size )
							->color( Color::IDLE )
							->render();
						?>
					</div>
					<input 
						type="search"
						name="<?php echo esc_attr( $input_name ); ?>"
						placeholder="<?php echo esc_attr( $placeholder ); ?>"
						class="tutor-input <?php echo esc_attr( $size ); ?> tutor-input-content-left tutor-input-content-clear"
						x-bind="register(<?php echo esc_attr( wp_json_encode( (string) $input_name ) ); ?>)"
						x-init="$nextTick(() => setValue(<?php echo esc_attr( wp_json_encode( (string) $input_name ) ); ?>, <?php echo esc_attr( wp_json_encode( (string) $search_value ) ); ?>))"
					/>

					<button 
						type="button"
						class="tutor-input-clear-button"
						x-show="values.<?php echo esc_attr( $input_name ); ?> && String(values.<?php echo esc_attr( $input_name ); ?>).length > 0"
						x-cloak
						aria-label="<?php esc_attr_e( 'Clear search', 'tutor' ); ?>"
						@click="<?php echo esc_attr( $clear_action ); ?>"
					>
						<?php SvgIcon::make()->name( Icon::CROSS )->size( 16 )->render(); ?>
					</button>
				</div>
			</div>
		</form>
		<?php
		return ob_get_clean();
	}
}
