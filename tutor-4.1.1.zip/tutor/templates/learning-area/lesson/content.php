<?php
/**
 * Tutor learning area lesson.
 *
 * @package Tutor\Templates
 * @subpackage LearningArea
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 4.0.0
 */

defined( 'ABSPATH' ) || exit;

use TUTOR\Input;
use TUTOR\Lesson;
use Tutor\Models\EnrollmentModel;

$lesson = $lesson ?? null;
if ( ! $lesson || ! is_a( $lesson, 'WP_Post' ) ) {
	return;
}

global $tutor_course_id, $tutor_current_content_id, $tutor_completion_mode, $post;

$tabs_data = Lesson::get_nav_items( $lesson->ID );

$active_tab = Input::get( 'tab', 'overview' );
$valid_tabs = wp_list_pluck( $tabs_data, 'id' );
if ( ! in_array( $active_tab, $valid_tabs, true ) ) {
	$active_tab = $tabs_data[0]['id'] ?? 'overview';
}

$json_data                                 = array();
$json_data['post_id']                      = $tutor_current_content_id;
$json_data['best_watch_time']              = 0;
$json_data['autoload_next_course_content'] = (bool) get_tutor_option( 'autoload_next_course_content' );

$best_watch_time = tutor_utils()->get_lesson_reading_info( $tutor_current_content_id, 0, 'video_best_watched_time' );
if ( $best_watch_time > 0 ) {
	$json_data['best_watch_time'] = $best_watch_time;
}

$video_info = tutor_utils()->get_video_info();
$source_key = is_object( $video_info ) && 'html5' !== $video_info->source ? 'source_' . $video_info->source : null;
$has_source = ( is_object( $video_info ) && $video_info->source_video_id ) || ( isset( $source_key ) ? $video_info->$source_key : null );

$feature_image = get_post_meta( get_the_ID(), '_thumbnail_id', true );
$feature_url   = $feature_image ? wp_get_attachment_url( $feature_image ) : null;

?>
<div class="tutor-lesson-content">
	<?php ob_start(); ?>
	<div 
		x-data="tutorTabs({
			tabs: <?php echo esc_attr( tutor_json_encode( $tabs_data ) ); ?>,
			defaultTab: '<?php echo esc_js( $active_tab ); ?>',
			urlParams: {
				paramName: 'page_tab',
			}
		})"
		class="tutor-lesson-content-tab"
	>
		<!-- Load Lesson Video -->
		<?php if ( $has_source ) : ?>
		<div class="tutor-lesson-video-wrapper tutor-border-b">
			<?php
				$json_data['strict_mode']                     = ( 'strict' === $tutor_completion_mode );
				$json_data['control_video_lesson_completion'] = (bool) tutor_utils()->get_option( 'control_video_lesson_completion', false );
				$json_data['required_percentage']             = (int) tutor_utils()->get_option( 'required_percentage_to_complete_video_lesson', 80 );
				$json_data['video_duration']                  = $video_info->duration_sec ?? 0;
				$json_data['lesson_completed']                = tutor_utils()->is_completed_lesson( $lesson->ID, get_current_user_id() ) !== false;
				$json_data['is_enrolled']                     = EnrollmentModel::is_enrolled( $tutor_course_id, get_current_user_id() ) !== false;
			?>
			<input type="hidden" id="tutor_video_tracking_information" value="<?php echo esc_attr( json_encode( $json_data ) ); ?>">
			<?php echo apply_filters( 'tutor_single_lesson_video', tutor_lesson_video( false ), $video_info, $source_key ); //phpcs:ignore ?>
		</div>
		<?php elseif ( $feature_url ) : ?>
		<div class="tutor-lesson-image-wrapper">
			<img class="tutor-lesson-feature-image" src="<?php echo esc_url( $feature_url ); ?>" alt="<?php echo esc_attr( get_the_title( $lesson->ID ) ); ?>">
		</div>
		<?php endif; ?>

		<?php if ( count( $tabs_data ) > 1 ) : ?>
		<div x-ref="tablist" class="tutor-tabs-nav tutor-px-6 tutor-py-5 tutor-border-b" role="tablist" aria-orientation="horizontal">
			<template x-for="tab in tabs" :key="tab.id">
				<button
					type="button" 
					role="tab" 
					:class='getTabClass(tab)' 
					x-bind:aria-selected="isActive(tab.id)" 
					:disabled="tab.disabled ? true : false" 
					@click="selectTab(tab.id)"
					>
					<span x-data="TutorCore.icon({ name: tab.icon, width: 20, height: 20})"></span>
					<span x-text="tab.label"></span>
				</button>
			</template>

			<?php do_action( 'tutor_lesson_single_after_nav_items', $lesson->ID, $active_tab ); ?>
		</div>
		<?php endif; ?>

		<?php if ( ! empty( $tabs_data ) ) : ?>
		<div class="tutor-tabs-content">
			<?php
			foreach ( $tabs_data as $key => $content ) {
				$is_pro = isset( $content['is_pro'] ) && true === $content['is_pro'];
				tutor_load_template(
					$content['template'],
					array(
						'is_active' => $content['id'] === $active_tab,
						'post'      => $post,
						'course_id' => $tutor_course_id,
						'lesson_id' => $lesson->ID,
					),
					$is_pro
				);
			}
			?>
		</div>
		<?php endif; ?>
	</div>
	<?php
		do_action( 'tutor_lesson/single/before/content' );
		echo apply_filters( 'tutor_learning_area_content', ob_get_clean() ); //phpcs:ignore --already escaped
		tutor_load_template( 'learning-area.lesson.footer' );
	?>
</div>
