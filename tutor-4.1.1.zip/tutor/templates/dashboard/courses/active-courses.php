<?php
/**
 * Active Courses Template
 *
 * @package Tutor\Templates
 * @subpackage Dashboard\Enrolled_Courses
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 1.4.3
 */

defined( 'ABSPATH' ) || exit;

$active_tab = 'courses/active-courses';
require dirname( __DIR__ ) . DIRECTORY_SEPARATOR . 'courses.php';
