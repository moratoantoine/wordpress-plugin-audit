<?php
/**
 * Settings options
 *
 * @package Tutor\Settings
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 2.0.0
 */

namespace Tutor;

defined( 'ABSPATH' ) || exit;

use TUTOR\Icon;
use TUTOR\Input;
use Tutor\Traits\JsonResponse;
use Tutor\Ecommerce\OptionKeys;
use TUTOR\User;

/**
 * Contains all the settings options
 *
 * @since 2.0.0
 */
class Options_V2 {

	use JsonResponse;

	/**
	 * Learning modes.
	 *
	 * @since 4.0.0
	 */
	const LEARNING_MODE_MODERN = 'modern';
	const LEARNING_MODE_KIDS   = 'kids';
	const LEARNING_MODE_LEGACY = 'legacy';

	/**
	 * Default theme.
	 *
	 * @since 4.0.0
	 */
	const DEFAULT_THEME_LIGHT  = 'light';
	const DEFAULT_THEME_DARK   = 'dark';
	const DEFAULT_THEME_SYSTEM = 'system';

	/**
	 * Brand color.
	 *
	 * @since 4.0.0
	 */
	const DEFAULT_BRAND_COLOR = '#3e64de';

	/**
	 * Undocumented variable
	 *
	 * @since 2.0.0
	 *
	 * @var array $options
	 */
	private $options;

	/**
	 * Settings fields
	 *
	 * @since 2.0.0
	 *
	 * @var mixed $setting_fields
	 */
	private $setting_fields;

	/**
	 * Register hooks
	 *
	 * @since 2.0.0
	 *
	 * @param boolean $register_hook should register hook or not.
	 *
	 * @return void
	 */
	public function __construct( $register_hook = true ) {
		if ( ! $register_hook ) {
			return;
		}

		// Saving option.
		add_action( 'tutor_option_save_before', array( $this, 'validate_options' ) );
		add_action( 'wp_ajax_tutor_option_save', array( $this, 'tutor_option_save' ) );
		add_action( 'wp_ajax_tutor_option_default_save', array( $this, 'tutor_option_default_save' ) );
		add_action( 'wp_ajax_tutor_option_search', array( $this, 'tutor_option_search' ) );
		add_action( 'wp_ajax_tutor_export_settings', array( $this, 'tutor_export_settings' ) );
		add_action( 'wp_ajax_tutor_export_single_settings', array( $this, 'tutor_export_single_settings' ) );
		add_action( 'wp_ajax_tutor_delete_single_settings', array( $this, 'tutor_delete_single_settings' ) );
		add_action( 'wp_ajax_tutor_import_settings', array( $this, 'tutor_import_settings' ) );
		add_action( 'wp_ajax_tutor_apply_settings', array( $this, 'tutor_apply_settings' ) );
		add_action( 'wp_ajax_load_saved_data', array( $this, 'load_saved_data' ) );
		add_action( 'wp_ajax_reset_settings_data', array( $this, 'reset_settings_data' ) );
		add_action( 'tutor_option_monetize_by_changed', array( $this, 'handle_changed_monetization_option' ) );
	}

	/**
	 * Get settings value
	 *
	 * @since 2.0.0
	 *
	 * @param mixed $key option key.
	 * @param mixed $default default value.
	 *
	 * @return mixed
	 */
	private function get( $key = null, $default = false ) {

		if ( ! $this->options ) {
			// Get if already not prepared.
			$this->options = (array) maybe_unserialize( get_option( 'tutor_option' ) );
		}

		$option = $this->options;

		if ( empty( $option ) || ! is_array( $option ) ) {
			return $default;
		}

		if ( ! $key ) {
			return $option;
		}

		if ( array_key_exists( $key, $option ) ) {
			return apply_filters( $key, $option[ $key ] );
		}

		// Access array value via dot notation, such as option->get('value.subvalue').
		if ( strpos( $key, '.' ) ) {
			$option_key_array = explode( '.', $key );
			$new_option       = $option;
			foreach ( $option_key_array as $dot_key ) {
				if ( isset( $new_option[ $dot_key ] ) ) {
					$new_option = $new_option[ $dot_key ];
				} else {
					return $default;
				}
			}

			return apply_filters( $key, $new_option );
		}

		return $default;
	}

	/**
	 * Get only list of options.
	 *
	 * @since 3.0.0
	 *
	 * @param array $only only options.
	 *
	 * @return array
	 */
	public static function get_only( $only = array() ) {
		$settings = get_option( 'tutor_option', array() );
		return array_intersect_key( $settings, array_flip( $only ) );
	}

	/**
	 * Prepare settings search item.
	 *
	 * @since 3.0.0
	 *
	 * @param array $section section item.
	 * @param array $block block item.
	 * @param array $field field item.
	 *
	 * @return array prepared searchable field item.
	 */
	private function prepare_search_item( $section, $block, $field ) {
		$field['section_label'] = isset( $section['label'] ) ? $section['label'] : '';
		$field['section_slug']  = isset( $section['slug'] ) ? $section['slug'] : '';
		$field['block_label']   = isset( $block['label'] ) ? $block['label'] : '';

		return $field;
	}

	/**
	 * Function to get all fields for search tutor_option_search
	 *
	 * @since 2.0.0
	 *
	 * @return void send wp_json response
	 */
	public function tutor_option_search() {
		tutor_utils()->checking_nonce();

		if ( ! User::is_admin() ) {
			wp_send_json_error( tutor_utils()->error_message() );
		}

		$data_array = array();
		foreach ( $this->get_setting_fields() as $sections ) {
			if ( is_array( $sections ) && ! empty( $sections ) ) {
				foreach ( Input::sanitize_array( $sections ) as $section ) {
					foreach ( $section['blocks'] as $blocks ) {
						if ( isset( $blocks['fields'] ) && ! empty( $blocks['fields'] ) ) {
							foreach ( $blocks['fields'] as $fields ) {
								$data_array['fields'][] = $this->prepare_search_item( $section, $blocks, $fields );
							}
						}
					}

					/**
					 * Submenu item search.
					 *
					 * @since 3.0.0
					 */
					if ( isset( $section['submenu'] ) && is_array( $section['submenu'] ) ) {
						foreach ( Input::sanitize_array( $section['submenu'] ) as $submenu_section ) {
							foreach ( $submenu_section['blocks'] as $block ) {
								if ( isset( $block['fields'] ) && ! empty( $block['fields'] ) ) {
									foreach ( $block['fields'] as $fields ) {
										$data_array['fields'][] = $this->prepare_search_item( $submenu_section, $block, $fields );
									}
								}
							}
						}
					}
				}
			}
		}

		wp_send_json_success( $data_array );
	}

	/**
	 * Export settings
	 *
	 * @since 2.0.0
	 *
	 * @return void send wp_json response
	 */
	public function tutor_export_settings() {
		tutor_utils()->checking_nonce();

		if ( ! User::is_admin() ) {
			wp_send_json_error( tutor_utils()->error_message() );
		}

		$tutor_option = get_option( 'tutor_option' );
		$data         = maybe_unserialize( $tutor_option );

		$export_data = $this->get_export_json_schema();

		$prepare_data = array(
			'content_type' => 'settings',
			'data'         => $data,
		);

		$export_data['data'][] = $prepare_data;

		$response = array(
			'job_progress'       => '100',
			'exported_data'      => $export_data,
			'completed_contents' => array(
				'settings' => true,
			),
		);

		// Update settings log.
		$this->update_settings_log( $data, 'Exported' );

		$this->json_response( __( 'Settings exported successfully', 'tutor' ), $response );
	}

	/**
	 * Export single settings
	 *
	 * @since 2.0.0
	 *
	 * @return void send wp_json response
	 */
	public function tutor_export_single_settings() {

		tutor_utils()->checking_nonce();

		// Check if user is privileged.
		if ( ! User::is_admin() ) {
			wp_send_json_error( tutor_utils()->error_message() );
		}

		$tutor_settings_log = get_option( 'tutor_settings_log' );
		$export_id          = $this->get_request_data( 'export_id' );

		$export_data = $this->get_export_json_schema();

		$prepare_data = array(
			'content_type' => 'settings',
			'data'         => $tutor_settings_log[ $export_id ]['dataset'],
		);

		$export_data['data'][] = $prepare_data;
		wp_send_json_success( $export_data );
	}

	/**
	 * Apply settings
	 *
	 * @since 2.0.0
	 *
	 * @return void send wp_json response
	 */
	public function tutor_apply_settings() {

		tutor_utils()->checking_nonce();

		// Check if user is privileged.
		if ( ! User::is_admin() ) {
			wp_send_json_error( tutor_utils()->error_message() );
		}

		$tutor_settings_log = get_option( 'tutor_settings_log' );
		$apply_id           = $this->get_request_data( 'apply_id' );

		update_option( 'tutor_option', $tutor_settings_log[ $apply_id ]['dataset'] );

		wp_send_json_success( $tutor_settings_log[ $apply_id ] );
	}

	/**
	 * Delete single setting
	 *
	 * @since 2.0.0
	 *
	 * @return void send wp_json response
	 */
	public function tutor_delete_single_settings() {

		tutor_utils()->checking_nonce();

		// Check if user is privileged.
		if ( ! User::is_admin() ) {
			wp_send_json_error( tutor_utils()->error_message() );
		}

		$tutor_settings_log = get_option( 'tutor_settings_log' );
		$delete_id          = $this->get_request_data( 'delete_id' );
		unset( $tutor_settings_log[ $delete_id ] );
		update_option( 'tutor_settings_log', $tutor_settings_log, false );

		wp_send_json_success( $tutor_settings_log );
	}

	/**
	 * Get request data
	 *
	 * @since 2.0.0
	 *
	 * @param mixed $var option key.
	 *
	 * @return mixed
	 */
	public function get_request_data( $var ) {
		return isset( $_REQUEST[ $var ] ) ? sanitize_text_field( wp_unslash( $_REQUEST[ $var ] ) ) : null;
	}

	/**
	 * Tutor settings log
	 *
	 * @since 2.0.0
	 *
	 * @return void send wp_json response
	 */
	public function load_saved_data() {
		tutor_utils()->checking_nonce();

		// Check if user is privileged.
		if ( ! User::is_admin() ) {
			wp_send_json_error( tutor_utils()->error_message() );
		}

		wp_send_json_success( get_option( 'tutor_settings_log' ) );
	}

	/**
	 * Reset settings
	 *
	 * @since 2.0.0
	 *
	 * @return void send wp_json response
	 */
	public function reset_settings_data() {
		tutor_utils()->checking_nonce();

		// Check if user is privileged.
		if ( ! User::is_admin() ) {
			wp_send_json_error( tutor_utils()->error_message() );
		}

		$reset_fields = $return_fields = $return_fields_group = array(); //phpcs:ignore
		$reset_page   = Input::post( 'reset_page' );
		$setting_data = $this->get_setting_fields()['option_fields'][ $reset_page ]['blocks'];

		foreach ( $setting_data as $blocks ) {

			$block_fields = isset( $blocks['fields'] ) ? $blocks['fields'] : array();
			foreach ( $block_fields as $fields ) {
				$return_fields[] = $fields;
			}

			$block_fields_group = isset( $blocks['fields_group'] ) ? $blocks['fields_group'] : array();
			foreach ( $block_fields_group as $fields ) {
				$return_fields_group[] = $fields;
			}
		}

		$reset_fields = array_merge( $return_fields, $return_fields_group );

		wp_send_json_success( $reset_fields );
	}

	/**
	 * Import settings
	 *
	 * @since 2.0.0
	 *
	 * @return void
	 */
	public function tutor_import_settings() {
		tutor_utils()->checking_nonce();

		// Check if user is privileged.
		if ( ! User::is_admin() ) {
			wp_send_json_error( tutor_utils()->error_message() );
		}

		//phpcs:ignore
		$data = $_FILES['data'];

		if ( ! isset( $data['tmp_name'] ) ) {
			$this->response_bad_request( __( 'Invalid file', 'tutor' ) );
		}

		$request = json_decode( file_get_contents( $data['tmp_name'] ), true );

		unlink( $data['tmp_name'] );

		$settings_found = false;

		if ( json_last_error() ) {
			$this->response_bad_request( __( 'Invalid json file', 'tutor' ) );
		}

		if ( ! isset( $request['data'] ) ) {
			$this->response_bad_request( __( 'Data not found or invalid', 'tutor' ) );
		}

		if ( is_array( $request['data'] ) && count( $request['data'] ) ) {
			foreach ( $request['data'] as $content ) {
				if ( isset( $content['content_type'] ) && 'settings' === $content['content_type'] ) {
					$settings_found = true;
				}
			}
		}

		if ( ! $settings_found ) {
			$this->response_bad_request( __( 'Settings not found', 'tutor' ) );
		}

		$settings_data   = is_array( $request ) && isset( $request['data'] ) ? $request['data'][0]['data'] : array();
		$update_settings = $this->update_settings_log( $settings_data, 'Imported' );

		$response = array(
			'job_progress'  => '100',
			'exported_data' => $update_settings,
		);

		$this->json_response( __( 'Settings imported successfully!', 'tutor' ), $response );
	}

	/**
	 * Validate options before save.
	 *
	 * @since 2.8.0
	 *
	 * @param array $options option submitted to save.
	 *
	 * @return void
	 */
	public function validate_options( $options ) {
		$success = true;
		$message = '';

		$enable_sharing        = $options['enable_revenue_sharing'] ?? 'off';
		$admin_commission      = (int) $options['earning_admin_commission'] ?? 0;
		$instructor_commission = (int) $options['earning_instructor_commission'] ?? 0;

		if ( 'on' === $enable_sharing && ( $admin_commission + $instructor_commission ) > 100 ) {
			$success = false;
			$message = __( 'Total share percentage must be 100% or less', 'tutor' );
		}

		if ( ! $success ) {
			wp_send_json(
				array(
					'success' => $success,
					'message' => $message,
				)
			);
		}
	}

	/**
	 * Function tutor_option_save
	 *
	 * @since 2.0.0
	 *
	 * @return void send wp_json response
	 */
	public function tutor_option_save() {
		tutor_utils()->checking_nonce();

		if ( ! User::is_admin() ) {
			wp_send_json_error( tutor_utils()->error_message() );
		}

		$data_before   = get_option( 'tutor_option' );
		$login_page_id = 0;

		if ( isset( $data_before['tutor_login_page'] ) ) {
			$login_page_id = $data_before['tutor_login_page'];
		}

		$option = (array) tutor_utils()->array_get( 'tutor_option', $_POST, array() ); //phpcs:ignore

		unset( $option['enable_spotlight_mode'], $option['tutor_frontend_course_page_logo_id'] );

		foreach ( array( 'brand_logo_light', 'brand_logo_dark' ) as $brand_logo_key ) {
			$attachment_id             = absint( $option[ $brand_logo_key ] ?? 0 );
			$option[ $brand_logo_key ] = $attachment_id && wp_attachment_is_image( $attachment_id ) ? $attachment_id : 0;
		}

		do_action( 'tutor_option_save_before', $option );

		if ( ! isset( $option['tutor_login_page'] ) ) {
			$option['tutor_login_page'] = $login_page_id ? $login_page_id : 0;
		}

		$option = Input::sanitize_array(
			$option,
			array(
				'payment_settings'                         => 'wp_kses_post',
				'tutor_bank_transfer_withdraw_instruction' => 'sanitize_textarea_field',
				'certificate_showcase_desc'                => 'sanitize_textarea_field',
				'invoice_from_address'                     => 'sanitize_textarea_field',
				'fees_name'                                => 'sanitize_textarea_field',
			)
		);
		$option = apply_filters( 'tutor_option_input', $option );

		$time                                  = strtotime( 'now' ) + ( 6 * 60 * 60 );
		$save_import_data['datetime']          = $time;
		$save_import_data['history_date']      = gmdate( 'j M, Y, g:i a', $time );
		$save_import_data['datatype']          = 'saved';
		$save_import_data['dataset']           = $option;
		$import_data[ 'tutor-saved-' . $time ] = $save_import_data;
		$update_option                         = array();
		$get_option_data                       = get_option( 'tutor_settings_log', array() );

		if ( ! empty( $get_option_data ) ) {
			$update_option = array_merge( $import_data, $get_option_data );
		} else {
			$update_option = array_merge( $update_option, $import_data );
		}

		$update_option = array_slice( $update_option, 0, 10 );

		update_option( 'tutor_settings_log', $update_option, false );
		update_option( 'tutor_option', $option );
		update_option( 'tutor_option_update_time', gmdate( 'j M, Y, g:i a', $time ) );

		/**
		 * Hook for each tutor settings option change detection.
		 * Example: `tutor_option_{course_permalink_base}_changed`
		 *
		 * @since 2.6.0
		 */
		$data_after = get_option( 'tutor_option' );
		if ( $data_before !== $data_after && is_array( $data_after ) ) {
			foreach ( $data_after as $key => $value ) {
				$from = $data_before[ $key ] ?? null;
				$to   = $value;
				if ( $from !== $to ) {
					do_action( "tutor_option_{$key}_changed", $from, $to );
				}
			}
		}

		do_action( 'tutor_option_save_after' );

		$data = apply_filters(
			'tutor_option_saved_data',
			array(
				'success' => true,
				'message' => __( 'Settings Saved', 'tutor' ),
				'options' => $option,
			)
		);

		wp_send_json( $data );
	}

	/**
	 * Handle monetization option value change.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public function handle_changed_monetization_option() {
		add_filter(
			'tutor_option_saved_data',
			function ( $res ) {
				$res['reload_required'] = true;
				return $res;
			}
		);
	}

	/**
	 * Function tutor_option_save
	 *
	 * @since 2.0.0
	 *
	 * @return void send wp_json response
	 */
	public function tutor_option_default_save() {
		tutor_utils()->checking_nonce();

		if ( ! User::is_admin() ) {
			wp_send_json_error( tutor_utils()->error_message() );
		}

		$attr                 = $this->get_setting_fields();
		$tutor_default_option = get_option( 'tutor_default_option' );
		$tutor_saved_option   = get_option( 'tutor_option' );
		$attr_default         = array();

		foreach ( $attr as $sections ) {
			if ( is_array( $sections ) && count( $sections ) ) {
				foreach ( $sections as $section ) {
					foreach ( $section['blocks'] as $blocks ) {
						if ( isset( $blocks['fields'] ) ) {
							foreach ( $blocks['fields'] as $field ) {
								if ( isset( $field['key'] ) ) {
									if ( isset( $tutor_default_option[ $field['key'] ] ) ) {
										$attr_default[ $field['key'] ] = $tutor_saved_option[ $field['key'] ];
									} else {
										$attr_default[ $field['key'] ] = $field['default'] ?? '';
									}
								}
							}
						}
					}
				}
			}
		}

		update_option( 'tutor_option', $attr_default );

		wp_send_json_success( $attr_default );
	}

	/**
	 * Load settings page
	 *
	 * @since 2.0.0
	 *
	 * @return void
	 */
	public function load_settings_page() {
		$template_path = '';
		extract( $this->get_setting_fields() ); //phpcs:ignore

		if ( ! $template_path ) {
			$template_path = tutor()->path . '/views/options/settings.php';
		}
		include $template_path;
	}

	/**
	 * Get settings fields
	 *
	 * @since 2.0.0
	 *
	 * @return mixed
	 */
	public function get_setting_fields() {
		if ( $this->setting_fields ) {
			// Return from property if already prepared.
			return $this->setting_fields;
		}

		$pages = tutor_utils()->get_pages();

		$site_url    = site_url();
		$course_base = $this->get( 'course_permalink_base', 'courses' );
		$lesson_key  = $this->get( 'lesson_permalink_base', 'lessons' );
		$quiz_key    = $this->get( 'quiz_permalink_base', 'quizzes' );

		$course_url = $site_url . '/<code>' . $course_base . '</code>/sample-course';
		$lesson_url = $site_url . '/' . $course_base . '/sample-course/<code>' . $lesson_key . '</code>/sample-lesson/';
		$quiz_url   = $site_url . '/' . $course_base . '/sample-course/<code>' . $quiz_key . '</code>/sample-quiz/';

		$student_url       = tutor_utils()->profile_url( 0, false );
		$methods_array     = array();
		$withdrawl_methods = apply_filters( 'tutor_withdrawal_methods_all', array() );

		foreach ( $withdrawl_methods as $key => $method ) {
			$methods_array[ $key ] = $method['method_name'];
		}

		$page_args = array(
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'title'          => 'Courses',
		);

		$page_posts             = get_posts( $page_args );
		$course_archive_page_id = ( is_array( $page_posts ) && count( $page_posts ) ) ? $page_posts[0] : null;
		$default_visibility     = (bool) tutor_utils()->get_option( 'enable_spotlight_mode', true ) ? 'off' : 'on';

		$attr = array(
			'general'        => array(
				'label'    => __( 'General', 'tutor' ),
				'slug'     => 'general',
				'desc'     => __( 'General Settings', 'tutor' ),
				'template' => 'basic',
				'icon'     => 'tutor-icon-earth',
				'blocks'   => array(
					array(
						'label'      => false,
						'block_type' => 'uniform',
						'slug'       => 'general-page',
						'fields'     => array(
							array(
								'key'        => 'tutor_dashboard_page_id',
								'type'       => 'select',
								'label'      => __( 'Dashboard Page', 'tutor' ),
								'default'    => '0',
								'options'    => $pages,
								'desc'       => __( 'This page will be used for student and instructor dashboard', 'tutor' ),
								'searchable' => true,
							),
						),
					),
					array(
						'label'      => false,
						'block_type' => 'uniform',
						'slug'       => 'general-page',
						'fields'     => array(
							array(
								'key'        => 'tutor_toc_page_id',
								'type'       => 'select',
								'label'      => __( 'Terms and Conditions Page', 'tutor' ),
								'default'    => '0',
								'options'    => $pages,
								'desc'       => __( 'This page will be used as the Terms and Conditions page', 'tutor' ),
								'searchable' => true,
							),
							array(
								'key'        => OptionKeys::PRIVACY_POLICY,
								'type'       => 'select',
								'label'      => __( 'Privacy Policy', 'tutor' ),
								'default'    => 0,
								'options'    => $pages,
								'desc'       => __( 'Choose the page for privacy policy.', 'tutor' ),
								'searchable' => true,
							),
						),
					),
					array(
						'label'      => __( 'Others', 'tutor' ),
						'slug'       => 'others',
						'block_type' => 'isolate',
						'fields'     => array(
							array(
								'key'         => 'enable_course_marketplace',
								'type'        => 'toggle_switch',
								'label'       => __( 'Enable Marketplace', 'tutor' ),
								'label_title' => '',
								'default'     => 'off',
								'desc'        => __( 'Allow multiple instructors to sell their courses.', 'tutor' ),
							),
							array(
								'key'         => 'pagination_per_page',
								'type'        => 'number',
								'number_type' => 'integer',
								'label'       => __( 'Pagination', 'tutor' ),
								'default'     => '20',
								'desc'        => __( 'Set the number of rows to be displayed per page', 'tutor' ),
							),
						),
					),
					array(
						'label'      => __( 'Instructor', 'tutor' ),
						'slug'       => 'instructor',
						'block_type' => 'uniform',
						'fields'     => array(
							array(
								'key'         => 'enable_become_instructor_btn',
								'type'        => 'toggle_switch',
								'label'       => __( 'Become an Instructor Button', 'tutor' ),
								'label_title' => '',
								'default'     => 'off',
								'desc'        => __( 'Enable the option to display this button on the student dashboard.', 'tutor' ),
							),
							array(
								'key'         => 'instructor_can_publish_course',
								'type'        => 'toggle_switch',
								'label'       => __( 'Allow Instructors to Publish Courses', 'tutor' ),
								'label_title' => '',
								'default'     => 'off',
								'desc'        => __( 'Enable instructors to publish the course directly. If disabled, admins will be able to review course content before publishing.', 'tutor' ),
							),
							array(
								'key'         => 'instructor_can_delete_course',
								'type'        => 'toggle_switch',
								'label'       => __( 'Allow Instructors to Trash Courses', 'tutor' ),
								'label_title' => '',
								'default'     => 'on',
								'desc'        => __( 'Enable this setting to allow instructors to delete courses.', 'tutor' ),
							),
						),
					),
				),
			),
			'course'         => array(
				'label'    => __( 'Course', 'tutor' ),
				'slug'     => 'course',
				'desc'     => __( 'Course Settings', 'tutor' ),
				'template' => 'basic',
				'icon'     => 'tutor-icon-book-open',
				'blocks'   => array(
					'block_course' => array(
						'label'      => '',
						'slug'       => 'course',
						'block_type' => 'uniform',
						'fields'     => array(
							array(
								'key'         => 'student_must_login_to_view_course',
								'type'        => 'toggle_switch',
								'label'       => __( 'Course Visibility', 'tutor' ),
								'label_title' => '',
								'default'     => 'off',
								'desc'        => __( 'Students must be logged in to view course', 'tutor' ),
							),
							array(
								'key'         => 'course_content_access_for_ia',
								'type'        => 'toggle_switch',
								'label'       => __( 'Course Content Access', 'tutor' ),
								'default'     => 'off',
								'label_title' => '',
								'desc'        => __( 'Allow instructors and admins to view the course content without enrolling', 'tutor' ),
							),
							array(
								'key'     => 'course_content_summary',
								'type'    => 'toggle_switch',
								'label'   => __( 'Content Summary', 'tutor' ),
								'default' => 'on',
								'desc'    => __( 'Enabling this feature will show a course content summary on the Course Details page.', 'tutor' ),
							),
							array(
								'key'         => 'auto_course_complete_on_all_lesson_completion',
								'type'        => 'toggle_switch',
								'label'       => __( 'Auto Complete Course on All Lesson Completion', 'tutor' ),
								'default'     => 'off',
								'label_title' => '',
								'desc'        => __( 'If enabled, an Enrolled Course will be automatically completed if all its Lessons, Quizzes, and Assignments are already completed by the Student', 'tutor' ),
							),
							array(
								'key'            => 'course_completion_process',
								'type'           => 'radio_vertical',
								'label'          => __( 'Course Completion Process', 'tutor' ),
								'default'        => 'flexible',
								'select_options' => false,
								'options'        => array(
									'flexible' => array(
										'label' => __( 'Flexible', 'tutor' ),
										'desc'  => __( 'Students can complete courses anytime in the Flexible mode', 'tutor' ),
									),
									'strict'   => array(
										'label' => __( 'Strict', 'tutor' ),
										'desc'  => __( 'Students must complete all lessons, quizzes, and assignments to mark their courses as complete.', 'tutor' ),
									),
								),
								'desc'           => __( 'Choose when a user can click on the <strong>“Complete Course”</strong> button', 'tutor' ),
							),
							array(
								'key'         => 'course_retake_feature',
								'type'        => 'toggle_switch',
								'label'       => __( 'Course Retake', 'tutor' ),
								'default'     => 'off',
								'label_title' => '',
								'desc'        => __( 'Enabling this feature will allow students to reset course progress and start over.', 'tutor' ),
							),
							array(
								'key'         => 'course_reset_progress',
								'type'        => 'toggle_switch',
								'label'       => __( 'Course Reset Progress', 'tutor' ),
								'default'     => 'off',
								'label_title' => '',
								'desc'        => __( 'Enabling this feature allows students to reset their progress and start over before completing the course.', 'tutor' ),
							),
							array(
								'key'         => 'enable_course_review_moderation',
								'type'        => 'toggle_switch',
								'label'       => __( "Publish Course Review on Admin's Approval", 'tutor' ),
								'default'     => 'off',
								'label_title' => '',
								'desc'        => __( 'Enable to publish/re-publish Course Review after the approval of Site Admin', 'tutor' ),
							),
						),
					),
					'block_lesson' => array(
						'label'      => __( 'Lesson', 'tutor' ),
						'slug'       => 'lesson',
						'block_type' => 'uniform',
						'fields'     => array(
							array(
								'key'         => 'enable_lesson_classic_editor',
								'type'        => 'toggle_switch',
								'label'       => __( 'WP Editor for Lesson', 'tutor' ),
								'label_title' => '',
								'default'     => 'off',
								'desc'        => __( 'Enable classic editor to edit lesson.', 'tutor' ),
							),
							array(
								'key'         => 'autoload_next_course_content',
								'type'        => 'toggle_switch',
								'label'       => __( 'Automatically Load Next Course Content.', 'tutor' ),
								'label_title' => '',
								'default'     => 'off',
								'desc'        => __( 'Enable this feature to automatically load the next course content after the current one is finished.', 'tutor' ),
							),
							array(
								'key'         => 'enable_comment_for_lesson',
								'type'        => 'toggle_switch',
								'label'       => __( 'Enable Lesson Comment', 'tutor' ),
								'label_title' => '',
								'default'     => 'off',
								'desc'        => __( 'Enable this feature to allow students to post comments on lessons.', 'tutor' ),
							),
						),
					),
					'block_quiz'   => array(
						'label'      => __( 'Quiz', 'tutor' ),
						'slug'       => 'quiz',
						'block_type' => 'uniform',
						'fields'     => array(
							array(
								'key'            => 'quiz_when_time_expires',
								'type'           => 'radio_vertical',
								'label'          => __( 'When time expires', 'tutor' ),
								'default'        => 'auto_abandon',
								'select_options' => false,
								'options'        => array(
									'auto_submit'  => array(
										'label' => __( 'Auto Submit', 'tutor' ),
										'desc'  => __( 'The current quiz answers are submitted automatically.', 'tutor' ),
									),
									'auto_abandon' => array(
										'label' => __( 'Auto Abandon', 'tutor' ),
										'desc'  => __( 'Attempts must be submitted before time expires, otherwise they will not be counted.', 'tutor' ),
									),
								),
								'desc'           => __( 'Choose which action to follow when the quiz time expires.', 'tutor' ),
							),
							array(
								'key'     => 'quiz_answer_display_time',
								'type'    => 'number',
								'label'   => __( 'Correct Answer Display Time (When Reveal Mode is enabled)', 'tutor' ),
								'default' => '2',
								'desc'    => __( 'Put the answer display time in seconds', 'tutor' ),
							),
							array(
								'key'     => 'quiz_previous_button_enabled',
								'type'    => 'toggle_switch',
								'label'   => __( 'Show Quiz Previous Button', 'tutor' ),
								'default' => 'on',
								'desc'    => __( 'Choose whether to show or hide the previous button for each question.', 'tutor' ),
							),
							array(
								'key'     => 'quiz_grade_method',
								'type'    => 'radio_horizontal_full',
								'label'   => __( 'Final Grade Calculation', 'tutor' ),
								'desc'    => __( 'When multiple attempts are allowed, select which method should be used to calculate a student\'s final grade for the quiz.', 'tutor' ),
								'default' => 'highest_grade',
								'options' => array(
									'highest_grade' => __( 'Highest Grade', 'tutor' ),
									'average_grade' => __( 'Average Grade', 'tutor' ),
									'first_attempt' => __( 'First Attempt', 'tutor' ),
									'last_attempt'  => __( 'Last Attempt', 'tutor' ),
								),
							),
						),
					),
					array(
						'label'      => __( 'Video', 'tutor' ),
						'slug'       => 'video',
						'block_type' => 'uniform',
						'fields'     => array(
							array(
								'key'         => 'supported_video_sources',
								'type'        => 'checkbox_vertical',
								'default'     => array( 'youtube', 'vimeo' ),
								'label'       => __( 'Preferred Video Source', 'tutor' ),
								'label_title' => __( 'Preferred Video Source', 'tutor' ),
								'options'     => tutor_utils()->get_video_sources( true ),
								'desc'        => __( 'Select the video hosting platform(s) you want to enable.', 'tutor' ),
							),
							array(
								'key'         => 'disable_default_player_youtube',
								'type'        => 'toggle_switch',
								'label'       => __( 'Use Tutor Player for YouTube', 'tutor' ),
								'label_title' => '',
								'default'     => 'off',
								'desc'        => __( 'Enable this option to use Tutor LMS video player for YouTube.', 'tutor' ),
							),
							array(
								'key'         => 'disable_default_player_vimeo',
								'type'        => 'toggle_switch',
								'label'       => __( 'Use Tutor Player for Vimeo', 'tutor' ),
								'label_title' => '',
								'default'     => 'off',
								'desc'        => __( 'Enable this option to use Tutor LMS video player for Vimeo.', 'tutor' ),
							),
						),
					),
				),
			),
			'monetization'   => array(
				'label'    => __( 'Monetization', 'tutor' ),
				'slug'     => 'monetization',
				'desc'     => __( 'Monetization Settings', 'tutor' ),
				'template' => 'basic',
				'icon'     => 'tutor-icon-badge-discount',
				'blocks'   => array(
					'block_options'         => array(
						'label'      => __( 'Options', 'tutor' ),
						'slug'       => 'options',
						'block_type' => 'uniform',
						'fields'     => array(
							array(
								'key'            => 'monetize_by',
								'type'           => 'select',
								'label'          => __( 'Select eCommerce Engine', 'tutor' ),
								'select_options' => false,
								'options'        => apply_filters(
									'tutor_monetization_options',
									array(
										'free' => __( 'Disable Monetization', 'tutor' ),
									)
								),
								'default'        => 'free',
								'desc'           => __( 'Select a monetization option to generate revenue by selling courses.', 'tutor' ),
							),
						),
					),
					'block_woocommerce'     => array(
						'label'      => __( 'WooCommerce', 'tutor' ),
						'slug'       => 'woocommerce',
						'block_type' => 'uniform',
						'fields'     => array(
							array(
								'key'         => 'tutor_woocommerce_order_auto_complete',
								'type'        => 'toggle_switch',
								'label'       => __( 'Automatically Complete WooCommerce Orders', 'tutor' ),
								'label_title' => '',
								'default'     => 'off',
								'desc'        => __( 'If enabled, in the case of Courses, WooCommerce Orders will get the "Completed" status .', 'tutor' ),
							),
							array(
								'key'         => 'wc_automatic_order_complete_redirect_to_courses',
								'type'        => 'toggle_switch',
								'label'       => __( 'Auto Redirect to Courses', 'tutor' ),
								'default'     => 'off',
								'label_title' => '',
								'desc'        => __( 'When a user\'s WooCommerce order is auto-completed, they will be redirected to enrolled courses', 'tutor' ),
							),
							array(
								'key'         => 'enable_guest_course_cart',
								'type'        => 'toggle_switch',
								'label'       => __( 'Enable Guest Mode', 'tutor' ),
								'label_title' => '',
								'default'     => 'off',
								'desc'        => __( 'Allow customers to place orders without an account.', 'tutor' ),
							),
						),
					),
					'block_revenue_sharing' => array(
						'label'      => __( 'Revenue Sharing', 'tutor' ),
						'slug'       => 'revenue_sharing',
						'block_type' => 'uniform',
						'fields'     => array(
							array(
								'key'           => 'enable_revenue_sharing',
								'type'          => 'toggle_switch',
								'label'         => __( 'Enable Revenue Sharing', 'tutor' ),
								'label_title'   => '',
								'default'       => 'off',
								'desc'          => __( 'Allow revenue generated from selling courses to be shared with course creators.', 'tutor' ),
								'toggle_fields' => 'sharing_percentage',
								'toggle_blocks' => 'fees,withdraw',
							),
							array(
								'key'         => 'sharing_percentage',
								'type'        => 'double_input',
								'label'       => __( 'Sharing Percentage', 'tutor' ),
								'label_title' => '',
								'default'     => '',
								'fields'      => array(
									'earning_instructor_commission' => array(
										'id'      => 'revenue-instructor',
										'type'    => 'ratio',
										'title'   => __( 'Instructor Takes', 'tutor' ),
										'default' => 20,
									),
									'earning_admin_commission' => array(
										'id'      => 'revenue-admin',
										'type'    => 'ratio',
										'title'   => __( 'Admin Takes', 'tutor' ),
										'default' => 80,
									),
								),
								'desc'        => __( 'Set how the sales revenue will be shared among admins and instructors.', 'tutor' ),
							),
						),
					),
					'block_fees'            => array(
						'label'      => __( 'Fees', 'tutor' ),
						'slug'       => 'fees',
						'block_type' => 'uniform',
						'fields'     => array(
							array(
								'key'           => 'enable_fees_deducting',
								'type'          => 'toggle_switch',
								'label'         => __( 'Deduct Fees', 'tutor' ),
								'label_title'   => '',
								'default'       => 'off',
								'desc'          => __( 'Fees are charged from the entire sales amount. The remaining amount will be divided among admin and instructors.', 'tutor' ),
								'toggle_fields' => 'fees_name,fee_amount_type',
							),
							array(
								'key'         => 'fees_name',
								'type'        => 'textarea',
								'label'       => __( 'Fee Description', 'tutor' ),
								'placeholder' => __( 'Fee Description', 'tutor' ),
								'desc'        => __( 'Set a description for the fee that you are deducting. Make sure to give a reasonable explanation to maintain transparency with your site’s instructors.', 'tutor' ),
								'maxlength'   => 200,
								'rows'        => 5,
								'default'     => 'Maintenance Fees',
							),
							array(
								'key'          => 'fee_amount_type',
								'type'         => 'group_fields',
								'label'        => __( 'Fee Amount & Type', 'tutor' ),
								'desc'         => __( 'Select the fee type and add fee amount/percentage', 'tutor' ),
								'group_fields' => array(
									'fees_type'   => array(
										'type'           => 'select',
										'default'        => 'fixed',
										'select_options' => false,
										'options'        => array(
											'percent' => __( 'Percent', 'tutor' ),
											'fixed'   => __( 'Fixed', 'tutor' ),
										),
									),
									'fees_amount' => array(
										'type'    => 'number',
										'default' => '0',
									),
								),
							),
						),
					),
					'block_withdraw'        => array(
						'label'      => __( 'Withdraw', 'tutor' ),
						'slug'       => 'withdraw',
						'block_type' => 'uniform',
						'fields'     => array(
							array(
								'key'     => 'min_withdraw_amount',
								'type'    => 'number',
								'label'   => __( 'Minimum Withdrawal Amount', 'tutor' ),
								'default' => '80',
								'desc'    => __( 'Instructors should earn equal or above this amount to make a withdraw request.', 'tutor' ),
							),
							array(
								'key'         => 'minimum_days_for_balance_to_be_available',
								'type'        => 'number',
								'number_type' => 'integer',
								'label'       => __( 'Minimum Days Before Balance is Available', 'tutor' ),
								'default'     => '7',
								'min'         => 1,
								'desc'        => __( 'Any income has to remain this many days in the platform before it is available for withdrawal.', 'tutor' ),
							),
							array(
								'key'     => 'tutor_withdrawal_methods',
								'type'    => 'checkbox_horizontal',
								'label'   => __( 'Enable Withdraw Method', 'tutor' ),
								'default' => array( 'bank_transfer_withdraw' ),
								'options' => $methods_array,
								'desc'    => __( 'Set how you would like to withdraw money from the website.', 'tutor' ),
							),
							array(
								'key'     => 'tutor_bank_transfer_withdraw_instruction',
								'type'    => 'textarea',
								'label'   => __( 'Bank Instructions', 'tutor' ),
								'default' => __( 'Write the up to date bank informations of your instructor here.', 'tutor' ),
								'desc'    => __( 'Write bank instructions for the instructors to conduct withdrawals.', 'tutor' ),
							),
						),
					),
				),
			),
			'design'         => array(
				'label'    => __( 'Design', 'tutor' ),
				'slug'     => 'design',
				'desc'     => __( 'Design Settings', 'tutor' ),
				'template' => 'design',
				'icon'     => 'tutor-icon-color-palette',
				'blocks'   => array(
					// Experimental.
					'block_appearance'    => array(
						'label'      => __( 'Appearance', 'tutor' ),
						'slug'       => 'appearance',
						'block_type' => 'uniform',
						'fields'     => array(
							array(
								'key'     => 'learning_mode',
								'type'    => 'radio_horizontal_image',
								'label'   => __( 'Learning Mode', 'tutor' ),
								'desc'    => __( 'Decide how students will experience the courses you create.', 'tutor' ),
								'default' => self::LEARNING_MODE_MODERN,
								'options' => array(
									self::LEARNING_MODE_MODERN      => array(
										'title' => __( 'Modern', 'tutor' ),
										'image' => 'learning-mode/modern.svg',
									),
									self::LEARNING_MODE_KIDS    => array(
										'title' => __( 'Kids', 'tutor' ),
										'image' => 'learning-mode/kids.svg',
									),
									self::LEARNING_MODE_LEGACY        => array(
										'title' => __( 'Legacy', 'tutor' ),
										'image' => 'learning-mode/legacy.svg',
									),
								),
							),
							array(
								'key'     => 'default_theme',
								'type'    => 'radio_horizontal_image',
								'label'   => __( 'Default Theme', 'tutor' ),
								'desc'    => __( 'Set the default appearance for learners across your platform. Learners can switch between dark and light mode if enabled.', 'tutor' ),
								'default' => self::DEFAULT_THEME_SYSTEM,
								'options' => array(
									self::DEFAULT_THEME_LIGHT      => array(
										'title' => __( 'Light', 'tutor' ),
										'image' => 'default-theme/light.webp',
									),
									self::DEFAULT_THEME_DARK       => array(
										'title' => __( 'Dark', 'tutor' ),
										'image' => 'default-theme/dark.webp',
									),
									self::DEFAULT_THEME_SYSTEM     => array(
										'title' => __( 'Auto', 'tutor' ),
										'image' => 'default-theme/auto.webp',
									),
								),
							),
							array(
								'key'         => 'brand_color',
								'preset_name' => 'brand_color',
								'type'        => 'color_field',
								'label'       => __( 'Brand Color', 'tutor' ),
								'desc'        => __( 'Customize the primary accent color used across your learning platform to match your brand identity.', 'tutor' ),
								'class'       => 'color-picker-wrapper',
								'default'     => tutor_utils()->get_default_brand_color(),
							),
							array(
								'key'   => 'brand_logo',
								'type'  => 'image_upload_list',
								'label' => __( 'Brand Logo', 'tutor' ),
								'desc'  => __( 'Upload your brand logo to display it in the Course Builder and Frontend Dashboard.', 'tutor' ),
								'items' => array(
									'light' => array(
										'label'   => __( 'Light Mode', 'tutor' ),
										'key'     => 'brand_logo_light',
										'icon'    => Icon::LIGHT,
										'default' => get_tutor_option( 'tutor_frontend_course_page_logo_id', 0 ),
									),
									'dark'  => array(
										'label'   => __( 'Dark Mode', 'tutor' ),
										'key'     => 'brand_logo_dark',
										'icon'    => Icon::DARK,
										'default' => 0,
									),
								),
							),
						),
					),
					'block_course'        => array(
						'label'      => __( 'Course', 'tutor' ),
						'slug'       => 'course',
						'block_type' => 'uniform',
						'fields'     => array(
							array(
								'key'     => 'courses_col_per_row',
								'type'    => 'radio_horizontal',
								'label'   => __( 'Column Per Row', 'tutor' ),
								'default' => '3',
								'options' => array(
									'1' => __( 'One', 'tutor' ),
									'2' => __( 'Two', 'tutor' ),
									'3' => __( 'Three', 'tutor' ),
									'4' => __( 'Four', 'tutor' ),
								),
								'desc'    => __( 'Define how many columns you want to use to display courses.', 'tutor' ),
							),
							array(
								'key'         => 'courses_per_page',
								'type'        => 'number',
								'number_type' => 'integer',
								'label'       => __( 'Courses Per Page', 'tutor' ),
								'default'     => '12',
								'desc'        => __( 'Set the number of courses to display per page on the Course List page.', 'tutor' ),
							),
							array(
								'key'           => 'course_archive_filter',
								'type'          => 'toggle_switch',
								'label'         => __( 'Course Filter', 'tutor' ),
								'label_title'   => '',
								'default'       => 'off',
								'desc'          => __( 'Show sorting and filtering options on course archive page', 'tutor' ),
								'toggle_fields' => 'supported_course_filters',
							),
							array(
								'key'     => 'supported_course_filters',
								'type'    => 'checkbox_horizontal',
								'label'   => __( 'Preferred Course Filters', 'tutor' ),
								'default' => array( 'search', 'category' ),
								'options' => array(
									'search'           => __( 'Keyword Search', 'tutor' ),
									'category'         => __( 'Category', 'tutor' ),
									'tag'              => __( 'Tag', 'tutor' ),
									'difficulty_level' => __( 'Difficulty Level', 'tutor' ),
									'price_type'       => __( 'Price Type', 'tutor' ),
								),
								'desc'    => __( 'Choose preferred filter options you\'d like to show on the course archive page.', 'tutor' ),
							),
							array(
								'key'         => 'course_archive_filter_sorting',
								'type'        => 'toggle_switch',
								'label'       => __( 'Course Sorting', 'tutor' ),
								'label_title' => '',
								'default'     => 'on',
								'desc'        => __( 'If enabled, the courses will be sortable by Course Name or Creation Date in either Ascending or Descending order', 'tutor' ),
							),
						),
					),
					'layout'              => array(
						'label'      => __( 'Layout', 'tutor' ),
						'slug'       => 'layout',
						'block_type' => 'uniform',
						'fields'     => array(
							array(
								'key'           => 'instructor_list_layout',
								'type'          => 'group_radio',
								'label'         => __( 'Instructor List Layout', 'tutor' ),
								'desc'          => __( 'Choose a layout for the list of instructors inside a course page. You can change this at any time.', 'tutor' ),
								'default'       => 'portrait',
								'group_options' => array(
									'vertical'   => array(
										'default' => array(
											'title' => __( 'Portrait', 'tutor' ),
											'image' => 'instructor-layout/instructor-portrait.svg',
										),
										'cover'   => array(
											'title' => __( 'Cover', 'tutor' ),
											'image' => 'instructor-layout/instructor-cover.svg',
										),
										'minimal' => array(
											'title' => __( 'Minimal', 'tutor' ),
											'image' => 'instructor-layout/instructor-minimal.svg',
										),
									),
									'horizontal' => array(
										'portrait-horizontal'   => array(
											'title' => __( 'Portrait Horizontal', 'tutor' ),
											'image' => 'instructor-layout/instructor-horizontal-portrait.svg',
										),
										'minimal-horizontal' => array(
											'title' => __( 'Minimal Horizontal', 'tutor' ),
											'image' => 'instructor-layout/instructor-horizontal-minimal.svg',
										),
									),
								),
							),
							array(
								'key'           => 'public_profile_layout',
								'type'          => 'group_radio_full_3',
								'label'         => __( 'Instructor Public Profile Layout', 'tutor' ),
								'desc'          => __( 'Choose a layout design for a instructor’s public profile', 'tutor' ),
								'default'       => 'pp-rectangle',
								'group_options' => array(
									'private'      => array(
										'title' => __( 'Private', 'tutor' ),
										'image' => 'profile-layout/profile-private.svg',
									),
									'pp-circle'    => array(
										'title' => __( 'Modern', 'tutor' ),
										'image' => 'profile-layout/profile-modern.svg',
									),
									'no-cp'        => array(
										'title' => __( 'Minimal', 'tutor' ),
										'image' => 'profile-layout/profile-minimal.svg',
									),
									'pp-rectangle' => array(
										'title' => __( 'Classic', 'tutor' ),
										'image' => 'profile-layout/profile-classic.svg',
									),
								),
							),
							array(
								'key'           => 'student_public_profile_layout',
								'type'          => 'group_radio_full_3',
								'label'         => __( 'Student Public Profile Layout', 'tutor' ),
								'desc'          => __( 'Choose a layout design for a student’s public profile', 'tutor' ),
								'default'       => 'pp-rectangle',
								'group_options' => array(
									'private'      => array(
										'title' => __( 'Private', 'tutor' ),
										'image' => 'profile-layout/profile-private.svg',
									),
									'pp-circle'    => array(
										'title' => __( 'Modern', 'tutor' ),
										'image' => 'profile-layout/profile-modern.svg',
									),
									'no-cp'        => array(
										'title' => __( 'Minimal', 'tutor' ),
										'image' => 'profile-layout/profile-minimal.svg',
									),
									'pp-rectangle' => array(
										'title' => __( 'Classic', 'tutor' ),
										'image' => 'profile-layout/profile-classic.svg',
									),
								),
							),
						),
					),
					'block_page_elements' => array(
						'label'      => __( 'Page Elements', 'tutor' ),
						'slug'       => 'page-elements',
						'block_type' => 'uniform',
						'fields'     => array(
							array(
								'key'     => 'page_elements',
								'type'    => 'toggle_matrix',
								'label'   => __( 'Header & Footer', 'tutor' ),
								'desc'    => __( 'Control the visibility of Header and Footer for Dashboard and Learning Area', 'tutor' ),
								'columns' => array(
									'header' => array(
										'label'      => __( 'Header', 'tutor' ),
										'icon'       => Icon::FOOTER,
										'icon_attrs' => array( 'data-header-icon' => 'true' ),
									),
									'footer' => array(
										'label' => __( 'Footer', 'tutor' ),
										'icon'  => Icon::FOOTER,
									),
								),
								'items'   => array(
									'dashboard' => array(
										'label'  => __( 'Dashboard', 'tutor' ),
										'header' => array(
											'key'     => 'show_dashboard_site_header',
											'default' => 'off',
										),
										'footer' => array(
											'key'     => 'show_dashboard_site_footer',
											'default' => 'off',
										),
									),
									'learning'  => array(
										'label'  => __( 'Learning Area', 'tutor' ),
										'header' => array(
											'key'     => 'show_learning_site_header',
											'default' => $default_visibility,
										),
										'footer' => array(
											'key'     => 'show_learning_site_footer',
											'default' => $default_visibility,
										),
									),
								),
							),
						),
					),
					'course-details'      => array(
						'label'      => __( 'Course Details', 'tutor' ),
						'slug'       => 'course-details',
						'block_type' => 'isolate',
						'fields'     => array(
							array(
								'key'           => 'course_details_adjustments',
								'type'          => 'checkgroup',
								'label'         => __( 'Page Features', 'tutor' ),
								'desc'          => __( 'You can keep the following features active or inactive as per the need of your business model', 'tutor' ),
								'group_options' => array(
									array(
										'key'     => 'display_course_instructors',
										'type'    => 'toggle_single',
										'label'   => __( 'Instructor Info', 'tutor' ),
										'default' => 'on',
										'desc'    => __( 'Toggle to show instructor info', 'tutor' ),
									),
									array(
										'key'     => 'enable_wishlist',
										'type'    => 'toggle_single',
										'label'   => __( 'Wishlist', 'tutor' ),
										'default' => 'on',
										'desc'    => __( 'Toggle to disable/enable wishlist', 'tutor' ),
									),
									array(
										'key'     => 'enable_q_and_a_on_course',
										'type'    => 'toggle_single',
										'label'   => __( 'Q&A', 'tutor' ),
										'default' => 'on',
										'desc'    => __( 'Enable to add a Q&A section', 'tutor' ),
									),
									array(
										'key'         => 'enable_course_author',
										'type'        => 'toggle_single',
										'label'       => __( 'Author', 'tutor' ),
										'label_title' => __( 'Enable', 'tutor' ),
										'default'     => 'off',
										'desc'        => __( 'Enable to show course author name', 'tutor' ),
									),
									array(
										'key'         => 'enable_course_level',
										'type'        => 'toggle_single',
										'label'       => __( 'Level', 'tutor' ),
										'label_title' => __( 'Enable', 'tutor' ),
										'default'     => 'on',
										'desc'        => __( 'Enable to show course level', 'tutor' ),
									),
									array(
										'key'         => 'enable_course_share',
										'type'        => 'toggle_single',
										'label'       => __( 'Social Share', 'tutor' ),
										'label_title' => __( 'Enable', 'tutor' ),
										'default'     => 'on',
										'desc'        => __( 'Toggle to enable course social share', 'tutor' ),
									),
									array(
										'key'         => 'enable_course_duration',
										'type'        => 'toggle_single',
										'label'       => __( 'Duration', 'tutor' ),
										'label_title' => __( 'Disable', 'tutor' ),
										'default'     => 'on',
										'desc'        => __( 'Enable to show course duration', 'tutor' ),
									),
									array(
										'key'         => 'enable_course_total_enrolled',
										'type'        => 'toggle_single',
										'label'       => __( 'Total Enrolled', 'tutor' ),
										'label_title' => __( 'Enable', 'tutor' ),
										'default'     => 'on',
										'desc'        => __( 'Enable to show total enrolled students', 'tutor' ),
									),
									array(
										'key'         => 'enable_course_update_date',
										'type'        => 'toggle_single',
										'label'       => __( 'Update Date', 'tutor' ),
										'label_title' => __( 'Enable', 'tutor' ),
										'default'     => 'on',
										'desc'        => __( 'Enable to show course update information', 'tutor' ),
									),
									array(
										'key'         => 'enable_course_progress_bar',
										'type'        => 'toggle_single',
										'label'       => __( 'Progress Bar', 'tutor' ),
										'label_title' => __( 'Enable', 'tutor' ),
										'default'     => 'on',
										'desc'        => __( 'Enable to show course progress for Students', 'tutor' ),
									),
									array(
										'key'         => 'enable_course_material',
										'type'        => 'toggle_single',
										'label'       => __( 'Material', 'tutor' ),
										'label_title' => __( 'Enable', 'tutor' ),
										'default'     => 'on',
										'desc'        => __( 'Enable to show course materials', 'tutor' ),
									),
									array(
										'key'         => 'enable_course_about',
										'type'        => 'toggle_single',
										'label'       => __( 'About', 'tutor' ),
										'label_title' => __( 'Enable', 'tutor' ),
										'default'     => 'on',
										'desc'        => __( 'Enable to show course about section', 'tutor' ),
									),
									array(
										'key'         => 'enable_course_description',
										'type'        => 'toggle_single',
										'label'       => __( 'Description', 'tutor' ),
										'label_title' => __( 'Enable', 'tutor' ),
										'default'     => 'on',
										'desc'        => __( 'Enable to show course description', 'tutor' ),
									),
									array(
										'key'         => 'enable_course_benefits',
										'type'        => 'toggle_single',
										'label'       => __( 'Benefits', 'tutor' ),
										'label_title' => __( 'Enable', 'tutor' ),
										'default'     => 'on',
										'desc'        => __( 'Enable to show course benefits section', 'tutor' ),
									),
									array(
										'key'         => 'enable_course_requirements',
										'type'        => 'toggle_single',
										'label'       => __( 'Requirements', 'tutor' ),
										'label_title' => __( 'Enable', 'tutor' ),
										'default'     => 'on',
										'desc'        => __( 'Enable to show courses requirements section', 'tutor' ),
									),
									array(
										'key'         => 'enable_course_target_audience',
										'type'        => 'toggle_single',
										'label'       => __( 'Target Audience', 'tutor' ),
										'label_title' => __( 'Disable', 'tutor' ),
										'default'     => 'on',
										'desc'        => __( 'Enable to show course target audience section', 'tutor' ),
									),
									array(
										'key'         => 'enable_course_announcements',
										'type'        => 'toggle_single',
										'label'       => __( 'Announcements', 'tutor' ),
										'label_title' => __( 'Enable', 'tutor' ),
										'default'     => 'on',
										'desc'        => __( 'Enable to show course announcements section', 'tutor' ),
									),
									array(
										'key'         => 'enable_course_review',
										'type'        => 'toggle_single',
										'label'       => __( 'Review', 'tutor' ),
										'label_title' => __( 'Enable', 'tutor' ),
										'default'     => 'on',
										'desc'        => __( 'Enable to show course review section', 'tutor' ),
									),
								),
							),
						),
					),
				),
			),
			'advanced'       => array(
				'label'    => __( 'Advanced', 'tutor' ),
				'slug'     => 'advanced',
				'desc'     => __( 'Advanced Settings', 'tutor' ),
				'template' => 'basic',
				'icon'     => 'tutor-icon-filter',
				'blocks'   => array(
					array(
						'label'      => __( 'Course', 'tutor' ),
						'slug'       => 'options',
						'block_type' => 'uniform',
						'fields'     => array(
							array(
								'key'     => 'enable_gutenberg_course_edit',
								'type'    => 'toggle_switch',
								'label'   => __( 'Gutenberg Editor', 'tutor' ),
								'default' => 'off',
								'desc'    => __( 'Enable this to create courses using the Gutenberg Editor.', 'tutor' ),
							),
							array(
								'key'     => 'hide_course_from_shop_page',
								'type'    => 'toggle_switch',
								'label'   => __( 'Hide Course Products on Shop Page', 'tutor' ),
								'default' => 'off',
								'desc'    => __( 'Enable to hide course products on shop page.', 'tutor' ),
							),
							array(
								'key'        => 'course_archive_page',
								'type'       => 'select',
								'label'      => __( 'Course Archive Page', 'tutor' ),
								'default'    => $course_archive_page_id->ID ?? '0',
								'options'    => $pages,
								'desc'       => __( 'This page will be used to list all the published courses.', 'tutor' ),
								'searchable' => true,
							),
							array(
								'key'        => 'instructor_register_page',
								'type'       => 'select',
								'label'      => __( 'Instructor Registration Page', 'tutor' ),
								'default'    => '0',
								'options'    => $pages,
								'desc'       => __( 'Choose the page for instructor registration.', 'tutor' ),
								'searchable' => true,
							),
							array(
								'key'        => 'student_register_page',
								'type'       => 'select',
								'label'      => __( 'Student Registration Page', 'tutor' ),
								'default'    => '0',
								'options'    => $pages,
								'desc'       => __( 'Choose the page for student registration.', 'tutor' ),
								'searchable' => true,
							),
							array(
								'key'         => 'lesson_video_duration_youtube_api_key',
								'type'        => 'text',
								'label'       => __( 'YouTube API Key', 'tutor' ),
								'default'     => '',
								'desc'        => __(
									'Connect your YouTube API key to access additional features',
									'tutor'
								),
								'placeholder' => __( 'Enter your YouTube API key', 'tutor' ),
							),
						),
					),
					array(
						'label'      => __( 'Base Permalink', 'tutor' ),
						'slug'       => 'base_permalink',
						'block_type' => 'uniform',
						'fields'     => array(
							array(
								'key'     => 'course_permalink_base',
								'type'    => 'text',
								'label'   => __( 'Course Permalink', 'tutor' ),
								'default' => 'courses',
								'desc'    => $course_url,
							),
							array(
								'key'     => 'lesson_permalink_base',
								'type'    => 'text',
								'label'   => __( 'Lesson Permalink', 'tutor' ),
								'default' => 'lessons',
								'desc'    => $lesson_url,
							),
							array(
								'key'     => 'quiz_permalink_base',
								'type'    => 'text',
								'label'   => __( 'Quiz Permalink', 'tutor' ),
								'default' => 'quizzes',
								'desc'    => $quiz_url,
							),
						),
					),
					array(
						'label'      => __( 'Options', 'tutor' ),
						'slug'       => 'options',
						'block_type' => 'uniform',
						'fields'     => array(
							array(
								'key'         => 'enable_profile_completion',
								'type'        => 'toggle_switch',
								'label'       => __( 'Profile Completion', 'tutor' ),
								'label_title' => '',
								'default'     => 'off',
								'desc'        => __( 'Enabling this feature will show a notification bar to students and instructors to complete their profile information', 'tutor' ),
							),
							array(
								'key'         => 'enable_tutor_native_login',
								'type'        => 'toggle_switch',
								'label'       => __( 'Enable Tutor LMS Login', 'tutor' ),
								'label_title' => '',
								'default'     => 'on',
								'desc'        => __( 'Enable to use the Tutor LMS native login system instead of the WordPress login page', 'tutor' ),
							),
							array(
								'key'         => 'delete_on_uninstall',
								'type'        => 'toggle_switch',
								'label'       => __( 'Erase upon uninstallation', 'tutor' ),
								'label_title' => '',
								'default'     => 'off',
								'desc'        => __( 'Delete all data during uninstallation', 'tutor' ),
							),
							array(
								'key'         => 'enable_tutor_maintenance_mode',
								'type'        => 'toggle_switch',
								'label'       => __( 'Maintenance Mode', 'tutor' ),
								'label_title' => '',
								'default'     => 'off',
								'desc'        => __( 'Enabling maintenance mode will display a custom message on the frontend. During maintenance mode, visitors cannot access site content, but the wp-admin dashboard remains accessible.', 'tutor' ),
							),
						),
					),
				),
			),
			'legal_consents' => array(
				'label'    => __( 'Legal Consents', 'tutor' ),
				'slug'     => 'legal_consents',
				'desc'     => __( 'Legal Consents', 'tutor' ),
				'template' => 'legal_consents',
				'icon'     => 'tutor-icon-lesson',
				'blocks'   => array(
					array(
						'label'      => __( 'Legal Consents', 'tutor' ),
						'slug'       => 'legal_consents',
						'block_type' => 'uniform',
						'fields'     => array(
							array(
								'key'     => 'legal_consents',
								'type'    => 'text',
								'label'   => __( 'Legal Consents', 'tutor' ),
								'default' => array(),
							),
						),
					),
				),
			),
		);

		$attrs = apply_filters( 'tutor/options/extend/attr', apply_filters( 'tutor/options/attr', $attr ) );

		// Get the active tab.
		$tab_page = tutor_utils()->array_get( 'tab_page', $_REQUEST, 'general' );
		$tab_data = null;
		$template = null;

		foreach ( $attrs as $key => $section ) {
			if ( $tab_page == $key ) {
				if ( isset( $section['template_path'] ) && $section['template_path'] ) {
					$template = $section['template_path'];
					$tab_data = $section;
				}
				break;
			}
		}

		// Store in runtime cache.
		$this->setting_fields = array(
			'option_fields'   => $attrs,
			'active_tab'      => $tab_page,
			'active_tab_data' => $tab_data,
			'template_path'   => $template,
		);

		return $this->setting_fields;
	}

	/**
	 * Generate field
	 *
	 * @since 2.0.0
	 *
	 * @param array $field field array.
	 * @param array $blocks blocks array.
	 *
	 * @return void
	 *
	 * Generate Option Field
	 */
	public function generate_field( $field = array(), $blocks = array() ) {
		ob_start();
		if ( isset( $field['type'] ) ) {
			include tutor()->path . "views/options/field-types/{$field['type']}.php";
		}
		echo ob_get_clean();//phpcs:ignore
	}

	/**
	 * Include field type template & return buffered
	 * string data.
	 *
	 * @since 2.0.0
	 *
	 * @param array $field field.
	 *
	 * @return string
	 */
	public function field_type( $field = array() ) {
		ob_start();
		if ( isset( $field['type'] ) ) {
			include tutor()->path . "views/options/field-types/{$field['type']}.php";
		}
		return ob_get_clean();
	}

	/**
	 * Include Option blocks template & return
	 * buffered string data.
	 *
	 * @since 2.0.0
	 *
	 * @param array $blocks blocks.
	 *
	 * @return string
	 */
	public function blocks( $blocks = array() ) {
		ob_start();
		include apply_filters( 'tutor_settings_block_template_path', tutor()->path . 'views/options/option_blocks.php', $blocks );
		return ob_get_clean();
	}

	/**
	 * Include options template & returns
	 * buffered string data.
	 *
	 * @since 2.0.0
	 *
	 * @param array $section section.
	 *
	 * @return string
	 */
	public function template( $section = array() ) {
		ob_start();
		$blocks = $section['blocks'];
		if ( isset( $section['template'] ) ) {
			include apply_filters( 'tutor_option_template_path', tutor()->path . "views/options/template/{$section['template']}.php", $section['template'] );
		}
		return ob_get_clean();
	}


	/**
	 * Load template inside template directory
	 *
	 * @since 2.0.0
	 *
	 * @param  mixed $template_slug template slug.
	 * @param  mixed $section section.
	 *
	 * @return string
	 */
	public function view_template( $template_slug, $section = array() ) {
		ob_start();
		if ( isset( $template_slug ) ) {
			require tutor()->path . "views/options/template/{$template_slug}";
		}
		return ob_get_clean();
	}

	/**
	 * Get field name
	 *
	 * It's useful when a field has event key like course.lessons
	 *
	 * @since 3.5.0
	 *
	 * @param array $field Option field array.
	 *
	 * @return string
	 */
	public function get_field_name( array $field ) {
		$events     = $field['event'] ?? null;
		$field_name = 'tutor_option';
		if ( $events ) {
			$events = explode( '.', $events );
			foreach ( $events as $event ) {
				$field_name .= '[' . $event . ']';
			}
			$field_name .= '[' . $field['key'] . ']';
		} else {
			$field_name .= '[' . $field['key'] . ']';
		}

		return $field_name;
	}

	/**
	 * Json schema data
	 *
	 * @since 1.0.0
	 *
	 * @return array
	 */
	public function get_export_json_schema() {
		$export_data = array(
			'schema_version'   => '1.0.0',
			'exported_at'      => current_time( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ),
			'keep_media_files' => false,
			'keep_user_data'   => false,
			'data'             => array(),
		);

		return $export_data;
	}

	/**
	 * Update settings log based on the new data
	 *
	 * @since 3.6.0
	 *
	 * @param array  $new_settings_data New exported/import settings data.
	 * @param string $action_type Action type Imported/Exported.
	 *
	 * @return array Settings log data
	 */
	public function update_settings_log( $new_settings_data, $action_type ) {
		$get_final_data = array();

		$action = strtolower( $action_type );

		$time = tutor_time();

		$save_import_data['datetime']             = $time;
		$save_import_data['history_date']         = gmdate( 'j M, Y, g:i a', $time );
		$save_import_data['datatype']             = $action_type;
		$save_import_data['dataset']              = $new_settings_data;
		$import_data[ 'tutor-imported-' . $time ] = $save_import_data;

		$get_option_data = get_option( 'tutor_settings_log' );
		if ( empty( $get_option_data ) ) {
			$get_option_data = array();
		}
		if ( ! empty( $get_option_data ) && null !== $save_import_data['dataset'] ) {

			$update_option = array_merge( $import_data, $get_option_data );

			$update_option = Input::sanitize_array(
				$update_option,
				array(
					'payment_settings'          => 'wp_kses_post',
					'tutor_bank_transfer_withdraw_instruction' => 'sanitize_textarea_field',
					'certificate_showcase_desc' => 'sanitize_textarea_field',
					'invoice_from_address'      => 'sanitize_textarea_field',
					'fees_name'                 => 'sanitize_textarea_field',
				)
			);

			if ( ! empty( $update_option ) ) {
				update_option( 'tutor_settings_log', $update_option );
			}

			if ( 'imported' === $action ) {
				if ( ! empty( $save_import_data['dataset'] ) ) {
					update_option( 'tutor_option', $save_import_data['dataset'] );
				}
			}

			$get_final_data = get_option( 'tutor_settings_log' );

		} else {
			update_option( 'tutor_settings_log', $import_data );

			if ( 'imported' === $action ) {
				if ( ! empty( $save_import_data['dataset'] ) ) {
					update_option( 'tutor_option', $save_import_data['dataset'] );
				}
			}

			$get_final_data = get_option( 'tutor_settings_log' );
		}

		return $get_final_data;
	}
}
