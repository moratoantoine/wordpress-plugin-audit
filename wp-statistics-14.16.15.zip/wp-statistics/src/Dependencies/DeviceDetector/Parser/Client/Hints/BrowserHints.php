<?php

/**
 * Device Detector - The Universal Device Detection library for parsing User Agents
 *
 * @link https://matomo.org
 *
 * @license http://www.gnu.org/licenses/lgpl.html LGPL v3 or later
 */

declare(strict_types=1);

namespace WP_Statistics\Dependencies\DeviceDetector\Parser\Client\Hints;

use WP_Statistics\Dependencies\DeviceDetector\Parser\AbstractParser;

class BrowserHints extends AbstractParser
{
    /**
     * @var string
     */
    protected $fixtureFile = 'regexes/client/hints/browsers.yml';

    /**
     * @var string
     */
    protected $parserName = 'BrowserHints';

    /**
     * Get browser name if is in collection
     *
     * @return array|null
     */
    public function parse(): ?array
    {
        if (null === $this->clientHints) {
            return null;
        }

        $appId = $this->clientHints->getApp();
        $name  = $this->getRegexes()[$appId] ?? null;

        if ('' === (string) $name) {
            return null;
        }

        return [
            'name' => $name,
        ];
    }
}
