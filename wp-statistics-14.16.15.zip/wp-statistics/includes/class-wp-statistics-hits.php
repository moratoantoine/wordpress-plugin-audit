<?php

namespace WP_STATISTICS;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

use Exception;
use WP_Statistics\Components\Singleton;
use WP_Statistics\Service\Analytics\VisitorProfile;
use WP_Statistics\Service\Integrations\IntegrationHelper;
use WP_Statistics\Traits\ErrorLoggerTrait;

class Hits extends Singleton
{
    use ErrorLoggerTrait;

    /**
     * Rest-APi Hit Record Params Key
     *
     * @var string
     */
    public static $rest_hits_key = 'wp_statistics_hit';

    /**
     * Rest-Api Hit Data
     *
     * @var object
     */
    public $rest_hits;

    /**
     * WP_Statistics Hits Class.
     *
     * @throws Exception
     */
    public function __construct()
    {

        // Sanitize Hit Data if Has Rest-Api Process.
        //
        // The client-data filters are installed here, but whether the
        // client-supplied page identity is actually trusted is decided at record
        // time inside the filter callbacks (set_current_page / set_page_uri),
        // where the signature is verified. Deciding it here would be too early:
        // the constructor runs on plugins_loaded, before a theme/init-registered
        // wp_statistics_request_signature_enabled filter is in effect, so an
        // early signature check could wrongly discard a legitimate page.
        if (self::is_rest_hit()) {

            // Get Hit Data
            $this->rest_hits = (object)self::rest_params();

            // Filter Data
            add_filter('wp_statistics_current_page', array($this, 'set_current_page'));
            add_filter('wp_statistics_page_uri', array($this, 'set_page_uri'));
            add_filter('wp_statistics_user_id', array($this, 'set_current_user'));
        }

        // Record Login Page Hits
        if (!Option::get('exclude_loginpage')) {
            add_action('init', array($this, 'trackLoginPageCallback'));
        }

        // Server Side Tracking
        add_action('wp', array($this, 'trackServerSideCallback'));
    }

    /**
     * Set Current Page
     *
     * @param $current_page
     * @return array
     */
    public function set_current_page($current_page)
    {
        // Only trust client-supplied page identity when the request carries a
        // valid signature. Verified here, at record time, so a late-registered
        // wp_statistics_request_signature_enabled filter is honoured and an
        // unsigned/spoofed request cannot inject a page identity.
        if (!Helper::verifyHitSignature()) {
            return $current_page;
        }

        /**
         * Filter to resolve page type and ID from URL for SPA tracking.
         *
         * @param string $pageUri The page URI (decoded)
         */
        $pageUri  = (isset($this->rest_hits->page_uri) && is_string($this->rest_hits->page_uri)) ? sanitize_url(base64_decode($this->rest_hits->page_uri)) : '';
        $resolved = apply_filters('wp_statistics_resolve_page_from_uri', $pageUri);

        if (is_array($resolved) && isset($resolved['type']) && $resolved['type'] !== 'unknown') {
            return array(
                'type'         => esc_sql($resolved['type']),
                'id'           => esc_sql($resolved['id']),
                'search_query' => isset($resolved['search_query']) ? $resolved['search_query'] : ''
            );
        }

        // Default behavior - use client-provided values
        if (isset($this->rest_hits->source_type) and isset($this->rest_hits->source_id)) {
            return array(
                'type'         => esc_sql($this->rest_hits->source_type),
                'id'           => esc_sql($this->rest_hits->source_id),
                'search_query' => isset($this->rest_hits->search_query) ? base64_decode($this->rest_hits->search_query) : ''
            );
        }

        return $current_page;
    }

    /**
     * Set Page Uri
     *
     * @param $page_uri
     * @return string
     */
    public function set_page_uri($page_uri)
    {
        // Only trust the client-supplied page URI when the request is signed
        // (verified at record time, mirroring set_current_page).
        if (!Helper::verifyHitSignature()) {
            return $page_uri;
        }

        return (isset($this->rest_hits->page_uri) && is_string($this->rest_hits->page_uri)) ? sanitize_url(base64_decode($this->rest_hits->page_uri)) : $page_uri;
    }

    /**
     * Set User ID
     *
     * @param $userId
     * @return mixed
     */
    public function set_current_user($userId)
    {
        $userIdFromGlobalVar = isset($GLOBALS['wp_statistics_user_id']) ? $GLOBALS['wp_statistics_user_id'] : 0;

        if (!$userId && $userIdFromGlobalVar) {
            $userId = $userIdFromGlobalVar;
        }

        return $userId;
    }

    /**
     * Check If Record Hits in Rest-Api Request
     *
     * @return bool
     */
    public static function is_rest_hit()
    {
        return (Helper::is_rest_request() and isset($_REQUEST[self::$rest_hits_key]));
    }

    /**
     * Get Params Value in Rest-APi Request Hit
     *
     * @param $params
     * @return Mixed
     */
    public static function rest_params($params = false)
    {
        $data = array();
        if (Helper::is_rest_request() and isset($_REQUEST[Hits::$rest_hits_key])) {
            foreach ($_REQUEST as $key => $value) {
                $data[$key] = $value;
            }

            return ($params === false ? $data : (isset($data[$params]) ? $data[$params] : false));
        }

        return $data;
    }

    /**
     * Record the visitor
     *
     * @throws Exception
     */
    public static function record($visitorProfile = null)
    {
        if (!$visitorProfile) {
            $visitorProfile = new VisitorProfile();
        }

        /**
         * Check the exclusion
         */
        $exclusion = Exclusion::check($visitorProfile);

        /**
         * Record exclusion if needed & then skip the tracking
         */
        if ($exclusion['exclusion_match'] === true) {
            Exclusion::record($exclusion);
            self::errorListener();

            // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- internal exception, message is not rendered to HTML
            throw new Exception($exclusion['exclusion_reason'], 200);
        }

        /**
         * Record Pages
         */
        $pageId = false;
        if (Pages::active()) {
            $pageId = Pages::record($visitorProfile);
        }

        /**
         * Record Visitor Detail
         */
        $visitorId = false;
        if (Visitor::active()) {
            $visitorId = Visitor::record($visitorProfile, ['page_id' => $pageId]);
        }

        /**
         * Record Visitor Relationship
         */
        if ($visitorId && $pageId) {
            Visitor::save_visitors_relationships($pageId, $visitorId);
        }

        self::errorListener();

        return $exclusion;
    }

    /**
     * Record Hits in Login Page
     *
     * @throws Exception
     */
    public static function trackLoginPageCallback()
    {
        if (Helper::is_login_page()) {
            try {
                self::record();
            } catch (Exception $e) {
                self::errorListener();
            }
        }
    }

    /**
     * Server-Side Tracking Callback
     *
     * @throws Exception
     */
    public static function trackServerSideCallback()
    {
        try {
            if (is_favicon() || is_admin() || is_preview() || Option::get('use_cache_plugin') || Helper::dntEnabled()) {
                return;
            }

            $isConsentGiven     = IntegrationHelper::isConsentGiven();
            $trackAnonymously   = IntegrationHelper::shouldTrackAnonymously();

            if ($isConsentGiven || $trackAnonymously) {
                self::record();
            }

        } catch (Exception $e) {
            self::errorListener();
        }
    }
}

Hits::instance();