<?php
/**
 * File containing the class WP_Job_Manager_Email_Admin_Updated_Job.
 *
 * @package wp-job-manager
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Email notification to administrator when a job is updated.
 *
 * @since 1.31.0
 * @extends WP_Job_Manager_Email
 */
class WP_Job_Manager_Email_Admin_Updated_Job extends WP_Job_Manager_Email_Template {
	/**
	 * Get the unique email notification key.
	 *
	 * @return string
	 */
	public static function get_key() {
		return 'admin_updated_job';
	}

	/**
	 * Get the friendly name for this email notification.
	 *
	 * @return string
	 */
	public static function get_name() {
		return __( 'Admin Notice of Updated Listing', 'wp-job-manager' );
	}

	/**
	 * Get the description for this email notification.
	 *
	 * @type abstract
	 * @return string
	 */
	public static function get_description() {
		return __( 'Send a notice to the site administrator when a job is updated on the frontend.', 'wp-job-manager' );
	}

	/**
	 * Get the email subject.
	 *
	 * @return string
	 */
	public function get_subject() {
		$args = $this->get_args();

		/**
		 * Job listing post object.
		 *
		 * @var WP_Post $job
		 */
		$job = $args['job'];

		// `post_title` holds HTML entities when the submitter lacks `unfiltered_html`; the subject is plain text.
		$job_title = wp_specialchars_decode( $job->post_title, ENT_QUOTES );

		// translators: Placeholder %s is the job listing post title.
		return sprintf( __( 'Job Listing Updated: %s', 'wp-job-manager' ), $job_title );
	}

	/**
	 * Get `From:` address header value. Can be simple email or formatted `Firstname Lastname <email@example.com>`.
	 *
	 * @return string|bool Email from value or false to use WordPress' default.
	 */
	public function get_from() {
		return false;
	}

	/**
	 * Get array or comma-separated list of email addresses to send message.
	 *
	 * @return string|array
	 */
	public function get_to() {
		$option = get_option( 'job_manager_email_admin_updated_job', false );
		return $option['email_to'] ? $option['email_to'] : get_option( 'admin_email', false );
	}

	/**
	 * Checks the arguments and returns whether the email notification is properly set up.
	 *
	 * @return bool
	 */
	public function is_valid() {
		$args = $this->get_args();
		return isset( $args['job'] )
				&& $args['job'] instanceof WP_Post
				&& $this->get_to();
	}
}
