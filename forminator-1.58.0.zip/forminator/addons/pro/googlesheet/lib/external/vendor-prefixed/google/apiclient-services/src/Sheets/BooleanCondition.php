<?php

/*
 * Copyright 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
namespace ForminatorGoogleAddon\Google\Service\Sheets;

class BooleanCondition extends \ForminatorGoogleAddon\Google\Collection
{
    protected $collection_key = 'values';
    /**
     * @var string
     */
    public $type;
    protected $valuesType = ConditionValue::class;
    protected $valuesDataType = 'array';
    /**
     * @param string
     */
    public function setType($type)
    {
        $this->type = $type;
    }
    /**
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }
    /**
     * @param ConditionValue[]
     */
    public function setValues($values)
    {
        $this->values = $values;
    }
    /**
     * @return ConditionValue[]
     */
    public function getValues()
    {
        return $this->values;
    }
}
// Adding a class alias for backwards compatibility with the previous class name.
\class_alias(BooleanCondition::class, 'ForminatorGoogleAddon\\Google_Service_Sheets_BooleanCondition');
