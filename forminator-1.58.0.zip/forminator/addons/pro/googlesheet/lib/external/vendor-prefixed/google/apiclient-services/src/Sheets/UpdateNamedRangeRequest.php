<?php

/*
 * Copyright 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
namespace ForminatorGoogleAddon\Google\Service\Sheets;

class UpdateNamedRangeRequest extends \ForminatorGoogleAddon\Google\Model
{
    /**
     * @var string
     */
    public $fields;
    protected $namedRangeType = NamedRange::class;
    protected $namedRangeDataType = '';
    /**
     * @param string
     */
    public function setFields($fields)
    {
        $this->fields = $fields;
    }
    /**
     * @return string
     */
    public function getFields()
    {
        return $this->fields;
    }
    /**
     * @param NamedRange
     */
    public function setNamedRange(NamedRange $namedRange)
    {
        $this->namedRange = $namedRange;
    }
    /**
     * @return NamedRange
     */
    public function getNamedRange()
    {
        return $this->namedRange;
    }
}
// Adding a class alias for backwards compatibility with the previous class name.
\class_alias(UpdateNamedRangeRequest::class, 'ForminatorGoogleAddon\\Google_Service_Sheets_UpdateNamedRangeRequest');
