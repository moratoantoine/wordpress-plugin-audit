<?php if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Class NF_Fields_Phone
 */
class NF_Fields_Phone extends NF_Fields_Textbox
{
    protected $_name = 'phone';

    protected $_nicename = 'Phone';

    protected $_section = 'userinfo';

    protected $_icon = 'phone';

    protected $_type = 'textbox';

    protected $_templates = 'tel';

    protected $_settings_exclude = array( 'custom_autocomplete' );

    public function __construct()
    {
        parent::__construct();

        $this->_nicename = esc_html__( 'Phone', 'ninja-forms' );

	    $this->_settings[ 'custom_name_attribute' ][ 'value' ] = 'phone';
	    $this->_settings[ 'personally_identifiable' ][ 'value' ] = '1';
    }
}
