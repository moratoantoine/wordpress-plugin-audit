<?php

namespace WPForms\Admin\Education;

/**
 * Helpers class.
 *
 * @since 1.8.5
 */
class Helpers {

	/**
	 * Field types a visitor does not fill in.
	 *
	 * @since 2.0.1
	 *
	 * @var array
	 */
	private const NON_FILLABLE_FIELD_TYPES = [ 'pagebreak', 'divider', 'html', 'hidden', 'captcha', 'layout', 'repeater', 'content', 'internal-information', 'entry-preview' ];

	/**
	 * Get badge HTML.
	 *
	 * @since 1.8.5
	 * @since 1.8.6 Added `$icon` parameter.
	 *
	 * @param string $text     Badge text.
	 * @param string $size     Badge size.
	 * @param string $position Badge position.
	 * @param string $color    Badge color.
	 * @param string $shape    Badge shape.
	 * @param string $icon     Badge icon name in Font Awesome "format", e.g. `fa-check`, defaults to empty string.
	 *
	 * @return string
	 */
	public static function get_badge(
		string $text,
		string $size = 'sm',
		string $position = 'inline',
		string $color = 'titanium',
		string $shape = 'rounded',
		string $icon = ''
	): string {

		if ( ! empty( $icon ) ) {
			$icon = self::get_inline_icon( $icon );
		}

		return sprintf(
			'<span class="wpforms-badge wpforms-badge-%1$s wpforms-badge-%2$s wpforms-badge-%3$s wpforms-badge-%4$s">%5$s%6$s</span>',
			esc_attr( $size ),
			esc_attr( $position ),
			esc_attr( $color ),
			esc_attr( $shape ),
			wp_kses(
				$icon,
				[
					'i' => [
						'class'       => [],
						'aria-hidden' => [],
					],
				]
			),
			esc_html( $text )
		);
	}

	/**
	 * Print badge HTML.
	 *
	 * @since 1.8.5
	 * @since 1.8.6 Added `$icon` parameter.
	 *
	 * @param string $text     Badge text.
	 * @param string $size     Badge size.
	 * @param string $position Badge position.
	 * @param string $color    Badge color.
	 * @param string $shape    Badge shape.
	 * @param string $icon     Badge icon name in Font Awesome "format", e.g. `fa-check`, defaults to empty string.
	 */
	public static function print_badge(
		string $text,
		string $size = 'sm',
		string $position = 'inline',
		string $color = 'titanium',
		string $shape = 'rounded',
		string $icon = ''
	) {

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo self::get_badge( $text, $size, $position, $color, $shape, $icon );
	}

	/**
	 * Get addon badge HTML.
	 *
	 * @since 1.8.9
	 *
	 * @param array $addon Addon data.
	 *
	 * @return string
	 */
	public static function get_addon_badge( array $addon ): string {

		// List of possible badges.
		$badges = [
			'recommended' => [
				'text'  => esc_html__( 'Recommended', 'wpforms-lite' ),
				'color' => 'green',
				'icon'  => 'fa-star',
			],
			'new'         => [
				'text'  => esc_html__( 'New', 'wpforms-lite' ),
				'color' => 'blue',
			],
			'featured'    => [
				'text'  => esc_html__( 'Featured', 'wpforms-lite' ),
				'color' => 'orange',
			],
		];

		$badge = [];

		// Get first badge that exists.
		foreach ( $badges as $key => $value ) {
			if ( ! empty( $addon[ $key ] ) ) {
				$badge = $value;

				break;
			}
		}

		if ( empty( $badge ) ) {
			return '';
		}

		return self::get_badge( $badge['text'], 'sm', 'inline', $badge['color'], 'rounded', $badge['icon'] ?? '' );
	}

	/**
	 * Get inline icon HTML.
	 *
	 * @since 1.8.6
	 *
	 * @param string $name Font Awesome icon name, e.g. `fa-check`.
	 *
	 * @return string HTML markup for the icon element.
	 */
	public static function get_inline_icon( string $name ): string {

		return sprintf( '<i class="fa %1$s" aria-hidden="true"></i>', esc_attr( $name ) );
	}

	/**
	 * Get available education addons.
	 *
	 * @since 1.9.4
	 *
	 * @return array
	 */
	public static function get_edu_addons(): array {

		static $addons = null;

		if ( $addons !== null ) {
			return $addons;
		}

		$addons_obj = wpforms()->obj( 'addons' );

		if ( ! $addons_obj ) {
			$addons = [];

			return $addons;
		}

		$addons = $addons_obj->get_available();

		return $addons;
	}

	/**
	 * Count form fields a visitor actually fills in.
	 *
	 * @since 2.0.1
	 *
	 * @param array $form_data Form data and settings.
	 *
	 * @return int
	 */
	public static function count_fillable_fields( array $form_data ): int {

		$count = 0;

		foreach ( (array) ( $form_data['fields'] ?? [] ) as $field ) {
			if ( ! in_array( $field['type'] ?? '', self::NON_FILLABLE_FIELD_TYPES, true ) ) {
				++$count;
			}
		}

		return $count;
	}

	/**
	 * Whether the current user has dismissed the education section.
	 *
	 * @since 2.0.1
	 *
	 * @param string $section Education dismissal section slug.
	 *
	 * @return bool
	 */
	public static function is_dismissed( string $section ): bool {

		$dismissed = (array) get_user_meta( get_current_user_id(), 'wpforms_dismissed', true );

		return ! empty( $dismissed[ 'edu-' . $section ] );
	}

	/**
	 * Get the data-processing disclosure shown before an addon is installed or activated.
	 *
	 * An addon that sends site data to WPForms services is not running when its install or
	 * activate modal opens, so the disclosure has to live here in core. The modal shows it in a
	 * footer below its buttons, so the site owner learns where the processing happens before
	 * opting in.
	 *
	 * @since 2.0.2.2
	 *
	 * @param string $slug Addon slug, e.g. `wpforms-pdf`.
	 *
	 * @return string Paragraph HTML, or an empty string when the addon has no disclosure.
	 */
	public static function get_addon_disclosure( string $slug ): string {

		$disclosures = [
			'wpforms-pdf' => sprintf(
				'<p>%1$s <a href="%2$s" target="_blank" rel="noopener noreferrer">%3$s</a></p>',
				esc_html__( 'PDFs are generated on WPForms\' servers in the United States. Your form entry data is sent there to create each PDF and is not stored after rendering.', 'wpforms-lite' ),
				esc_url( wpforms_utm_link( 'https://wpforms.com/docs/pdf-addon/#data-processing', 'Builder Settings', 'PDF Remote Processing Disclosure' ) ),
				esc_html__( 'Learn More', 'wpforms-lite' )
			),
		];

		return $disclosures[ $slug ] ?? '';
	}
}
