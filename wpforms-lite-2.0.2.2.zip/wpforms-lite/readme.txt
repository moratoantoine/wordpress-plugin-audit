=== WPForms - AI Form Builder for WordPress - Contact Forms, Payment Forms, Survey Form, Quiz & More ===
Contributors: wpforms, smub, slaFFik
Tags: contact form, contact form plugin, forms, form builder, custom form
Requires at least: 5.5
Tested up to: 7.1
Stable tag: 2.0.2.2
Requires PHP: 7.2
License: GNU General Public License v2.0 or later

The best WordPress contact form plugin. Drag & Drop form builder to create beautiful contact forms, payment forms, & other custom forms. 7000+ integrations including Stripe and more.



== Description ==

= WordPress Contact Form Builder Plugin =

[WPForms](https://wpforms.com/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) is an AI drag & drop WordPress form builder that's EASY and POWERFUL. Create contact forms, feedback forms, subscription forms, payment forms (including Stripe, Square & PayPal), and other types of forms for your site in minutes with just a few clicks!

At WPForms, user experience is our #1 priority. Our pre-built form templates and workflows make WPForms the most beginner-friendly contact form plugin on the market. You don't have to hire a developer. Create a form in less than 5 minutes with our drag & drop form builder, using a template or just asking AI to get a head start.

> <strong>WPForms Pro</strong><br />
> This plugin is the Lite version of WPForms Pro, which comes with email subscription forms, multi-page contact forms, file uploads, conditional logic, and extra payment integrations. [Click here to purchase the best premium WordPress contact form plugin now!](https://wpforms.com/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)

https://player.vimeo.com/video/1180577946

= AI-Powered Drag & Drop Contact Form Builder =

Create custom contact forms in minutes with our easy-to-use [drag and drop online form builder](https://wpforms.com/features/drag-drop-online-form-builder/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) or just ask AI to build it for you. But don't just take our word for it. See what WordPress experts are saying:

> WPForms is by far the <strong>easiest form plugin to use</strong>. My clients love WPForms and it's one of the few plugins they can use without any training. As a developer I appreciate how fast, modern, clean and extensible it is.<br>
> Bill Erickson - Expert WordPress Consultant

= Pre-built Form Templates =

WPForms comes with [2100+ pre-built form templates](https://wpforms.com/templates/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin).

Whether you're looking to create a simple contact form, marketing form, request a quote form, donation form, payment order form, registration form, survey form, quiz form, Stripe payment form, or a subscription form, we have a form template already prepared and ready to use.

= Mobile Ready, SEO Friendly, and Optimized for Speed =

WPForms contact forms are 100% responsive and mobile-friendly. We optimized every query on the frontend and the backend to ensure that it's one of the fastest WordPress contact form plugins.

You can embed your contact form on any page with an optimized title and description, so WPForms is one of the most SEO friendly contact form plugins too.

= Fields & Features You Need to Succeed =

With star ratings, file uploads, repeater fields, survey fields, and multi-page contact forms, you can easily build the right custom form for your site's needs. Plus, integrate your contact forms with an email marketing service in just a few steps and collect payments with Stripe, PayPal, and Square for bookings and orders without the need for a dedicated eCommerce plugin.

See what one business owner has to say about their WPForms contact form:

>As a business owner, time is my most valuable asset. WPForms allows me to create smart contact forms with just a few clicks. With their pre-built form templates and the drag & drop builder, I can create a new form that works in less than 2 minutes without writing a single line of code. Well worth the investment.<br>
> David Henzel - Co-founder of MaxCDN

= Surveys & Polls =

Create custom survey forms like Survey Monkey. Our [WordPress survey plugin addon](https://wpforms.com/features/surveys-and-polls-addon?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) comes with smart survey fields including Likert scale, star ratings, and NPS. Embed your surveys and polls anywhere in WordPress.

Use our survey reporting tools to customize graphs, export them for presentations, and display aggregate results. You can also share poll results instantly when collecting votes.

= Default WordPress Forms =

Aside from building simple contact forms, WPForms also helps you create better default WordPress forms, like custom WordPress login forms and custom WordPress user registration forms. Create a password-protected contact form or even a members-only contact form.

Bloggers and publishers can use our WordPress post submission forms to accept guest posts, testimonials, and more.

= Payment Forms, Donation Forms, Booking Forms, and More =

While WPForms started out as a contact form plugin, it has evolved into a powerful custom forms solution for any type of payment or booking form.

WPForms integrates with PayPal, Stripe, Square Payments, Authorize.Net, and Mercado Pago so you can easily accept credit card payments or take payments via PayPal. Bonus: you can also take signatures.

We're proud to be a Stripe Verified Partner. This partnership allows us to build the best Stripe integration with early access to features. You can use our Stripe integration to accept both one-time payments as well as recurring payments while syncing all form data to your Stripe account.

= Custom Calculator Forms =

Using the [WPForms Calculations addon](https://wpforms.com/features/calculations-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin), you can build custom formulas and display results on the frontend.

Create simple arithmetic calculations or build complex conditional calculations with rounded values, averages, time ranges, and more! It's the best calculator plugin for WordPress.

= Forms Optimized for Conversions =

With our Form Pages addon, you can create distraction-free custom form landing pages to increase conversions.

To improve form completion rates, we created Conversational Forms which helps you make your feedback forms feel more human by adding an interactive layout. ([See Conversational Forms Demo](https://wpforms.com/features/conversational-forms-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)).

= Easy to Customize and Extend =

You can easily customize your contact forms with our section dividers, HTML blocks, and CSS. Embedding forms in Elementor and Divi has never been easier thanks to our native integrations.

We also know that our developer friends may want more control, so we added tons of hooks and filters.

= Full WPForms Feature List =

* [Online form builder](https://wpforms.com/features/drag-drop-online-form-builder/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) - powerful drag & drop contact form builder. Create WordPress contact forms, payment forms, and other online forms without writing any code.
* 100% mobile responsive.
* GDPR friendly.
* Payment Forms - Take payments, donations, down payments, recurring payments, service payments with our Stripe (FREE) integration.
* [Form templates](https://wpforms.com/templates/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) pre-built and ready to import.
* [Form styling](https://wpforms.com/docs/styling-your-forms/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) for fields, labels, and buttons.
* [Spam protection](https://wpforms.com/features/spam-protection/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) built in, plus integrations with hCaptcha, Google reCAPTCHA, and Cloudflare Turnstile.
* [AI Forms](https://wpforms.com/features/wpforms-ai/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to automatically create and refine forms through natural conversation.
* [Instant form notifications](https://wpforms.com/features/instant-notifications/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) via email.
* [Custom form confirmations](https://wpforms.com/features/form-confirmation/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) with success messages or thank you pages.
* [Smart phone field](https://wpforms.com/docs/how-to-choose-the-right-form-field-for-your-forms/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin#phone) that adapts to your visitor's location.
* [AI Choices](https://wpforms.com/features/wpforms-ai/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to automatically populate Multiple Choice, Checkboxes, and Dropdown field options.
* [Coupons](https://wpforms.com/features/coupons-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) for free shipping and sale discounts.
* [Calculator forms](https://wpforms.com/features/calculations-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) for payment, shipping, billing, and more.
* [File upload fields](https://wpforms.com/features/file-uploads/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) for user submissions.
* [Multi-page forms](https://wpforms.com/features/multi-page-forms/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) with progress bars.
* [Smart conditional logic](https://wpforms.com/features/conditional-logic/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to show or hide fields.
* [Repeater field](https://wpforms.com/features/repeater-field/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) that enables the person filling out the form to easily add another field or group of fields to fill out. Perfect for group registration forms, custom order forms, and more.
* [Signatures](https://wpforms.com/features/digital-signatures/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) for agreements or payment forms.
* [User registration forms](https://wpforms.com/features/user-registration/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) and custom login forms.
* [Post submission forms](https://wpforms.com/features/post-submissions/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to collect user-generated content.
* [Geolocation](https://wpforms.com/features/geolocation-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to collect location data along with submissions.
* [Surveys and Polls](https://wpforms.com/features/surveys-and-polls-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) with interactive reports.
* [Quizzes](https://wpforms.com/features/quiz-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) with graded tests, personality quizzes, and scored assessments, plus AI-generated questions.
* [Form abandonment detection](https://wpforms.com/features/form-abandonment/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to collect partial form submissions.
* [Form locker](https://wpforms.com/features/form-locker-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to control access using passwords, dates, and more.
* [Offline forms](https://wpforms.com/features/offline-forms-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to collect submissions without an internet connection.
* [Form landing pages](https://wpforms.com/features/form-pages-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to boost conversions.
* [Conversational forms](https://wpforms.com/features/conversational-forms-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to boost overall completion rates.
* [Lead forms](https://wpforms.com/features/lead-forms-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to get more submissions with multi-step layouts.
* [Webhooks](https://wpforms.com/features/webhooks-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to send data without third party connectors.
* [User Journey reports](https://wpforms.com/features/user-journey-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) so you know which content is driving form conversions.
* [Save and Resume](https://wpforms.com/features/save-and-resume-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to let visitors save and come back later.
* [Entry Automation](https://wpforms.com/features/entry-automation-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) to export and delete form entries on a daily, weekly, or monthly basis.

= Integrations =

* [Google Sheets](https://wpforms.com/features/google-sheets-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Zapier](https://wpforms.com/features/zapier-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [PayPal Commerce](https://wpforms.com/features/paypal-commerce/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Stripe](https://wpforms.com/features/stripe-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) - We're a Stripe Verified Partner for Payments.
* [Square](https://wpforms.com/features/square-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Authorize.Net](https://wpforms.com/features/authorize-net-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Mercado Pago](https://wpforms.com/features/mercado-pago-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Mailchimp](https://wpforms.com/features/mailchimp-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [AWeber](https://wpforms.com/features/aweber-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Campaign Monitor](https://wpforms.com/features/campaign-monitor-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [GetResponse](https://wpforms.com/features/getresponse-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Constant Contact](https://wpforms.com/features/constant-contact/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Airtable](https://wpforms.com/features/airtable-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Notion](https://wpforms.com/features/notion-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Drip](https://wpforms.com/features/drip-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [ActiveCampaign](https://wpforms.com/features/activecampaign-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [HubSpot](https://wpforms.com/features/hubspot-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Brevo](https://wpforms.com/features/brevo-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [MailerLite](https://wpforms.com/features/mailerlite-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [MailPoet](https://wpforms.com/features/mailpoet-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [ConvertKit](https://wpforms.com/features/convertkit-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Klaviyo](https://wpforms.com/features/klaviyo-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [SendGrid](https://wpforms.com/features/sendgrid-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Salesforce](https://wpforms.com/features/salesforce-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Slack](https://wpforms.com/features/slack-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Dropbox](https://wpforms.com/features/dropbox-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Google Calendar](https://wpforms.com/features/google-calendar-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Google Drive](https://wpforms.com/features/google-drive-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Twilio](https://wpforms.com/features/twilio-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Pipedrive](https://wpforms.com/features/pipedrive-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Make](https://wpforms.com/features/make-addon/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)
* [Zoho CRM](https://wpforms.com/features/zoho-crm-addon//?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)

You can see why WPForms is the best WordPress contact form plugin on the market! Want to unlock these features? [Upgrade to our Pro version](https://wpforms.com/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin).

= Credits =

This plugin is created by [Syed Balkhi](https://syedbalkhi.com/).

= Branding Guidelines =

WPForms&reg; is a registered trademark of WPForms LLC. When writing about the contact form plugin by WPForms, please make sure to uppercase the initial 3 letters.

* WPForms (correct)
* WP Forms (incorrect)
* wpforms (incorrect)
* wpform (incorrect)

== Installation ==

1. Install WPForms Lite either via the WordPress.org plugin repository or by uploading the files to your server. (See instructions on [how to install a WordPress plugin](https://www.wpbeginner.com/beginners-guide/step-by-step-guide-to-install-a-wordpress-plugin-for-beginners))
2. Activate WPForms Lite.
3. Navigate to the WPForms tab at the bottom of your admin menu and click the "Add New" button to begin creating your new WordPress contact form.
4. Want more features? [Purchase the full version of WPForms](https://wpforms.com/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin)!

== Screenshots ==

1. WPForms Drag & Drop Form Builder
2. Adding New Fields
3. Generate choices using AI
4. Form Templates
5. WPForms Block With Style Options
6. Payments Overview
7. Single Payment
8. Form Preview
9. Form Pages with Multiple Styles
10. Conversational Form

== Frequently Asked Questions ==

= Who should use WPForms? =

WPForms is perfect for business owners, bloggers, designers, developers, photographers, and basically everyone else. If you want to create a custom WordPress form, then you need to use the WPForms drag & drop form builder.

= Do I need to have coding skills to use WPForms? =

Absolutely not. You can create and manage forms without any coding knowledge (100% drag & drop form builder). WPForms is the most beginner-friendly contact form plugin on the market.

= What type of WordPress forms can I build with WPForms? =

WPForms drag & drop form builder combined with our addons is the most powerful WordPress contact form plugin on the market. Here are some types of WordPress forms you can create:

* Simple Contact Forms
* Job Application Contact Form
* Feedback Survey Contact Form
* Make a Suggestion Contact Form
* Change Request Forms
* Online Booking Forms
* Event Booking Form
* Video Release Forms
* PTO Request Contact Form
* Maintenance Request Contact Form
* Scholarship Application Forms
* File Download Forms
* Employment Verification Forms
* Make a Referral Contact Form
* Volunteer Registration Contact Form
* Offline Contact Form

To see a full list, visit our [Form Template Gallery](https://wpforms.com/templates/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin), which has over 2100+ pre-made contact form templates.

= Which Form Fields Does WPForms offer? =

We made the WPForms form builder to be both easy and powerful.

Here are the contact form fields that come with WPForms Form Builder (also known as Standard Fields):

* Text Field
* Paragraph Text (Textarea)
* Dropdown Field
* Multiple Choice (Radio Buttons)
* Checkboxes
* Numbers Field
* Name Field
* Email Address Field
* Number Slider Field

Here is a list of our advanced contact form builder fields (Fancy Fields):

* Smart Phone Field with international format verification
* Address Field
* Date / Time Field
* Website / URL Field
* File Upload - Great for File Upload Form
* Password Field
* Rich Text - Add a WYSIWYG field, perfect for guest blog post forms
* Layout Field - Position form fields inside columns using custom or premade layouts
* Repeater Field - Allow users to duplicate fields or groups of fields in your forms
* Page Break Field - Great for Multi-Page Contact Form with Progress Bar
* Section Divider - Great for Long Contact Forms
* HTML Field - add Custom HTML inside your form
* Content Field - Add headings, lists, and media to your forms without writing code
* Entry Preview - Allow your form users to preview their form entries before they've submitted them
* Star Rating - Great for Survey Forms and Polls
* Hidden Field
* Questions CAPTCHA - Great for Preventing Contact Form Spam
* Math CAPTCHA - Great for Preventing Contact Form Spam
* Likert Scale - Great for Survey Forms
* hCAPTCHA - Great for Preventing Contact Form Spam
* Cloudflare Turnstile - Great for Preventing Contact Form Spam
* Signature Field - Great for Contracts and Booking Forms
* Net Promoter Score (NPS Field) - Great for Survey Forms
* Google ReCAPTCHA - Great for Preventing Contact Form Spam


Here is a list of our Payment Fields that will help you create an order form, donation form, booking form, and other payment forms:

* Single Item
* Multiple Items
* Checkbox Items
* Dropdown Items
* Total (Calculation Field)
* Credit Card (Stripe, Square, Authorize.Net, and Mercado Pago)
* PayPal

= Can I integrate WPForms with my CRM or Email Marketing Service? =

Yes, WPForms offers seamless integration with over 1,000+ popular [email marketing](https://www.wpbeginner.com/showcase/best-email-marketing-services/) and [CRM software](https://www.wpbeginner.com/showcase/best-crm-software-for-small-businesses-compared/).

You can easily send data from your contact form and other WordPress forms to your favorite CRM, email newsletter, and other marketing platforms.

Here is a list of our popular marketing integrations:

* Mailchimp
* Constant Contact
* AWeber
* Drip
* Campaign Monitor
* GetResponse
* ActiveCampaign
* Zapier
* Salesforce CRM
* Brevo (ex Sendinblue)
* MailerLite
* MailPoet
* Pipedrive
* Google Sheets
* Slack
* Dropbox

Using our Zapier integration, you can easily connect WPForms with over 9,000+ marketing apps including:

* Zoho CRM
* Zoho Mail
* Zoho Invoice
* Agile CRM
* Trello
* Infusionsoft by Keap
* Microsoft Excel
* HelpScout
* Zendesk
* Freshbooks
* Freshsales
* Intercom
* Click Funnels
* Microsoft Dynamics 365 CRM
* Capsule CRM
* Insightly CRM
* Printfection
* Acuity Scheduling
* Quickbooks Online

See all [WPForms Zapier Integrations](https://zapier.com/apps/wpforms/integrations).

Note: WPForms was voted Zapier's 6th fastest-growing app in the world.

= Can I create a Payment Form with WPForms? =

Yes, WPForms is not your average contact form plugin. You can use it to create any type of form including payment forms.

We make it easy for you to accept payments using Stripe, Square, Authorize.Net, Mercado Pago, and PayPal Commerce.

Our Stripe, Authorize.Net, and Mercado Pago integrations help you easily accept credit card payments online.

Our PayPal integration allows you to accept PayPal payments online.

= Can I Import / Export Forms with WPForms?

Yes, WPForms makes it easy to import / export your contact forms and other WordPress forms created with the WPForms form builder. This is incredibly useful for developers and agencies who are building websites for clients.

You can also create custom form templates that you can use on client websites. For more see our documentation.

Aside from that, WPForms also allows you to import forms from other WordPress Contact Form plugins such as Contact Form 7, Ninja Forms, and Pirate Forms.

If you're not happy with your WordPress contact form plugin, then definitely give WPForms a try!

= I'd like access to all features. How can I get them? =

You can get access to more features, addons, and support by [upgrading to our Pro version](https://wpforms.com/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin). Purchasing a Pro license gets you access to the full version of WPForms, automatic updates, priority support, and all WPForms Addons!

= Is WPForms translation ready? =

Yes, WPForms has full translation and localization support via the wpforms textdomain. Based on your site language, required .mo and .po translation files will be downloaded and placed into the default WordPress languages directory. The same is true for every WPForms Addon, as well.

= Does WPForms include spam protection? =

Yes, WPForms includes spam protection which is enabled on all forms by default in the form settings.

Additionally, Google reCAPTCHA, hCaptcha, and Cloudflare Turnstile are also supported and can be set up at WPForms > Settings > CAPTCHA.

WPForms is fully compatible with all versions of Google reCAPTCHA:

* Checkbox reCAPTCHA v2
* Invisible reCAPTCHA v2
* reCAPTCHA v3

Lastly, [Custom Captchas](https://wpforms.com/features/spam-protection//?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) are available which allow you to create math- or question-based CAPTCHAs for your contact forms.

== Notes ==

WPForms is absolutely, positively the most [beginner-friendly WordPress contact form plugin](https://wpforms.com/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) on the market. It is both easy and powerful.

We took the pain out of creating online forms and made it easy. Check out all [WPForms features](https://wpforms.com/features/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin).

Also, I'm the founder of [WPBeginner](https://www.wpbeginner.com/), the largest WordPress resource site for beginners. It was a huge priority for me to make a WordPress contact form plugin that beginners can use without any training.

I feel that we have done that here. I hope you enjoy using WPForms.

Thank you,

Syed Balkhi

== Changelog ==
= 2.0.2.2 =
- Added: Support for the Nigerian Naira (NGN), Ghanaian Cedi (GHS), and Kenyan Shilling (KES) currencies.
- Fixed: The Setup Wizard handed off to its hosted version even when that version could not connect back to the site, so it failed on its first request instead of falling back to the local Getting Started setup.
- Fixed: Email addresses used as payment titles were displayed capitalized in the Payments table.
- Fixed: PayPal Commerce forms now always require a completed payment before saving an entry.
- Fixed: Smart Tag values used inside embedded content in a Confirmation message or a form description were not always escaped properly.

= 2.0.2.1 =
- Changed: The Keyboard Shortcuts modal in the Form Builder was reorganized into a single two-column list that pairs related shortcuts side by side, and widened so no shortcut wraps onto a second line.
- Fixed: Values submitted to a form embedded with the WPForms block were echoed back into the re-rendered form with shortcode delimiters intact.
- Fixed: A Smart Tag placed inside an HTML attribute in a Confirmation message, a form description, a field description or a User Registration message could alter the markup around it, or turn a link into a script, once its value contained a quote or an unsafe URL.

= 2.0.2 =
- Added: New Dashboard that displays form views and recommended next steps across all forms at a glance is now the first page you see when opening WPForms.
- Added: Links in AI Chat responses are now clickable and open in a new tab.
- Added: The AI form editing chat can now restore the form to its previous state when asked — reverting the most recent change, the same way as pressing Undo.
- Added: The `{all_fields}` smart tag now accepts an `exclude` parameter to omit specific fields by ID from notification emails, e.g. `{all_fields exclude="4,5"}`.
- Added: Suggested privacy policy text for the AI features now appears on the WordPress Privacy Policy Guide screen (Settings > Privacy > Policy Guide), so site owners can adopt it into their own policy.
- Changed: The "Minimum time to submit" spam protection is now measured on the server, so it can no longer be bypassed by bots.
- Changed: The Form Builder no longer saves the form and creates a revision when a WPForms AI editing prompt makes no changes to the form.
- Fixed: Installing an addon or plugin from WPForms was reported as failed when it printed a message during activation, even though it was successfully installed and active.
- Fixed: A Cloudflare Turnstile warning appeared in the browser console after a form was successfully submitted.
- Fixed: On right-to-left sites, the back arrow and card arrows in the Form Embed Wizard's Add to a New Page popup pointed the wrong way, and the QR Code icon was separated from its accompanying text.
- Fixed: Form submissions were silently marked as spam when the CAPTCHA provider rejected the site's secret key. An admin notice now reports the problem so it can be corrected, and the notice disappears once the CAPTCHA is reconfigured or disabled.
- Fixed: The Form Builder opened from the Get Started button in the WPForms block stayed stuck on a loading spinner on some sites and could not be saved or closed.
- Fixed: Saving a form showed a popup warning that AJAX form submissions are required for the PayPal Commerce field even after that field had been deleted.
- Fixed: The submit button did not switch to the processing text and stayed unchanged while a PayPal Commerce card payment was being processed.
- Fixed: The Email Summary email contained no form entries or trends data on sites running MySQL 5.7.
- Fixed: The Email Summary showed a blank trend percentage for a form that received exactly one entry in the previous week.
- Fixed: Security hardening for the Stripe payment refund process.
- Fixed: The AI chat displayed raw technical error messages (such as browser exceptions and connection timeouts) instead of user-friendly error notices.
- Fixed: On right-to-left sites, the AI chat window opened anchored to the wrong side of the screen instead of mirroring to the left, and the stop button lost its padding and stuck to the corner of the message field during response generation.
- Fixed: Undo and Redo controls in the Form Builder could disappear after two quick changes to the same setting.
- Fixed: The standard Submit button appeared next to the PayPal Commerce payment buttons in the Form Builder preview after editing a form with the AI Smart Form Editor.
- Fixed: Adding or removing a row in the Stripe Custom Meta table in the Form Builder was not tracked by Undo and Redo.
- Fixed: Email Summaries in some cases sent the same info block every week instead of rotating through the available blocks.
- Fixed: Extra small padding was displayed on the right side of the AI chat when using a Mac browser.

= 2.0.1.1 =
- Added: New QR Code setting generates a downloadable code for a chosen page or URL.
- Added: New Add Media button in the Confirmation Message editor allows inserting images from the Media Library.
- Added: Buttons in the Form Builder and on WPForms admin pages now show a visible focus indicator during keyboard navigation, and it no longer appears on mouse click.
- Changed: Stripe Radar-blocked payments now appear in the payment log with a distinct label instead of the generic decline message.
- Changed: Updated DOMPurify library to 3.4.13.
- Fixed: The Smart Tags widget in the Form Builder did not highlight required fields with a red border when validation failed.
- Fixed: A PHP notice was logged on the front-end when a payment field (Multiple Items, Checkbox Items, or Dropdown Items) contained a choice saved without a label.
- Fixed: Form templates in the Form Builder Setup panel were not filtered by the form's selected category, showing all templates instead.
- Fixed: Some button icons were misaligned on WordPress 7.0.
- Fixed: Incorrect spacing between the icon and text in the Form Builder top bar buttons.
- Fixed: Choice checkboxes and radio buttons in the Form Builder had no visible border and appeared stretched into ovals in Safari.
- Fixed: Collapsible settings sections in the Form Builder, such as AI MCP, did not stay closed after the page was reloaded.
- Fixed: Reordering choices in a Checkbox field in the Form Builder caused a browser console error and stopped the field preview from updating.
- Fixed: Square payments failed on every retry after a submission with an invalid credit card expiration date, even once the card details were corrected.
- Fixed: The Payments page showed too much space between elements when no payments had been collected yet.
- Fixed: PayPal Commerce subscription checkout failed with a fatal error when the account was disconnected while the form was loaded.
- Fixed: Visitors were not taken to the destination set in the form's Confirmations settings after submitting a form when a plugin or custom code supplied an invalid redirect address.
- Fixed: No warning appeared for empty or invalid notification email addresses in the Form Builder.
- Fixed: Various buttons across plugin admin pages showed the default blue focus outline instead of their custom focus styles after being clicked.
- Fixed: Pages rendered in response to a form submission are no longer cacheable, and submitted values are no longer written back into the form when a submission is rejected.

= 2.0.0.5 =
- Fixed: The WPForms admin menu left a large empty gap below it on mobile screens when viewing non-WPForms admin pages.

= 2.0.0.4 =
- Fixed: Lite Connect site registration failed permanently when the admin user profile had an empty first or last name, blocking entry backups.
- Fixed: The Onboarding Wizard would time out in some cases.

= 2.0.0.3 =
- Added: New supported currencies.
- Fixed: Permission handling in the Export Forms tool was improved.
- Fixed: Form data handling in the Block Editor was improved.

= 2.0.0.2 =
- Fixed: Form submissions could still be blocked by stricter web application firewall configurations that flagged the JSON structure of the Form Analytics data; the data attached to each submission is now base64-encoded.
- Fixed: A cross-site scripting vulnerability when a page combined a WPForms captcha with a specially crafted OptinMonster campaign.

= 2.0.0.1 =
- Fixed: Form submissions could be blocked by a web application firewall, such as Cloudflare's OWASP ruleset, because of the format of the Form Analytics data attached to each submission.

= 2.0.0 =
- Added: New Onboarding Wizard and Setup Checklist page in the WPForms admin menu to guide users through essential configuration steps.
- Added: New Reconnect button for invalid payment connections in the Form Builder Payments Settings panel.
- Changed: The Form Builder Setup panel now opens significantly faster.
- Changed: Updated DOMPurify library to 3.4.11.
- Changed: The AI Chat button in the Form Builder is now shown in grey and displays a tooltip explaining that WPForms AI is not available on local sites.
- Changed: Updated woocommerce/action-scheduler library to 4.0.0.
- Changed: Stripe payment security is enhanced with automatic detection and blocking of card testing attacks and other fraudulent activity.
- Fixed: Randomize the position of the correct answer in AI-generated graded quizzes.
- Fixed: Admin notices about incompatible WPForms versions are now shown only to users who can update plugins.
- Fixed: A choice deleted in the Form Builder could still appear as an empty option on the front-end and triggered PHP warnings on the form view.
- Fixed: The settings gear icon on the Payments, and Dashboard pages was displayed in the wrong color and oversized when Elementor plugin was active.
- Fixed: Form elements could appear disabled after a Stripe 3D Secure authentication failure, even though they remained editable.
- Fixed: The connection icon was displayed in the Builder settings for payment methods even when no account was connected.
- Fixed: Stripe subscription renewals could remain in the Pending status and display an outdated renewal date on the Payment Single page.
- Fixed: Connected payment methods checkmark could still appear in the Form Builder Payments panel after switching to a template without a payment field.
- Fixed: The Weekly Email Summary email content was displayed right-aligned instead of centered in the web version of Gmail.
- Fixed: The Themes panel in the Form Builder Settings did not re-open when its menu item was clicked again after navigating away and back.
- Fixed: A PHP warning was logged when restoring a trashed form on PHP 8.3 and higher.

= 1.10.2.1 =
- Added: AI MCP settings section in the Form Builder with the MCP write-access toggle.
- Fixed: Forms scrolled back to the first text input when adjusting a Number Slider in Chrome on Android.
- Fixed: Email notification header sanitization was improved for better security.

= 1.10.2 =
- Added: The Abilities API now supports creating new forms, editing existing form fields, and editing form settings.
- Changed: Stripe subscriptions that finish all configured billing cycles are now marked as Completed.
- Fixed: Delete icon overlapped form name in the Bulk Edit Tags field during bulk edits.
- Fixed: Custom CSS configured in the Form Builder was not applied when the form was embedded via the Gutenberg block.
- Fixed: An AbortError: Transition was skipped console error appeared in the Form Builder on WordPress 7.0.
- Fixed: PayPal Credit payment status was not being synchronized in WPForms > Payments.
- Fixed: The Query String Variable smart tag key was unexpectedly reset when the Email field default value was cleared and re-configured in the Form Builder.
- Fixed: Stripe block-editor CSS and JS assets no longer load unconditionally on every Block Editor screen. They now load only when the `wpforms/form-selector` block is present.
- Fixed: The `wpforms_emails_send_email_data` filter silently discarded any changes to the headers key before sending the email.
- Fixed: PHP fatal error when submitting a form with the {page_url} smart tag if the page_url POST field was sent as an array.
- Fixed: An invalid notice about Fastlane and alternative payment methods appeared in Stripe and Square subscription payment settings in the Form Builder.

= 1.10.1.1 =
- Added: Inline Connect buttons in the Form Builder Payments panel, allowing users to connect their payment accounts without leaving the form editor.
- Changed: The Payments page has a refreshed design when no payments have been received yet.
- Fixed: Fatal error on form submission when the PayPal Commerce account was disconnected while the form still had the PayPal Commerce payment enabled.

= 1.10.1 =
- Added: Secret key fields in the admin settings are now masked for improved privacy.
- Added: Smart Form Editing allows modifying existing forms using natural language through an AI chat interface directly inside the form builder.
- Changed: Updated `symfony/polyfill-mbstring` library to v1.37.0.
- Changed: Updated `symfony/polyfill-iconv` library to v1.37.0.
- Changed: Updated DOMPurify library to v3.4.1.
- Fixed: The wrong PayPal Commerce connection status was displayed in certain cases.
- Fixed: Form Builder was stuck loading when third-party plugins prevented WordPress footer scripts from rendering.
- Fixed: Settings input values were saved with a trailing space, which could cause unexpected behavior.
- Fixed: Smart tag parsing returned an invalid value when no smart tags were present in the content.
- Fixed: Form Builder was not loading on sites with inconsistent URL configurations (e.g., www vs non-www mismatch or root-relative URL plugins).
- Fixed: PHP fatal errors could occur in some cases on PHP 8.0+.
- Fixed: The Allow/Deny list settings were being cleared when a form had more than one Email field.
- Fixed: Outdated image asset paths were causing 404 errors on sites using the Divi theme.
- Fixed: An incorrect error message was shown when the daily AI request limit was reached, referring to form generation instead of AI usage.

[See changelog for all versions](https://wpforms.com/docs/how-to-view-recent-changes-to-the-wpforms-plugin-changelog/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin).
