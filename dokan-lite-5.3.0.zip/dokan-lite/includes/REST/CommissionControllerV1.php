<?php

namespace WeDevs\Dokan\REST;

use WeDevs\Dokan\Abstracts\DokanRESTController;
use WeDevs\Dokan\Commission\ProductCommission;
use WeDevs\Dokan\ProductCategory\Helper;
use WP_Error;
use WP_HTTP_Response;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

class CommissionControllerV1 extends DokanRESTController {

    /**
     * Endpoint namespace
     *
     * @var string
     */
    protected $namespace = 'dokan/v1';

    /**
     * Route name
     *
     * @var string
     */
    protected $base = 'commission';

    /**
     * Registering the commission routes here.
     *
     * @since 3.14.0
     */
    public function register_routes() {
        register_rest_route(
            $this->namespace, '/' . $this->base, [
                [
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => [ $this, 'get_commission' ],
                    'args'                => [
                        'product_id' => [
                            'description'       => __( 'Products price', 'dokan-lite' ),
                            'type'              => 'integer',
                            'default'           => 0,
                            'required'          => true,
                            'sanitize_callback' => 'absint',
                        ],
                        'amount' => [
                            'description'       => __( 'The amount on that the commission will be calculated.', 'dokan-lite' ),
                            'type'              => 'number',
                            'default'           => 0,
                            'required'          => true,
                            'sanitize_callback' => 'sanitize_text_field',
                        ],
                        'vendor_id' => [
                            'description'       => __( 'Vendor id', 'dokan-lite' ),
                            'type'              => 'integer',
                            'default'           => 0,
                            'required'          => true,
                            'sanitize_callback' => 'absint',
                        ],
                        'category_ids' => [
                            'description'       => __( 'Category ids', 'dokan-lite' ),
                            'type'              => 'array',
                            'sanitize_callback' => [ $this, 'sanitize_category_ids' ],
                            'items'             => array(
                                'type' => 'integer',
                            ),
                            'default'           => [],
                            'required'          => true,
                        ],
                        'context' => [
                            'required'    => false,
                            'description' => __( 'In which context the commission will be calculated', 'dokan-lite' ),
                            'type'        => 'string',
                            'enum'        => [ 'admin', 'seller' ],
                            'context'     => [ 'view', 'edit' ],
                            'default'     => 'seller',
                        ],
                    ],
                    'permission_callback' => [ $this, 'get_permissions_check' ],
                ],
            ]
        );
    }

    /**
     * Checking if have any permission.
     *
     * @since 3.14.0
     * @since 5.2.0 Vendors need a product capability and may only calculate against their own vendor ID and products.
     *
     * @param WP_REST_Request $request
     *
     * @return bool|WP_Error
     */
    public function get_permissions_check( $request ) {
        if ( current_user_can( 'manage_woocommerce' ) ) {
            return true;
        }

        // phpcs:ignore WordPress.WP.Capabilities.Unknown
        if ( ! current_user_can( 'dokandar' ) ) {
            return false;
        }

        // The calculator backs product creation and editing, so it needs that capability too (ADR-0007).
        if ( ! current_user_can( 'dokan_add_product' ) && ! current_user_can( 'dokan_edit_product' ) ) {
            return false;
        }

        $vendor_id  = absint( $request->get_param( 'vendor_id' ) );
        $product_id = absint( $request->get_param( 'product_id' ) );

        // A vendor may only price against their own commission setup, never another vendor's.
        if ( ( $vendor_id && $vendor_id !== dokan_get_current_user_id() ) || ( $product_id && ! dokan_is_product_author( $product_id ) ) ) {
            return new WP_Error( 'dokan_rest_forbidden_target', __( 'You are not allowed to calculate commission for this vendor.', 'dokan-lite' ), [ 'status' => rest_authorization_required_code() ] );
        }

        return true;
    }

    /**
     * Returns commission or earning based on context.
     *
     * @param WP_REST_Request $request
     *
     * @return WP_Error|WP_HTTP_Response|WP_REST_Response
     */
    public function get_commission( $request ) {
        $product_id   = $request->get_param( 'product_id' );
        $amount       = $request->get_param( 'amount' );
        $vendor_id    = $request->get_param( 'vendor_id' );
        $category_ids = $request->get_param( 'category_ids' );
        $context      = $request->get_param( 'context' );

        $chosen_cats = Helper::generate_chosen_categories( $category_ids );
        $category_id = reset( $chosen_cats );

        if ( ! $category_id ) {
            $category_id = 0;
        }

        if ( ! $vendor_id ) {
            $vendor_id = dokan_get_vendor_by_product( $product_id, true );
            $vendor_id = $vendor_id ? $vendor_id : 0;
        }

        if ( ! is_numeric( $amount ) ) {
            $amount = 0;
        }
        try {
            $product_commission = dokan_get_container()->get( ProductCommission::class );
            $product_commission->set_product_id( $product_id );
            $product_commission->set_total_amount( $amount );
            $product_commission->set_vendor_id( $vendor_id );
            $product_commission->set_category_id( $category_id );
            $commission_or_earning = $product_commission->calculate();

            $data = 'seller' === $context ? $commission_or_earning->get_vendor_earning() : $commission_or_earning->get_admin_commission();
        } catch ( \Exception $exception ) {
            $data = 0;
        }

        return rest_ensure_response( wc_format_decimal( $data, wc_get_price_decimals() ) );
    }

    /**
     * Normalize the `category_ids` request param to a flat list of term IDs.
     *
     * The product editor's category field is an async-select that submits option
     * objects ([ { value, label }, ... ]); the commission lookup only needs the
     * integer term IDs, so reduce any object shape to its `value` before use.
     *
     * @since 5.0.6
     *
     * @param mixed $value Raw `category_ids` value from the request.
     *
     * @return int[]
     */
    public function sanitize_category_ids( $value ): array {
        $category_ids = [];

        foreach ( (array) $value as $category ) {
            // Async-select options arrive as { value, label }; flat IDs pass through unchanged.
            $term_id = absint( is_array( $category ) ? ( $category['value'] ?? 0 ) : $category );

            if ( $term_id ) {
                $category_ids[] = $term_id;
            }
        }

        return $category_ids;
    }
}
