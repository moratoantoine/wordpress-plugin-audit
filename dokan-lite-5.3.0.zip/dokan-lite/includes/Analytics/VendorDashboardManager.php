<?php

namespace WeDevs\Dokan\Analytics;

use WeDevs\Dokan\Contracts\Hookable;
use WP_REST_Request;

class VendorDashboardManager implements Hookable {
    public function register_hooks(): void {
        add_filter( 'woocommerce_rest_check_permissions', [ $this, 'woocommerce_rest_check_permissions' ], 20, 4 );

        add_action( 'dokan_dashboard_before_widgets', [ $this, 'add_dashboard_content' ], 20 );

        add_filter( 'woocommerce_rest_product_object_query', [ $this, 'product_query_args' ], 10, 2 );

        add_filter( 'woocommerce_rest_report_revenue_stats_schema', [ $this, 'revenue_stats_schema' ] );
        // add_filter( 'woocommerce_rest_report_orders_stats_schema', [ $this, 'revenue_stats_schema' ] );

        add_filter( 'woocommerce_rest_report_sort_performance_indicators', [ $this, 'sort_performance_indicators' ] );

        add_filter( 'woocommerce_component_settings_preload_endpoints', array( $this, 'add_preload_endpoints' ), 20 );
    }

    /**
     * Add a dummy content to the dashboard.
     *
     * @since 4.0.0
     *
     * @return void
     */
    public function add_dashboard_content() {
        echo '<div id="dokan-analytics-app"></div>';
    }

    public function woocommerce_rest_check_permissions( $permission, $context, $int_val, $obj ) {
        if ( ! $permission && in_array(
            $obj, [
				'reports',
				'settings',
				'product_cat',
			], true
        ) && $context === 'read' ) {
            $current_user_id = dokan_get_current_user_id();
            $permission      = dokan_is_user_seller( $current_user_id );
        }

        return $permission;
    }

    /**
     * Filter product query by the Vendor.
     *
     * @param array $args
     * @return array
     */
    public function product_query_args( array $args, WP_REST_Request $request ) {
        if (
            ! is_user_logged_in()
            || ! is_admin()
            || current_user_can( 'manage_woocommerce' )
            || '/wc-analytics/products' !== $request->get_route()
        ) {
            return $args;
        }

        $args['author'] = get_current_user_id();

        return $args;
    }

    public function add_additional_fields_schema1( $reports ) {
        $reports[] = array(
            'slug'        => 'revenue/total_seller_earning',
            'description' => __( 'Seller Totals.', 'dokan-lite' ),
        );

        return $reports;
    }

    public function revenue_stats_schema( $reports ) {
        $is_vendor_dashboard = dokan_is_seller_dashboard();

        $reports['totals']['properties']['total_vendor_earning'] = array(
            'description' => $is_vendor_dashboard
                ? esc_html__( 'Total Earning', 'dokan-lite' )
                : esc_html__( 'Total Vendor Earning', 'dokan-lite' ),
            'type'        => 'number',
            'context'     => array( 'view', 'edit' ),
            'readonly'    => true,
            'indicator'   => true,
            'format'      => 'currency',
        );

        $reports['totals']['properties']['total_admin_discount'] = array(
            'description' => esc_html__( 'Marketplace Discount', 'dokan-lite' ),
            'type'        => 'number',
            'context'     => array( 'view', 'edit' ),
            'readonly'    => true,
            'indicator'   => true,
            'format'      => 'currency',
        );

        $reports['totals']['properties']['total_vendor_discount'] = array(
            'description' => $is_vendor_dashboard
                ? esc_html__( 'Store Discount', 'dokan-lite' )
                : esc_html__( 'Total Vendor Discount', 'dokan-lite' ),
            'type'        => 'number',
            'context'     => array( 'view', 'edit' ),
            'readonly'    => true,
            'indicator'   => true,
            'format'      => 'currency',
        );

        $reports['totals']['properties']['total_admin_commission'] = array(
            'description' => $is_vendor_dashboard
                ? esc_html__( 'Marketplace Commission', 'dokan-lite' )
                : esc_html__( 'Total Commission', 'dokan-lite' ),
            'type'        => 'number',
            'context'     => array( 'view', 'edit' ),
            'readonly'    => true,
            'indicator'   => true,
            'format'      => 'currency',
        );

        return $reports;
    }

    public function sort_performance_indicators( $reports ) {
        $first_indicator = array_shift( $reports );

        $vendor_indicators = [
            $first_indicator,
            'revenue/total_seller_earning',
            'revenue/total_admin_commission',
        ];

        array_unshift( $reports, ...$vendor_indicators );

        return $reports;
    }

    /**
     * Load analytics revenue schema vendor dashboard.
     *
     * @since 4.2.8
     *
     * @see https://github.com/woocommerce/woocommerce/blob/8e3b0c45ad771d7fe53ee610f237f4803f1a63bb/plugins/woocommerce/src/Internal/Admin/Analytics.php#L113
     *
     * @param array $endpoints Array of preloaded endpoints.
     *
     * @return array
     */
    public function add_preload_endpoints( array $endpoints ): array {
        $screen_id = ( function_exists( 'get_current_screen' ) && get_current_screen() ) ? get_current_screen()->id : '';

        /**
         * Should load vendor analytics revenue schema.
         *
         * @since 4.2.8
         *
         * @param bool   $load_schema Should load vendor analytics schema.
         * @param array  $endpoints   Array of preloaded endpoints.
         * @param string $screen_id   Current screen ID.
         */
        $load_analytics_schema = apply_filters(
            'dokan_analytics_reports_load_vendor_revenue_schema',
            'woocommerce_page_wc-admin' === $screen_id || dokan_is_seller_dashboard(),
            $endpoints,
            $screen_id
        );

        // Only preload endpoints on wc-admin pages.
        if ( $load_analytics_schema ) {
            $endpoints['performanceIndicators'] = '/wc-analytics/reports/performance-indicators/allowed';
            $endpoints['leaderboards']          = '/wc-analytics/leaderboards/allowed';
        }

        return $endpoints;
    }
}
