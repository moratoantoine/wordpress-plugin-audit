<?php

namespace WeDevs\Dokan\Admin;

/**
 * Recommended Plugins Class.
 *
 * @since 4.0.0
 */
class RecommendedPlugins {

    /**
     * Array of Recommended Plugins.
     *
     * @var array
     */
    protected array $plugins;

    /**
     * Class Constructor.
     *
     * @since 4.0.0
     */
    public function __construct() {
        $this->plugins = [
            [
                'type'        => 'flycrm',
                'title'       => fn() => __( 'FlyCRM', 'dokan-lite' ),
                'description' => fn() => __( 'Track leads, contacts and deals for your marketplace inside WordPress', 'dokan-lite' ),
                'img_url'     => DOKAN_PLUGIN_ASSEST . '/images/extensions/addons/flycrm.svg',
                'img_alt'     => fn() => __( 'FlyCRM logo', 'dokan-lite' ),
                'slug'        => 'flycrm',
                'basename'    => 'flycrm/flycrm.php',
            ],
            [
                'type'        => 'wepos',
                'title'       => fn() => __( 'wePos', 'dokan-lite' ),
                'description' => fn() => __( 'Run your counter and online store from one fast POS system', 'dokan-lite' ),
                'img_url'     => DOKAN_PLUGIN_ASSEST . '/images/extensions/addons/wepos.svg',
                'img_alt'     => fn() => __( 'wePos logo', 'dokan-lite' ),
                'slug'        => 'wepos',
                'basename'    => 'wepos/wepos.php',
            ],
            [
                'type'        => 'wemail',
                'title'       => fn() => __( 'weMail', 'dokan-lite' ),
                'description' => fn() => __( 'Send campaigns and automate email marketing inside WordPress', 'dokan-lite' ),
                'img_url'     => DOKAN_PLUGIN_ASSEST . '/images/wemail-logo.png',
                'img_alt'     => fn() => __( 'weMail logo', 'dokan-lite' ),
                'slug'        => 'wemail',
                'basename'    => 'wemail/wemail.php',
            ],
            [
                'type'        => 'wc_conversion_tracking',
                'title'       => fn() => __( 'WooCommerce Conversion Tracking', 'dokan-lite' ),
                'description' => fn() => __( 'Advanced WooCommerce conversion tracking for every ad platform', 'dokan-lite' ),
                'img_url'     => DOKAN_PLUGIN_ASSEST . '/images/wc-conversion-tracking-logo.png',
                'img_alt'     => fn() => __( 'WooCommerce Conversion Tracking logo', 'dokan-lite' ),
                'slug'        => 'woocommerce-conversion-tracking',
                'basename'    => 'woocommerce-conversion-tracking/conversion-tracking.php',
            ],
            [
                'type'        => 'store_growth',
                'title'       => fn() => __( 'StoreGrowth', 'dokan-lite' ),
                'description' => fn() => __( 'Boost sales with upsells, BOGO deals, FOMO popups and more', 'dokan-lite' ),
                'img_url'     => DOKAN_PLUGIN_ASSEST . '/images/store-growth-logo.png',
                'img_alt'     => fn() => __( 'StoreGrowth logo', 'dokan-lite' ),
                'slug'        => 'storegrowth-sales-booster',
                'basename'    => 'storegrowth-sales-booster/storegrowth-sales-booster.php',
            ],
            [
                'type'        => 'wedocs',
                'title'       => fn() => __( 'weDocs', 'dokan-lite' ),
                'description' => fn() => __( 'Add a self-serve help center with AI-powered docs for vendors', 'dokan-lite' ),
                'img_url'     => DOKAN_PLUGIN_ASSEST . '/images/extensions/addons/wedocs.svg',
                'img_alt'     => fn() => __( 'weDocs logo', 'dokan-lite' ),
                'slug'        => 'wedocs',
                'basename'    => 'wedocs/wedocs.php',
            ],
        ];
    }

    /**
     * Get All Enlisted Plugins.
     *
     * @since 4.0.0
     *
     * @return array
     */
    protected function get_enlisted_plugins(): array {
        $plugins = array_map(
            function ( $plugin ) {
				return array_map(
                    function ( $value ) {
                        return is_callable( $value ) ? $value() : $value;
                    }, $plugin
				);
			}, $this->plugins
        );

        /**
         * Filter the list of recommended plugins.
         *
         * @since 4.0.0
         *
         * @param array $plugins List of recommended plugins.
         *
         * @return array Filtered list of recommended plugins.
         */
        return apply_filters( 'dokan_recommended_plugins_list', $plugins );
    }

    /**
     * Is Plugin Active.
     *
     * @since 4.0.0
     *
     * @param string $basename
     *
     * @return bool
     */
    protected function is_active( string $basename ): bool {
        /**
         * Filter to determine if a recommended plugin is active.
         *
         * @since 4.0.0
         *
         * @param bool   $is_active Whether the plugin is active.
         * @param string $basename  The basename of the plugin.
         *
         * @return bool Filtered value indicating if the plugin is active.
         */
        return apply_filters( 'dokan_recommended_plugin_is_active', is_plugin_active( $basename ), $basename );
    }

    /**
     * Get List of Recommended Inactive Plugins.
     *
     * @since 4.0.0
     *
     * @return array
     */
    public function get(): array {
        $enlisted_plugins = $this->get_enlisted_plugins();

        $recommended_plugins = array_filter(
            $enlisted_plugins,
            function ( $plugin ) {
                return isset( $plugin['basename'] ) && ! $this->is_active( $plugin['basename'] );
            }
        );

        /**
         * Filter the list of recommended inactive plugins.
         *
         * @since 4.0.0
         *
         * @param array $recommended_plugins List of recommended inactive plugins.
         *
         * @return array Filtered list of recommended inactive plugins.
         */
        return apply_filters( 'dokan_recommended_inactive_plugins', $recommended_plugins );
    }
}
