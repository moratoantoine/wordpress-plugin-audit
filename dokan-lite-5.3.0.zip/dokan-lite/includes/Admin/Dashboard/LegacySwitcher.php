<?php

namespace WeDevs\Dokan\Admin\Dashboard;

use WeDevs\Dokan\Contracts\Hookable;

/**
 * LegacySwitcher Class
 *
 * Handles legacy URL switching and menu title clearing for admin dashboard and settings.
 *
 * @since 4.1.3
 */
class LegacySwitcher implements Hookable {

    /**
     * Value of `dokan_action` that triggers the product editor switch.
     *
     * @since 5.0.0
     */
    public const PRODUCT_EDITOR_SWITCH_ACTION = 'switch_product_editor';

    /**
     * Option that stores the site-wide opt-in to the new settings screen.
     *
     * @since 5.2.0
     */
    public const NEW_SETTINGS_OPTION = 'dokan_new_settings_page_enabled';

    /**
     * Default transient expiration time in seconds (15 days)
     *
     * @since 4.1.3
     *
     * @var int
     */
    protected int $transient_expiration = 15 * DAY_IN_SECONDS;

    /**
     * Register hooks for the LegacySwitcher
     *
     * @since 4.1.3
     *
     * @return void
     */
    public function register_hooks(): void {
        add_action( 'admin_menu', [ $this, 'handle_dokan_admin_submenu' ], 20 );
        add_action( 'admin_init', [ $this, 'handle_dashboard_redirect' ] );
    }

    /**
     * Clear admin submenu title based on legacy dashboard preference.
     *
     * @since 4.1.3
     *
     * @return void
     */
    public function handle_dokan_admin_submenu(): void {
        global $submenu;

        // Check if the submenu exists.
        if ( ! isset( $submenu['dokan'] ) || ! is_array( $submenu['dokan'] ) ) {
            return;
        }

        // Filter the submenu items based on legacy dashboard preference.
        $filtered = array_reduce(
            $submenu['dokan'], function ( $filtered, $menu_item ) {
                $menu_title       = explode( ' <', $menu_item[0] );
                $title            = sanitize_title_with_dashes( $menu_title[0] );
                $is_settings      = (bool) preg_match( '~#/settings(?:[/?]|$)~', $menu_item[2] );
				$is_legacy        = $is_settings ? $this->is_legacy_settings_page() : get_transient( 'dokan_legacy_' . $title . '_page' );
                $is_new_dashboard = strpos( $menu_item[2], 'dokan-dashboard' ) !== false;

				// Handle the admin dashboard menu item based on legacy dashboard preference.
                // Dashboard legacy and the new menu should keep (both) for the frontend mounting purpose, that's why we are handling the dashboard menu item separately.
				if ( 'dashboard' === $title ) {
                    // Clear the title if the legacy dashboard is enabled.
                    if ( $is_new_dashboard && $is_legacy ) {
                        $menu_item[0] = '';
                    }

                    // Clear the title and update the url if the legacy dashboard is disabled.
                    if ( ! $is_new_dashboard && ! $is_legacy ) {
                        $menu_item[0] = '';
                        $menu_item[2] = 'admin.php?page=dokan-dashboard';
                    }

                    // Add dashboard menu item based on legacy dashboard preference.
                    $filtered[] = $menu_item;

					return $filtered;
				}

				// Check if the menu item for handle the admin legacy page switching.
				if ( isset( $menu_item[2] ) && $is_new_dashboard ) {
					if ( ! $is_legacy ) {
						$filtered[ $title ] = $menu_item;
					}
				} elseif ( ! isset( $filtered[ $title ] ) ) {
					$filtered[ $title ] = $menu_item;
				}

				return $filtered;
			}, []
        );

        $submenu['dokan'] = array_values( $filtered ); // phpcs:ignore
    }

    /**
     * Handle dashboard redirect based on legacy dashboard preference.
     *
     * @since 4.1.3
     *
     * @return void
     */
    public function handle_dashboard_redirect(): void {
        // Early return if not a switch request.
        if ( ! isset( $_GET['dokan_action'] ) || 'switch_admin_panel' !== sanitize_key( wp_unslash( $_GET['dokan_action'] ) ) ) {
            return;
        }

        // Early return if nonce verification fails.
        if ( ! isset( $_GET['dokan_admin_switching_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_GET['dokan_admin_switching_nonce'] ) ), 'dokan_switch_admin_panel' ) ) {
            return;
        }

        $legacy_key = sanitize_key( wp_unslash( $_GET['legacy_key'] ?? 'dashboard' ) );

        if ( 'settings' === $legacy_key ) {
            $switch_to        = sanitize_key( wp_unslash( $_GET['switch_to'] ?? '' ) );
            $new_legacy_state = $this->switch_settings_page( $switch_to );
        } else {
            $filtered_legacy_key = $this->get_custom_transient_key( $legacy_key );
            $current_is_legacy   = get_transient( $filtered_legacy_key );
            $new_legacy_state    = ! $current_is_legacy;

            if ( $current_is_legacy ) {
                delete_transient( $filtered_legacy_key );
            } else {
                set_transient( $filtered_legacy_key, $new_legacy_state, $this->transient_expiration );
            }
        }

        // Redirect to the new admin page, if needed.
        $page_slug    = $new_legacy_state ? 'dokan' : 'dokan-dashboard';
        $endpoint     = str_replace( 'dashboard', '', $legacy_key ); // Remove 'dashboard' from the endpoint as the default endpoint.
        $redirect_url = add_query_arg( [ 'page' => $page_slug ], admin_url( 'admin.php' ) ) . '#/' . $endpoint;

        // TODO: Remove this legacy option cleanup after 2-3 versions
        // Check if the legacy option exists and remove it.
        $legacy_dashboard_page = get_option( 'dokan_legacy_dashboard_page', false );
        if ( $legacy_dashboard_page ) {
            // This removes the old option from the database as we've migrated to transients.
            delete_option( 'dokan_legacy_dashboard_page' );
        }

        wp_safe_redirect( $redirect_url );
        exit;
    }

    /**
     * Whether the site uses the classic (legacy) settings screen.
     *
     * @since 5.2.0
     *
     * @return bool
     */
    public function is_legacy_settings_page(): bool {
        return 'yes' !== get_option( self::NEW_SETTINGS_OPTION, 'no' );
    }

    /**
     * Switch the site-wide settings screen to classic or new.
     *
     * @since 5.2.0
     *
     * @param string $switch_to `legacy` or `new`; anything else toggles the current screen.
     *
     * @return bool Whether the classic screen is active after the switch.
     */
    protected function switch_settings_page( string $switch_to ): bool {
        $use_legacy = in_array( $switch_to, [ 'legacy', 'new' ], true ) ? 'legacy' === $switch_to : ! $this->is_legacy_settings_page();

        if ( $use_legacy ) {
            delete_option( self::NEW_SETTINGS_OPTION );
        } else {
            update_option( self::NEW_SETTINGS_OPTION, 'yes' );
        }

        return $use_legacy;
    }

    /**
     * Whether the classic screen is active for a Dokan admin page.
     *
     * @since 5.2.0
     *
     * @param string $key Page key, e.g. `settings`, `withdraw` or `dashboard`.
     *
     * @return bool
     */
    public function is_legacy_page( string $key ): bool {
        if ( 'settings' === $key ) {
            return $this->is_legacy_settings_page();
        }

        return (bool) get_transient( $this->get_custom_transient_key( $key ) );
    }

    /**
     * Get the admin URL of a Dokan page on the screen (classic or new) the site uses.
     *
     * Only for pages that exist on both screens.
     *
     * @since 5.2.0
     *
     * @param string $route Hash route, e.g. `settings` or `vendors?status=pending`. Empty for the dashboard.
     *
     * @return string
     */
    public function get_admin_page_url( string $route = '' ): string {
        $key  = strtok( $route, '/?' );
        $page = $this->is_legacy_page( $key ? $key : 'dashboard' ) ? 'dokan' : 'dokan-dashboard';

        return admin_url( 'admin.php?page=' . $page . '#/' . $route );
    }

    /**
     * Get admin menu transient key.
     *
     * @since 4.1.3
     *
     * @param string $key
     *
     * @return string
     */
    public function get_custom_transient_key( $key ) {
        $admin_url_map = apply_filters(
            'dokan_admin_legacy_url_map',
            [
                'refund'              => 'refunds',
                'request-for-quote'   => 'rfq',
                'announcement'        => 'announcements',
                'dokan-seller-badge'  => 'seller-badge',
                'product-advertising' => 'advertising',
                'admin-store-support' => 'store-support',
                'product-qa'          => 'product-qa',
            ]
        );

        // Get the legacy key from the map or the original key.
        $legacy_key = sanitize_key( wp_unslash( $admin_url_map[ $key ] ?? $key ) );

        return 'dokan_legacy_' . $legacy_key . '_page';
    }

    /**
     * Whether the given user prefers the legacy product editor.
     *
     * Defaults to `false` — the new (React) product editor.
     *
     * @since 5.0.0
     *
     * @param int $user_id Optional. Defaults to current user.
     *
     * @return bool
     */
    public function is_product_editor_legacy_preferred( int $user_id = 0 ): bool {
        if ( ! $user_id ) {
            $user_id = get_current_user_id();
        }

        // Anonymous context (cron, emails without a current user) → prefer the new editor.
        if ( ! $user_id ) {
            return false;
        }

        $appearance = get_option( 'dokan_appearance', [] );
        if ( isset( $appearance['vendor_product_editor'] ) && 'latest' === $appearance['vendor_product_editor'] ) {
            return false;
        }

        return true;
    }

    /**
     * Whether the legacy vendor store settings page is preferred.
     *
     * The preference is the site-wide `dokan_appearance` admin option, not a
     * per-user setting — `$user_id` only guards anonymous contexts, mirroring
     * {@see self::is_product_editor_legacy_preferred()}. The stored default is
     * legacy, and the admin setup wizard flips it to latest, so an upgraded
     * site keeps the legacy form until an admin opts in.
     *
     * @since 5.3.0
     *
     * @param int $user_id Optional. Defaults to current user.
     *
     * @return bool
     */
    public function is_store_settings_legacy_preferred( int $user_id = 0 ): bool {
        if ( ! $user_id ) {
            $user_id = get_current_user_id();
        }

        // Anonymous context (cron, emails without a current user) → prefer the new page.
        if ( ! $user_id ) {
            return false;
        }

        $appearance = get_option( 'dokan_appearance', [] );
        if ( isset( $appearance['vendor_store_settings'] ) && 'latest' === $appearance['vendor_store_settings'] ) {
            return false;
        }

        return true;
    }

    /**
     * Build the new (React) product editor URL.
     *
     * @since 5.0.0
     *
     * @param int $product_id
     *
     * @return string
     */
    public function get_new_product_editor_url( int $product_id ): string {
        // `dokan_get_navigation_url( 'products', true )` already ends with `#products/`.
        $base   = dokan_get_navigation_url( 'products', true );
        $suffix = $product_id ? $product_id . '/edit' : 'create';

        return $base . $suffix;
    }

    /**
     * Build the legacy product editor URL, falling back to the
     * create-new-product URL when no product id is supplied.
     *
     * @since 5.0.0
     *
     * @param int $product_id
     *
     * @return string
     */
    protected function get_legacy_product_editor_url( int $product_id ): string {
        if ( ! $product_id ) {
            return (string) dokan_get_new_product_url();
        }

        return (string) dokan_edit_product_url( $product_id );
    }
}
