<?php return array('dependencies' => array('wc-csv', 'wc-date', 'wp-i18n'), 'version' => 'a219af58777c02c3f887');
