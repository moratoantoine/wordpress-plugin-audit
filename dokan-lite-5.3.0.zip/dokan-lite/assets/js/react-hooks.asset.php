<?php return array('dependencies' => array('dokan-stores-product-categories', 'dokan-stores-products', 'wp-api-fetch', 'wp-data', 'wp-element', 'wp-url'), 'version' => 'a73190baf4c351a98a4d');
