<?php return array('dependencies' => array('jquery', 'wp-i18n'), 'version' => 'b5acf5ddf5ce76e49a11');
