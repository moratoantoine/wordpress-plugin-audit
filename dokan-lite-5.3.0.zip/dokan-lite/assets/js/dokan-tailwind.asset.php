<?php return array('dependencies' => array(), 'version' => '11718f0a73eefc944c73');
