<?php return array('dependencies' => array('dokan-ui', 'react-jsx-runtime', 'wp-api-fetch', 'wp-compose', 'wp-dom-ready', 'wp-element', 'wp-hooks', 'wp-i18n'), 'version' => 'af375c9da2326cbf079f');
