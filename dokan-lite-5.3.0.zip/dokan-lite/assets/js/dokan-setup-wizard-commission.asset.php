<?php return array('dependencies' => array(), 'version' => '7ca02fee130105112099');
