<?php return array('dependencies' => array('react-jsx-runtime', 'wc-csv', 'wc-date', 'wp-api-fetch', 'wp-data', 'wp-i18n'), 'version' => '4dbb335eef03ddb3d8f2');
