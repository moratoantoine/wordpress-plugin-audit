<?php return array('dependencies' => array('react-jsx-runtime', 'wp-dom-ready', 'wp-element', 'wp-hooks', 'wp-i18n', 'wp-url'), 'version' => 'b8fed446648493c79f37');
