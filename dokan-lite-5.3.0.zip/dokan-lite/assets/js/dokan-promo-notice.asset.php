<?php return array('dependencies' => array('jquery', 'wp-i18n'), 'version' => '975af834f54ab4f314a5');
