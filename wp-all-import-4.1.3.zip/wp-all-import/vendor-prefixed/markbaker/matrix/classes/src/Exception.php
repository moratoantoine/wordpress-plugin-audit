<?php

/**
 * Exception.
 *
 * @copyright  Copyright (c) 2013-2018 Mark Baker (https://github.com/MarkBaker/PHPMatrix)
 * @license    https://opensource.org/licenses/MIT    MIT
 */
namespace Soflyy\WpAllImport\Vendor\Matrix;

class Exception extends \Exception
{
}
