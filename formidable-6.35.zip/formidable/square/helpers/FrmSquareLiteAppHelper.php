<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

class FrmSquareLiteAppHelper {

	/**
	 * @var FrmSquareLiteSettings|null
	 */
	private static $settings;

	/**
	 * @return string
	 */
	public static function plugin_path() {
		return FrmAppHelper::plugin_path() . '/square/';
	}

	/**
	 * @return string
	 */
	public static function plugin_folder() {
		return basename( self::plugin_path() );
	}

	/**
	 * @return string
	 */
	public static function plugin_url() {
		return FrmAppHelper::plugin_url() . '/square/';
	}

	/**
	 * @return FrmSquareLiteSettings
	 */
	public static function get_settings() {
		if ( ! isset( self::$settings ) ) {
			self::$settings = new FrmSquareLiteSettings();
		}
		return self::$settings;
	}

	/**
	 * @return string
	 *
	 * @psalm-return 'live'|'test'
	 */
	public static function active_mode() {
		return self::get_settings()->settings->test_mode ? 'test' : 'live';
	}

	/**
	 * Add education about Square fees.
	 *
	 * Square is not included in a grandfathered license, so its fees always apply
	 * there even though Stripe fees do not.
	 *
	 * @param string             $content UTM Content for the admin upgrade link.
	 * @param array|false|string $gateway Gateway or list of gateways this applies to.
	 *
	 * @return void
	 */
	public static function fee_education( $content = 'tip', $gateway = false ) {
		if ( ! FrmAddonsController::payment_fees_apply( 'square' ) ) {
			return;
		}

		$classes = 'frm-light-tip show_square';

		if ( $gateway && ! array_intersect( (array) $gateway, array( 'square' ) ) ) {
			$classes .= ' frm_hidden';
		}

		FrmTipsHelper::show_tip(
			array(
				'link'  => array(
					'campaign' => 'square-fee',
					'content'  => $content,
				),
				'tip'   => 'Pay as you go pricing: 3% fee per-transaction + Square fees.',
				'call'  => __( 'Upgrade to save on fees.', 'formidable' ),
				'class' => $classes,
			),
			'p'
		);
	}
}
