=== Formidable Forms - WordPress Form Builder for Contact Forms, Calculators, Quizzes & More ===
Contributors: formidableforms, sswells, srwells
Tags: forms, form builder, custom form, contact form, payment form
Requires at least: 6.3
Tested up to: 7.1
Requires PHP: 7.0
Stable tag: 6.35

The most powerful drag and drop WordPress form builder for contact forms, payment forms, calculators, quizzes, surveys, and data-driven applications.

== Description ==

== The Most Powerful WordPress Form Builder Plugin ==

[Formidable Forms](https://formidableforms.com/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) is the most powerful drag and drop form builder for WordPress. Easily add contact forms, payment forms, survey forms, quiz forms, calculator forms, registration forms, custom forms, data tables, and complete web applications to your website, without any code.

Whether you're a beginner creating your first contact form or a developer building a complex member directory or data-driven application, Formidable Forms scales with you.

Stop paying for a single-purpose contact form plugin. With Formidable's drag and drop form builder, one plugin replaces five, so you can build forms, collect payments, run surveys, grade quizzes, generate online calculators, and build web apps, all inside WordPress without writing a single line of code.

https://youtu.be/7X2BqhRsXcg

[Watch the video overview for the Formidable form builder, calculator, and quiz builder](https://youtu.be/7X2BqhRsXcg)

> <strong>Formidable Pro - The Ultimate WordPress Forms Plugin</strong>
> This plugin is the free version of Formidable Pro, which unlocks email subscription forms, multi-page forms, file upload forms, quiz grading, and conditional logic. Add repeater fields, payment integrations with Stripe and PayPal, cascading dropdown fields, calculated fields, front-end form editing, the AI form builder, and the powerful web application builder.
>
> Formidable Pro is more than a contact form plugin. It's a complete platform for building smart forms and web applications. [Upgrade to the most advanced premium WordPress form builder now!](https://formidableforms.com/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion)
>
> Or start with the [Lite vs Pro comparison](https://formidableforms.com/knowledgebase/what-is-the-difference-between-the-lite-free-and-pro-version/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion).

== Drag and Drop Form Builder for Every Type of WordPress Form ==

Formidable's [drag and drop form maker](https://formidableforms.com/features/drag-drop-form-builder/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) makes it fast to create any form you can imagine. Start from one of [300+ pre-built form templates](https://formidableforms.com/form-templates/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion), design a completely custom form from scratch, or describe what you need and let the AI form builder generate it for you in seconds. Build a simple contact form in minutes, or layer in conditional logic, [multi-step pages](https://formidableforms.com/features/wordpress-multi-step-form/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion), and calculated fields to create sophisticated registration forms, quote forms, and price [calculator forms](https://formidableforms.com/wordpress-calculator-plugin/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion). The form builder is optimized for outstanding speed and server performance, making it one of the fastest WordPress form plugins available.

Unlimited forms are included in the free version, and every form you build is mobile-responsive out of the box. Whether visitors land on your site via desktop, tablet, or phone, your contact forms, survey forms, and payment forms look great and work flawlessly on every device. No other drag and drop form builder for WordPress gives you this depth of functionality starting from the free tier.

== Entry Management for Your Free WordPress Contact Forms ==

Every form submission is stored securely in your WordPress database, so no lead is ever lost. Access entries from the form builder back-end, export to CSV for use in Excel or any other platform, and import leads directly to services like Mailchimp. Formidable is fully GDPR-friendly, giving you controls for IP tracking, saving submissions, and adding GDPR consent fields to any form.

Automate follow-up with customizable email notifications and autoresponders. Set up redirect rules or success messages to guide visitors after form submission. From your first contact form to advanced payment forms and registration forms, every detail of the post-submission experience is in your hands. Built-in [invisible SPAM protection](https://formidableforms.com/features/invisible-spam-protection/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) keeps your entries clean from bots and spam submissions.

== The Only Form Builder Plugin with an Advanced Visual Form Styler ==

Formidable is the only WordPress form builder with a built-in [visual style creator](https://formidableforms.com/features/wordpress-visual-form-styler/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion). Match your contact forms, survey forms, and payment forms to your brand in just a few clicks, no custom CSS required. Adjust colors, fonts, layouts, and field styles to create online forms that blend seamlessly with any WordPress theme. For agencies and developers, the visual form styler means you can deliver beautiful, on-brand forms for every client without touching a line of code.

== Build Smart Survey Forms and Generate Insightful Reports ==

With [Formidable Pro](https://formidableforms.com/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion), you get survey tools that rival SurveyMonkey, without the monthly subscription cost. Build survey forms and poll forms with Net Promoter Score (NPS) fields, Likert scales, star ratings, and image choices. Analyze survey results instantly and display beautiful graphs and charts directly on your WordPress pages and posts. Formidable's survey form builder makes it simple to gather data, understand it, and act on it, all inside WordPress.

== Advanced WordPress Registration Forms for Teams and Events ==

Formidable goes far beyond basic contact form functionality. The [repeater field](https://formidableforms.com/features/dynamically-add-form-fields/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) makes it easy to build comprehensive registration forms for sports teams, events, retreats, courses, and membership sites. Robust marketing integrations and API connections let you funnel registration data to your CRM, email platform, or any other tool in your stack automatically. Whether you're building an event registration form or a complex multi-step membership application, the form builder handles it.

== Payment Forms with Stripe, PayPal, Square, and More ==

Accept credit card payments, subscriptions, and donations directly through your WordPress forms. Formidable integrates with leading payment gateways including Stripe, PayPal, Square, and Authorize.net. Set up a donation form, product order form, event registration payment form, or service booking payment form in minutes. WooCommerce store owners can build custom product configurator forms with dynamic pricing and calculation fields that feed directly into the WooCommerce cart.

Stripe payment forms are available in the free version, supporting ACH, Cash App, Klarna, iDeal, and more. A transaction fee applies without a Pro license. For in-person events and hybrid businesses, payment forms can be set up for cash, manual payment recording, and on-site collection, giving you complete flexibility for online and in-person transactions.

== Build Data-Driven Web Applications with Formidable Views ==

Formidable Forms is not just a WordPress contact form plugin. It's a complete platform for building web applications. With [Formidable Views](https://formidableforms.com/features/display-form-data-views/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion), you can display submitted form data on the front-end of your WordPress site, creating searchable databases, directories, event calendars, job boards, real estate listings, member directories, and more. No additional plugin required. The form builder and application builder are tightly integrated, so you can go from form to full application without ever leaving WordPress.

== Quiz Forms, Online Calculators, and Calculator Forms ==

Formidable's quiz form builder and calculator form builder are industry-leading features that set it apart from every other WordPress form plugin. Build educational assessments, personality quizzes, scored tests, and viral BuzzFeed-style quizzes with ease. For calculator forms and online calculators, the possibilities are endless: mortgage calculators, loan calculators, BMI calculators, price calculators, instant quote calculators, ROI calculators, cost estimators, and more. These interactive calculator forms and online calculators give visitors instant results and give you a powerful lead generation tool. No other drag and drop form builder for WordPress combines quizzes, scored forms, and fully functional online calculators in one free plugin.

== WordPress User Registration Forms and Profile Forms ==

For membership sites and community platforms, Formidable offers advanced customization options for WordPress user registration forms and user profile forms. Enable front-end profile editing so users can update their information without ever visiting the WordPress dashboard. From initial contact form to lead form to final payment form, every step of the user journey is covered by Formidable's drag and drop form builder.

== Advanced Fields and Features for High-Converting Forms ==

Formidable's form builder includes everything you need to create professional, high-converting forms. Multi-page forms with progress bars boost completion rates. Save-and-continue lets users finish long forms on their own schedule. [Cascading dropdowns](https://formidableforms.com/features/cascading-dropdown-lookup-field/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion), conditional logic, partial submissions, and invisible spam protection are all included. Calculated fields power your online calculator forms and instant quote forms automatically.

For developers and agencies, Formidable is the premier WordPress form builder choice. [Customize form HTML](https://formidableforms.com/features/customize-form-html-wordpress/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) directly (similar to Contact Form 7, but with full drag and drop power on top). Extend with hooks and filters. Build complex data-driven web applications with low overhead. Formidable supports the most sophisticated projects while remaining approachable for beginners building their first contact form.

With the AI form builder (Pro), you can describe any form in plain text and have it built for you instantly. Need a multi-step registration form, a quote calculator, or a patient intake form? Just type what you need and the AI generates a fully structured, editable form in seconds. You can also add an AI field directly inside any form to display AI-generated responses based on user input, then include those responses in confirmation messages, email notifications, or [Formidable Views](https://formidableforms.com/features/display-form-data-views/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion). Every form is WCAG-compliant and accessible by default, making your forms usable for all visitors.

https://youtu.be/qkL8rhBRL9s

[How to Build an Instant Quote Form](https://youtu.be/qkL8rhBRL9s)

== Full Feature List ==

* Drag and Drop Form Builder - Create contact forms, payment forms, survey forms, and more visually
* Calculator Forms - Build mortgage calculators, loan calculators, BMI calculators, price calculators, online quote calculators
* Survey Forms - NPS, Likert scale, star rating, image choice fields for powerful survey forms
* [Multi-Step Forms](https://formidableforms.com/features/wordpress-multi-step-form/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) - Multi-page forms with progress bars and conditional logic
* Payment Forms - Stripe, PayPal, Square, Authorize.net payment form integrations online and in-person
* WooCommerce Form Builder - Custom product forms with dynamic pricing
* [Formidable Views](https://formidableforms.com/features/display-form-data-views/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) - Display form data: directories, job boards, event calendars, real estate listings
* [Form Templates](https://formidableforms.com/form-templates/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) - 300+ pre-built form templates for every use case
* Conditional Logic - Smart forms that show and hide fields dynamically
* [File Upload Form](https://formidableforms.com/features/wordpress-multiple-file-upload-form/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) - Accept documents, photos, and files in any form
* Quiz Form Builder - Scored quizzes, personality quizzes, graded assessments, viral quiz forms
* User Registration Form - WordPress registration and profile forms for membership sites
* [PDF Forms](https://formidableforms.com/features/form-to-pdf-wordpress-plugin/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) - Generate PDFs, certificates, and invoices from form submissions
* [Invisible SPAM Protection](https://formidableforms.com/features/invisible-spam-protection/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) - Honeypot, Akismet, reCAPTCHA, hCaptcha, Cloudflare Turnstile
* [Customize Form HTML](https://formidableforms.com/features/customize-form-html-wordpress/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) - Full control over form HTML like Contact Form 7, plus drag and drop
* [Conversational Forms](https://formidableforms.com/conversational-forms/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) - One-question-at-a-time form experience like Typeform
* [Landing Page Forms](https://formidableforms.com/landing-page-forms/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) - Distraction-free form landing pages
* [Repeater Fields](https://formidableforms.com/features/dynamically-add-form-fields/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) - Add multiple rows of fields in registration and order forms
* [Visual Form Styler](https://formidableforms.com/features/wordpress-visual-form-styler/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) - Brand your forms with colors, fonts, and layouts, no CSS required
* [Cascading Dropdown Fields](https://formidableforms.com/features/cascading-dropdown-lookup-field/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) - Dynamic dependent dropdowns for complex forms
* Digital Signatures - Collect signatures in contract and booking forms
* Front-End Editing - Let users edit their own form submissions without logging in
* WCAG-Compliant Forms - Accessible form builder for all users
* AI Form Builder - Create entire forms from a plain text description in seconds

== Payment Forms, Marketing APIs, and Business Integrations ==

Formidable Pro connects your WordPress forms to every major platform in your marketing and business stack. The form builder's integration ecosystem means you never lose a lead or miss a workflow.

**Payment Forms:** Accept online payments with [Stripe Forms](https://formidableforms.com/features/stripe-payments-for-wordpress/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) (one-time or recurring, with ACH, Cash App, Klarna, iDeal support), [PayPal Forms](https://formidableforms.com/features/paypal-wordpress-payments/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) (instant and recurring), and [Authorize.net](https://formidableforms.com/features/authorize-net-payments/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) (one-time payments in order forms and calculator forms). Formidable charges zero transaction fees on all payment forms with a valid license. For in-person payments, cash, and manual payment collection, Formidable's flexible payment form architecture supports hybrid billing workflows.

**Email Marketing:** Direct integrations for **Mailchimp**, **Constant Contact**, **AWeber**, **MailPoet**, **ActiveCampaign**, **HubSpot**, **Salesforce**, **GetResponse**, and **Campaign Monitor** make lead collection seamless. Connect any contact form, survey form, or registration form to your email list in minutes.

**CRM and Automation:** [Zapier](https://formidableforms.com/features/form-entry-routing-with-zapier/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) integration connects your WordPress contact forms and payment forms to thousands of apps. Use SMS notifications via Twilio, sync data to **Zoho CRM**, **HubSpot CRM**, **Salesforce**, **Highrise**, and more. Automate form-triggered workflows without writing code.

**WooCommerce Integration:** As the only WordPress form builder plugin fully integrated with WooCommerce, [Formidable lets you build custom WooCommerce product forms](https://formidableforms.com/features/customizable-woocommerce-forms/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) with variable pricing, configuration options, and calculated totals that flow directly into the cart.

**Multilingual Forms:** Reach a global audience with WPML and Polylang integrations for multilingual WordPress forms.

== WordPress Form Builder for Every Industry and Use Case ==

Formidable is the drag and drop form builder of choice across every industry. Small businesses use it for contact forms and lead capture. Financial services companies build loan calculators and quote forms. HR teams and researchers build survey forms. Schools and event coordinators build registration forms. Educators use the quiz form builder for scored assessments. Nonprofits build donation forms. Legal and medical practices use file upload forms for intake. Membership sites use it for user registration forms. Real estate and job sites build front-end directories. Service businesses use it for booking and appointment forms. Agencies and developers choose Formidable because it handles everything from a simple contact form to a complex web application in a single plugin.

== Formidable Forms Branding Guidelines ==

Formidable Forms may also be referred to as Formidable, Formidable Form Builder, Formidable Pro, or Formidable Views.

== The Best Gravity Forms Alternative, WPForms Alternative, and JotForm Alternative for WordPress ==

If you're looking for an advanced WordPress form builder as a Gravity Forms alternative, Formidable Forms delivers more power at a lower price, with a completely free version that Gravity Forms doesn't offer. As a WPForms alternative, Formidable goes deeper: beyond contact forms into calculator forms, web applications, and data-driven front-end displays that WPForms simply can't match. Looking for a JotForm alternative or Typeform alternative that keeps your data on your own server? Formidable is the answer. All form data stays in your WordPress database, not on an external SaaS platform. Formidable is also the top Contact Form 7 alternative for anyone who has outgrown CF7's limited feature set and wants drag and drop power on top. Compared to SurveyMonkey, Formidable Pro delivers professional survey forms, NPS forms, Likert scale fields, and real-time results directly inside WordPress, without a separate subscription. Ninja Forms users looking for more built-in power will find Formidable's form builder offers calculators, Views, and a web application builder that Ninja Forms add-ons can't replicate in a single plugin. Fluent Forms and Forminator users who need advanced calculator forms and a complete data display layer consistently upgrade to Formidable.

== Credits ==
This online form and quiz builder plugin is created by Steve and Steph Wells and the amazing Strategy11 Team with <a href="https://syedbalkhi.com/">Syed Balkhi</a> as an Advisor.

== Installation ==
1. Go to the Plugins -> 'Add New' page in your WP admin area
2. Search for 'Formidable'
3. Click the 'Install Now' button, then 'Activate'
4. Go to the newly added 'Formidable' menu
5. Click the 'Add New' button to go to the form generator page and create a new email form
6. Insert your newly created lead form, quiz, or survey form on a page or post using the Embed Form pop up. Or insert it manually or into a widget using a shortcode [formidable id=x]. Alternatively use `<?php echo FrmFormsController::show_form(2); ?>` to add it in a theme file.

== Screenshots ==
1. Build a professional WP form without any code.
2. Page for creating a quote form, Stripe payment form, quiz form, and many more.
3. Field Options and CSS Layout Classes
4. Field Options for checkbox fields
5. View, create, edit, and delete entries on the back end from a to-do list, employment application form, and more.
6. Add a form widget into a sidebar
7. Create a contact form in minutes and start collecting submissions right away.
8. Collect payments by adding a Stripe, PayPal, or Square field directly to your form.
9. Add automatic field calculations to build quote, order, and pricing calculator forms.
10. Display submitted entries on the front end as a searchable directory or listing with Formidable Views.

== Frequently Asked Questions ==
= How do I get started with the best forms for WordPress? =
The fastest way to build a form is to use the example we built for you. After you activate Formidable, insert [formidable id=contact-form] on the WordPress page of your choice.

Go to the Formidable page and click "add new". Choose the Contact Us form template or another free template and click "Create".

Next, edit or create a WordPress contact page. Click the "Formidable" button to open the shortcode generator. Choose your new web form and insert it into the WordPress page. Save the page for a beautiful WP contact form, ready to collect and store your leads. The contact form template will get you up and running fast.

= Why isn't WordPress sending emails? =
When you do not receive emails, try the following steps:

   1. Double check the email address in your Email action on the settings page. The [admin_email] shortcode uses the email address from your WordPress Settings -> General page.
   2. Are you receiving other emails from your site (ie comment notifications, forgot password...)? If not, notifications will not work either.
   3. Check your SPAM box.
   4. Try a different address in your settings.
   5. Install WP Mail SMTP or another similar emailing alternative and configure the SMTP settings.
   6. If these steps do not fix the problem and other WP signup emails are not going out, please reach out to your web host.

[Read more about WordPress emails not sending](https://formidableforms.com/wordpress-not-sending-emails-smtp/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) in our blog.

= What types of WordPress forms can I build? =
Combined with our add-ons, Formidable is the most powerful form maker on the market. Here are some types of web forms you can create:

* Custom Contact Form
* Multi-Page Form with progress bar
* Dynamic Form (where fields change based on user's answers)
* Request a Quote Form
* Job Application Form
* Feedback Surveys
* Make a Suggestion
* Testimonials
* Change Requests
* Online Booking
* Event Booking
* Online RSVP Form
* Custom WordPress User Registration Form (Great for membership sites)
* WordPress Login Form
* Custom WordPress User Profile
* WordPress Post Submission (Great for guest posts)
* WooCommerce Form for Products
* Credit Card Form
* Make a Donation Form
* T-Shirt Order Form
* Product Purchase Form
* Lead Capture
* Auto Form with Car Make and Model
* Video Release
* Partnership Agreements
* PTO Request
* Online Petitions
* Signature Form
* Maintenance Request
* Scholarship Application Form
* File Download Form
* Employment Verification
* Make a Referral
* Membership, Customer, Vendor, Conference, and Volunteer Registration
* Camp, Course, School Class, and other Event Registration
* Custom Survey
* Polls
* Quizzes
* Mortgage Calculator
* Car Payment Calculator
* BMI Calculator
* User Age Calculator
* Online Quote Calculator
* Compound Interest Calculator
* Amortization Calculator
* Calorie Intake Calculator
* Pregnancy Due Date Calculator
* Days Between Dates
* Recipe Reviews
* Personality Quiz
* Viral Quiz
* Cosmos Style Quiz
* Create Your Own Adventure Quiz

To see more, visit our [Form Template Gallery](https://formidableforms.com/form-templates/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) which has over 300 pre-made templates.

= Can I see any example online calculators? =
Sure! Here are just a few examples:
* [Advanced Mortgage Calculator](https://formidableforms.com/form-templates/advanced-mortgage-calculator-form/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion)
* [Basic Mortgage Calculator](https://formidableforms.com/form-templates/simple-mortgage-calculator-form/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion)
* [Car Payment Calculator](https://formidableforms.com/form-templates/automobile-payment-calculator-form/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion)
* [Net Promoter Score (NPS) Survey](https://formidableforms.com/form-templates/nps-survey-form/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion)
* [BMI Calculator](https://formidableforms.com/form-templates/bmi-calculator-form/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion) and more Health and Fitness Calculators
* [User Age Calculator](https://formidableforms.com/form-templates/age-calculator-form/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion)
* Online Quote Calculator
* Finance Calculator
* Booking Cost Calculator
* Product Price Calculator

= How can I get access to all advanced features? =
To get access to more features, integrations, and support, [upgrade to Formidable Pro](https://formidableforms.com/?utm_source=wprepo&utm_medium=link&utm_campaign=liteversion). A Pro license gives you access to the full version of Formidable for more advanced options, Formidable Views, graphs and stats, priority support, and Formidable Add-ons!

= Can I create a payment form? =

Yes! We make it easy to accept payments using Stripe, Square, PayPal, and Authorize.net.

Our Stripe integration helps you quickly accept credit card payments online. Our PayPal forms allow you to accept PayPal payments, subscriptions, and donations online.

= Which field types does Formidable offer? =

Our custom form and quiz builder comes with all the powerful fields that you need to create a solution-focused form, fast!

* Single line text - Great for name, phone number, address, and more.
* Name
* Email
* Website/URL
* Paragraph text
* Checkboxes and radio buttons
* Dropdown select boxes
* Number
* Phone number
* Hidden fields
* User ID
* HTML block - Great for custom HTML
* Captcha for Google reCAPTCHA (invisible V2 or checkbox V2, V3), hCaptcha, or Cloudflare Turnstile.
* GDPR - Great for compliance with General Data Protection Regulation (GDPR).
* Address - Power it up with Google address autofill and geolocation with add-ons.

Here is a list of our advanced premium fields that will come in handy:

* File Upload
* Rich Text
* Date
* Time
* Scale
* Star Rating
* Ranking
* Range Slider
* Toggle
* Dynamic - Great for creating relationships between entries.
* Repeater - Great for registering multiple kids, job history, and much more.
* Tags
* Summary - Great to review responses before submit.
* Lookup - Great for cascading lookups like country, city, state.
* Section Heading
* Page Break
* Embed Form - Great for reusing the same set of fields in multiple places.
* Password Field
* Signature - Great for contracts and booking.
* AI - Display AI-generated responses inside your form using OpenAI. Great for personalized results, recommendations, and dynamic content.

Additionally, our Payment fields will help you create a credit card form, donation form, or booking form.

* Single Item
* Multiple Items
* Checkbox Items
* Dropdown Items
* Product Quantity
* Total
* Credit Card (Stripe, Square, or Authorize.net)

= Can I import and export submissions? =

Yes, it's easy to import and export. This is incredibly useful for developers and agencies who are building websites for clients. You can also create custom form templates to use on client websites.

You can also import from other WordPress contact form plugins such as [Gravity Forms](https://wordpress.org/plugins/formidable-gravity-forms-importer/) and Pirate Forms. Although we don't have an importer available, this is also a great Caldera Forms alternative since it's no longer supported.

= Can I integrate with my CRM or email marketing service? =

Yes! We know that marketing is the key to growing your business. That's why Formidable allows you to connect your WP form (email form, payment form, etc.) with the marketing platform of your choice. You can easily send data from WordPress to your favorite CRM, email newsletter, and other marketing platforms.

Here is a list of our CRM and email marketing integrations:

* Mailchimp
* AWeber
* Constant Contact
* GetResponse
* MailPoet
* Active Campaign
* Salesforce CRM
* HubSpot CRM
* Campaign Monitor
* Highrise CRM

Using our Zapier integration, you can easily connect your website with over 5,000+ marketing apps including:

* SendInBlue
* Zoho CRM
* Zoho Mail
* Zoho Invoice
* Agile CRM
* Slack
* Trello
* Infusionsoft by Keap
* Microsoft Excel
* Dropbox
* PipeDrive CRM
* HelpScout
* Zendesk
* Freshbooks
* Freshsales
* Intercom
* Click Funnels
* Microsoft Dynamics 365 CRM
* Capsule CRM
* Insightly CRM
* Printfection
* Acuity Scheduling
* Quickbooks Online

See all [Formidable Zapier Integrations](https://zapier.com/apps/formidable/integrations).

== Changelog ==
= 6.35 =
* Security: More strict sanitizing is now applied to entry key values before it gets used in the HTML of a form.
* Security: The value that records who last saved an entry is now always set from the current user, not allowing for any custom values unless importing.
* New: The shortcodes list now offers show options for more types, and long names are truncated so the list stays readable.
* New: The Processor column on the Payments list page can now be sorted.
* New: A message is now shown on the Payments list page after bulk deleting.
* New: The required email input used for Stripe Link payments will now display a required asterisk like other required inputs.
* New: A new frm_builder_after_field_label hook has been added for adding content after a label in the builder.
* New: A new frm_payment_user_id filter has been added for setting which user a payment belongs to.
* Performance: The builder now loads much faster when there are a lot of fields. Fields loaded with AJAX are now loaded in asynchronous batches.
* Performance: The way the denylist is checked has been optimized, so spam checks are much faster when a large amount of text is submitted.
* Performance: Pricing updates for Stripe payments are now debounced, and are skipped on pages with no payment intents.
* Fix: A subscription would not get cancelled after it reached its Recurring Payment Limit.
* Fix: Payment status actions could run twice for the same Stripe Link payment.
* Fix: Multiple customer objects would get created for Stripe Link recurring payments.
* Fix: Subscription plan details would not update after changing the trial period.
* Fix: A Stripe Link redirect would use the URL from Form settings instead of the URL in the confirmation action that ran.
* Fix: Square payments would not correctly follow conditional logic when two Square actions were used.
* Fix: The wrong amount would get used when verifying a buyer with Square.
* Fix: Connecting and disconnecting Square would go by whichever mode was active instead of the mode that was selected.
* Fix: In Pro, the dropdown on a style card would not populate, leaving no way to delete a style or set one as the default.
* Fix: In Pro, a section added after a partially sized field would move into the previous row after a reload.
* Fix: Adding the frm_first layout class would not start a new row for a group.
* Fix: A field id used in a description would not get switched when a form was duplicated or imported.
* Fix: Creating a field with a missing or invalid options value would raise a PHP warning and store null.
* Fix: The Embeds column would only update when a post was inserted, so it went stale when a page was updated or deleted.
* The old hard coded widths for the frm_grid_2 through frm_grid_10 classes have been removed from the generated stylesheets, helping to reduce the file size of styles used on the front end.

= 6.34 =
* Security: Additional validation has been added to guarantee that submitted HTML in form data by untrusted users cannot be used for XSS.
* New: Address fields are now included in Lite!
* New: Address field data is included in PayPal Commerce credit card payments when defined in payment action settings to help prevent entries from incorrectly getting flagged as fraudulent.
* New: Buttons on admin pages will now shrink slightly when clicked, to give a more tactile response.
* Fix: Additional checks have been added to make sure that pages will not result in 404 errors when Gated Content actions are not actually defined for the page. In addition, when a custom permission is used for handling access to a private page, the custom permission is properly checked for.
* Fix: Captcha field labels no longer use labels to prevent orphaned label issues since the label cannot reference the input in an iframe.
* Fix: A JS error would occur when removing the last layout class from a field.
* Fix: The JS spam token would get added to a form multiple times when multiple forms were on a page.

= 6.33.1 =
* Fix: Public taxonomy pages could result in 404 errors, caused by a missing check in the new Gated Content actions.

[See changelog for all versions](https://raw.githubusercontent.com/Strategy11/formidable-forms/master/changelog.txt)

== Upgrade Notice ==
= 6.35 =
This version fixes security-related bugs. Upgrade immediately.
