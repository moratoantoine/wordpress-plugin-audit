<?php
/**
 * Inline modal wrapper used inside field settings.
 *
 * @package Formidable
 *
 * @var array $args Modal arguments: dismiss-icon (bool), show (bool), class (string), id (string), title (string), inside_class (string), callback (callable), args (mixed).
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

if ( ! $args['dismiss-icon'] ) {
	$args['class'] .= ' frm-modal-no-dismiss';
}

if ( ! $args['show'] ) {
	$args['class'] .= ' frm_hidden';
}
?>
<div class="frm-inline-modal frm-modal postbox <?php echo esc_attr( $args['class'] ); ?>" id="<?php echo esc_attr( $args['id'] ); ?>">
	<?php if ( $args['dismiss-icon'] ) { ?>
		<a href="#" class="dismiss" title="<?php esc_attr_e( 'Close', 'formidable' ); ?>">
			<?php FrmAppHelper::icon_by_class( 'frmfont frm_close_icon', array( 'aria-label' => __( 'Close', 'formidable' ) ) ); ?>
		</a>
	<?php } ?>

	<?php if ( $args['title'] ) { ?>
		<ul class="frm-nav-tabs">
			<li class="frm-tabs">
				<a href="#">
					<?php echo esc_html( $args['title'] ); ?>
				</a>
			</li>
		</ul>
	<?php } ?>

	<div class="<?php echo esc_attr( $args['inside_class'] ); ?>">
		<?php call_user_func( $args['callback'], $args['args'] ); ?>
	</div>
</div>
