<?php
/**
 * Value format setting.
 *
 * @package Formidable
 *
 * @var array $field      Field data including 'id' and 'format'.
 * @var array $attributes HTML attributes for the wrapping paragraph.
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}
?>
<p <?php FrmAppHelper::array_to_html_params( $attributes, true ); ?>>
	<label for="frm_format_<?php echo esc_attr( absint( $field['id'] ) ); ?>" class="frm_help" title="<?php esc_attr_e( 'Insert the format you would like to accept. Use a regular expression starting with ^ or an exact format like (999)999-9999.', 'formidable' ); ?>">
		<?php esc_html_e( 'Format', 'formidable' ); ?>
	</label>
	<span class="frm-with-right-icon frm-block">
		<input type="text" class="frm_long_input frm_format_opt" value="<?php echo esc_attr( $field['format'] ); ?>" name="field_options[format_<?php echo absint( $field['id'] ); ?>]" id="frm_format_<?php echo absint( $field['id'] ); ?>" data-fid="<?php echo intval( $field['id'] ); ?>" />
		<?php
		FrmAppHelper::icon_by_class(
			'frmfont frm_more_horiz_solid_icon frm-show-inline-modal frm-input-icon',
			array(
				'data-open' => 'frm-input-mask-box',
				'title'     => esc_attr__( 'Toggle Options', 'formidable' ),
				'tabindex'  => '0',
			)
		);
		?>
	</span>
</p>
