<?php
/**
 * Generate options with AI button.
 *
 * @package Formidable
 *
 * @var array $args       Arguments including 'button_text' and 'show_pill'.
 * @var array $attributes HTML attributes for the button.
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}
?>
<button <?php FrmAppHelper::array_to_html_params( $attributes, true ); ?>>
	<?php FrmAppHelper::icon_by_class( 'frmfont frm-ai-form-icon frm_svg15', array( 'aria-label' => __( 'Generate options with AI', 'formidable' ) ) ); ?>
	<span><?php echo esc_html( $args['button_text'] ?? __( 'Generate with AI', 'formidable' ) ); ?></span>
	<?php if ( isset( $args['show_pill'] ) ) : ?>
		<?php FrmAppHelper::show_pill_text( __( 'BETA', 'formidable' ) ); ?>
	<?php endif; ?>
</button>
