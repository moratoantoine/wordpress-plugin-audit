<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

$limit = $action_control->action_options['limit'];

if ( 'paypal' === $action_control->id_base ) {
	// The PayPal add-on may overwrite this so change it back.
	$limit = 1;
}

// Remove limit for Stripe action when Stripe add-on is active
if ( 'stripe' === $action_control->id_base && class_exists( 'FrmStrpAppHelper' ) ) {
	$limit = 99;
}

$single_action_attrs = array_merge(
	$data,
	array(
		'href'            => 'javascript:void(0)',
		'class'           => $classes . ' button frm-button-secondary frm-button-sm frm-with-icon frm-ml-auto-force frm-fadein-down-short',
		'data-limit'      => $limit,
		'data-actiontype' => $action_control->id_base,
	)
);

if ( 'paypal' === $action_control->id_base ) {
	$action_control->name = 'PayPal Commerce';
}

// An action that needs a plan upgrade, as opposed to one this license can install with a single click.
$is_locked = isset( $data['data-upgrade'] ) && ! isset( $data['data-oneclick'] );

$li_classes = $group_class;

if ( isset( $data['data-upgrade'] ) ) {
	$li_classes .= ' frm-not-installed';
}

if ( $is_locked ) {
	$li_classes .= ' frm-action-locked';
}
?>
<li class="frm-card-item frm-card-item--outlined frm-action<?php echo esc_attr( $li_classes ); ?>" tabindex="0">
	<div class="frm-h-stack-xs frm-w-full">
		<span class="frm-border-icon frm-shrink-0">
			<?php FrmAppHelper::icon_by_class( $action_control->action_options['classes'], FrmFormActionsController::get_action_icon_atts( $action_control ) ); ?>
		</span>

		<div class="frm-flex-col frm-min-w-0">
			<h3 class="frm-h-stack-xs frm-capitalize">
				<?php
				if ( $is_locked ) {
					FrmAppHelper::icon_by_class( 'frmfont frm_lock_icon frm_svg15', array( 'aria-label' => __( 'Lock icon', 'formidable' ) ) );
				}
				?>
				<span class="frm-font-medium frm-white-space-nowrap"><?php echo esc_html( str_replace( 'Add to ', '', $action_control->name ) ); ?></span>
				<?php if ( ! empty( $action_control->action_options['is_new'] ) ) { ?>
					<?php FrmAppHelper::show_pill_text(); ?>
				<?php } elseif ( ! empty( $action_control->action_options['is_beta'] ) ) { ?>
					<?php FrmAppHelper::show_pill_text( __( 'BETA', 'formidable' ) ); ?>
				<?php } ?>
			</h3>
			<?php if ( ! empty( $action_control->action_options['description'] ) ) { ?>
				<p class="frm-truncate"><?php echo esc_html( $action_control->action_options['description'] ); ?></p>
			<?php } ?>
		</div>

		<a <?php FrmAppHelper::array_to_html_params( $single_action_attrs, true ); ?>>
			<?php if ( $is_locked ) { ?>
				<span><?php esc_html_e( 'Upgrade', 'formidable' ); ?></span>
			<?php } else { ?>
				<?php FrmAppHelper::icon_by_class( 'frmfont frm_plus_icon' ); ?>
				<span><?php echo esc_html_x( 'Add', 'form action', 'formidable' ); ?></span>
			<?php } ?>
		</a>

		<?php if ( ! empty( $action_control->action_options['keywords'] ) ) { ?>
			<span class="frm_hidden"><?php echo esc_html( $action_control->action_options['keywords'] ); ?></span>
		<?php } ?>
	</div>
</li>
