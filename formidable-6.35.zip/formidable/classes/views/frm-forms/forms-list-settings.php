<?php
/**
 * Template for the forms list settings
 *
 * @since 6.32
 *
 * @package Formidable
 *
 * @var int       $per_page
 * @var array     $columns
 * @var array     $hidden
 * @var array     $skip_cols
 * @var bool      $show_screen_options
 * @var WP_Screen $screen
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}
?>
<div id="frm-forms-list-settings" class="frm_hidden frm-p-2xs">
	<div class="frm-collapsible-box">
		<a href="#" class="frm-collapsible-box__btn">
			<?php
			esc_html_e( 'Columns', 'formidable' );
			FrmAppHelper::icon_by_class( 'frmfont frm_arrowup6_icon' );
			?>
		</a>

		<?php
		$attrs = array(
			'class' => 'frm-collapsible-box__content',
		);

		if ( ! $show_screen_options ) {
			$attrs['id'] = 'adv-settings';
			wp_nonce_field( 'screen-options-nonce', 'screenoptionnonce', false );
		}
		?>
		<div <?php FrmAppHelper::array_to_html_params( $attrs, true ); ?>>
			<div class="frm-forms-list-column-checkboxes">
				<?php
				foreach ( $columns as $key => $label ) {
					if ( in_array( $key, $skip_cols, true ) ) {
						continue;
					}

					$is_hidden = in_array( $key, $hidden, true );
					?>
					<label>
						<input
							type="checkbox"
							class="hide-column-tog"
							value="<?php echo esc_attr( $key ); ?>"
							data-wp-column-input-id="<?php echo esc_attr( $key ); ?>-hide"
							<?php checked( ! $is_hidden ); ?>
						/>
						<?php echo esc_html( $label ); ?>
					</label>
					<?php
				}//end foreach
				?>
			</div>
		</div>
	</div>

	<hr />

	<div class="frm-flex frm-items-center frm-justify-between frm-mb-sm frm-pt-2xs">
		<label for="frm-forms-list-show-desc"><?php esc_html_e( 'Description Excerpt', 'formidable' ); ?></label>
		<?php
		FrmHtmlHelper::toggle(
			'frm-forms-list-show-desc',
			'frm_forms_show_desc',
			array(
				'echo'    => true,
				'checked' => 'excerpt' === FrmAppHelper::simple_get( 'mode', 'sanitize_title' ),
			)
		);
		?>
	</div>

	<div class="frm-flex frm-items-center frm-justify-between frm-mb-sm">
		<label for="frm-forms-list-per-page"><?php esc_html_e( 'Items per page', 'formidable' ); ?></label>
		<input
			type="number"
			id="frm-forms-list-per-page"
			value="<?php echo intval( $per_page ); ?>"
			min="1"
			data-wp-screen-option-id="formidable_page_formidable_per_page"
		/>
	</div>

	<hr />

	<div style="text-align: right;" class="frm-pt-2xs frm-pb-xs">
		<button type="button" class="frm-button-primary button-primary" id="frm-save-forms-list-settings-btn"><?php esc_html_e( 'Apply', 'formidable' ); ?></button>
	</div>
</div>
