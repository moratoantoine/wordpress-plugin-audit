<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

class FrmPayPalLiteHooksController {

	/**
	 * @return void
	 */
	public static function load_hooks() {
		add_action( 'frm_enqueue_form_scripts', 'FrmPayPalLiteActionsController::maybe_load_scripts' );
		add_filter( 'frm_validate_credit_card_field_entry', 'FrmPayPalLiteActionsController::remove_cc_validation', 20, 3 );

		add_filter( 'frm_payment_gateways', 'FrmPayPalLiteAppController::add_gateway' );

		add_action( 'init', 'FrmPayPalLiteConnectHelper::check_for_redirects' );

		// Use 20 so this happens after the Stripe add-on.
		add_filter( 'frm_pro_show_card_callback', 'FrmPayPalLiteActionsController::maybe_show_card', 20, 2 );

		add_filter( 'frm_show_normal_field_type', 'FrmPayPalLiteFieldsController::hide_paypal_order_fields', 10, 3 );
	}

	/**
	 * @return void
	 */
	public static function load_admin_hooks() {
		add_action( 'frm_add_form_option_section', 'FrmPayPalLiteActionsController::actions_js' );

		// Use 99 so we overwrite the PayPal add-on settings.
		// These are called explicitly below the Lite PayPal settings.
		add_filter( 'frm_add_settings_section', 'FrmPayPalLiteSettingsController::add_settings_section', 99 );
		add_action( 'frm_update_settings', 'FrmPayPalLiteSettingsController::process_form' );

		// Hook into update_option to preserve test_mode when add-on saves
		add_action( 'update_option_frm_paypal_options', 'FrmPayPalLiteSettingsController::preserve_test_mode_on_update', 10, 2 );

		add_filter( 'frm_before_save_payment_action', 'FrmPayPalLiteActionsController::before_save_settings', 20, 2 );

		// Hook into after payment type to render Product Name and Product Type fields.
		add_action( 'frm_payments_settings_recurring_product_info', 'FrmPayPalLiteActionsController::add_paypal_subscription_settings_from_hook' );

		// Hook into after recurring to render PayPal Settings and PayPal Button Settings sections.
		add_action( 'frm_payments_settings_after_recurring', 'FrmPayPalLiteActionsController::add_action_options' );
		add_action( 'frm_payments_settings_after_recurring', 'FrmPayPalLiteActionsController::add_button_settings_section', 99 );

		add_filter(
			'frm_paypal_action_options',
			function ( $options ) {
				// Make actions using the PayPal add-on use the same icon we use in Lite.
				$options['classes'] = 'frmfont frm_paypal_icon';
				return $options;
			}
		);

		add_action( 'frm_field_options_before_label', 'FrmPayPalLiteFieldsController::add_paypal_order_field_note', 10, 3 );

		if ( defined( 'DOING_AJAX' ) ) {
			self::load_ajax_hooks();
		}
	}

	/**
	 * @return void
	 */
	private static function load_ajax_hooks() {
		add_action( 'wp_ajax_frm_paypal_oauth', 'FrmPayPalLiteAppController::handle_oauth' );
		add_action( 'wp_ajax_frm_paypal_disconnect', 'FrmPayPalLiteAppController::handle_disconnect' );

		$frm_paypal_events_controller = new FrmPayPalLiteEventsController();
		add_action( 'wp_ajax_nopriv_frm_paypal_process_events', array( &$frm_paypal_events_controller, 'process_events' ) );
		add_action( 'wp_ajax_frm_paypal_process_events', array( &$frm_paypal_events_controller, 'process_events' ) );

		// Verify PayPal Lite sites.
		add_action( 'wp_ajax_nopriv_frm_paypal_lite_verify', 'FrmPayPalLiteConnectHelper::verify' );

		add_action( 'wp_ajax_frm_paypal_get_amount', 'FrmPayPalLiteAppController::get_amount' );
		add_action( 'wp_ajax_nopriv_frm_paypal_get_amount', 'FrmPayPalLiteAppController::get_amount' );

		add_action( 'wp_ajax_frm_paypal_create_order', 'FrmPayPalLiteAppController::create_order' );
		add_action( 'wp_ajax_nopriv_frm_paypal_create_order', 'FrmPayPalLiteAppController::create_order' );

		add_action( 'wp_ajax_frm_paypal_create_subscription', 'FrmPayPalLiteAppController::create_subscription' );
		add_action( 'wp_ajax_nopriv_frm_paypal_create_subscription', 'FrmPayPalLiteAppController::create_subscription' );

		add_action( 'wp_ajax_frm_paypal_report_error', 'FrmPayPalLiteAppController::report_error' );
		add_action( 'wp_ajax_nopriv_frm_paypal_report_error', 'FrmPayPalLiteAppController::report_error' );

		add_action( 'wp_ajax_frm_paypal_render_seller_status', 'FrmPayPalLiteConnectHelper::handle_render_seller_status' );

		add_action( 'wp_ajax_frm_add_form_action', 'FrmPayPalLiteActionsController::maybe_modify_new_action_post_data', 1 );
	}
}
