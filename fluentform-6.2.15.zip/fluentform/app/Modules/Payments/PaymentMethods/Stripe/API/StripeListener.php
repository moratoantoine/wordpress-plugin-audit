<?php

namespace FluentForm\App\Modules\Payments\PaymentMethods\Stripe\API;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

use FluentForm\App\Helpers\Helper;
use FluentForm\App\Models\Submission;
use FluentForm\App\Models\Subscription;
use FluentForm\App\Models\Transaction;
use FluentForm\Framework\Helpers\ArrayHelper;
use FluentForm\App\Modules\Payments\PaymentHelper;
use FluentForm\App\Modules\Payments\PaymentMethods\BaseProcessor;
use FluentForm\App\Modules\Payments\PaymentMethods\Stripe\StripeProcessor;
use FluentForm\App\Modules\Payments\PaymentMethods\Stripe\StripeSettings;

class StripeListener
{

    public function verifyIPN()
    {
        // SECURITY (FINDING-19): verify the Stripe webhook signature against the configured
        // signing secret before trusting the payload. Previously the signature check was
        // commented out and verifySignature() used a shared hardcoded whsec_, so the handler
        // relied solely on the event re-fetch — an attacker who knew a valid event id could
        // steer processing. Mirror the pro listener: reject forged/unsigned events up front.
        $signature = isset($_SERVER['HTTP_STRIPE_SIGNATURE']) ? $_SERVER['HTTP_STRIPE_SIGNATURE'] : '';

        // retrieve the request's body and parse it as JSON
        $body = @file_get_contents('php://input');

        $webhookSecret = get_option('fluentform_stripe_webhook_secret', '');
        if ($webhookSecret) {
            if (!$signature) {
                status_header(401);
                exit('Missing Stripe signature header');
            }
            if (!$this->verifySignature($body, $signature, $webhookSecret)) {
                status_header(403);
                exit('Invalid Stripe signature');
            }
        }

        $event = json_decode($body);

        if (!$event || empty($event->id)) {
            return;
        }

        $eventId = $event->id;

        if ($eventId) {
            status_header(200);
            try {
                $formId = StripeSettings::guessFormIdFromEvent($event);

                $event = $this->retrive($eventId, $formId);

                if ($event && !is_wp_error($event)) {
                    $eventType = $event->type;
                    $result = null;

                    if ($eventType == 'charge.succeeded' || $eventType == 'charge.captured') {
                        $result = $this->handleChargeSucceeded($event);
                    } else if ($eventType == 'invoice.payment_succeeded') {
                        $result = $this->maybeHandleSubscriptionPayment($event);
                    } else if ($eventType == 'charge.refunded') {
                        $this->handleChargeRefund($event);
                    } else if ($eventType == 'customer.subscription.deleted') {
                        $this->handleSubscriptionCancelled($event);
                    } else if ('checkout.session.completed' == $eventType || 'checkout.session.async_payment_succeeded' == $eventType) {
                        $result = $this->handleCheckoutSessionCompleted($event);
                    } elseif ('checkout.session.async_payment_failed' === $eventType) {
                        $this->handleCheckoutSessionAsyncPaymentFailed($event);
                    } elseif ('charge.failed' === $eventType) {
                        $this->handleChargeFailed($event);
                    } else if($eventType == 'customer.subscription.updated') {
                        // maybe we have to handle the
                    }

                    if (is_wp_error($result) && 'stripe_settlement_retry' === $result->get_error_code()) {
                        status_header(503);
                        exit('Payment settlement temporarily unavailable');
                    }
                }
            } catch (\Exception $e) {
                return; // No event found for this account
            }
        } else {
            status_header(500);
            die('-1'); // Failed
        }
        die('1');
    }

    // This is an onetime payment success
    private function handleChargeSucceeded($event)
    {
        $charge = $event->data->object;

        $meta = (array) $charge->metadata;

        $transactionId = ArrayHelper::get($meta, 'transaction_id');

        if(!$transactionId) {
            $transaction = Transaction::byChargeId($charge->payment_intent)->first();
            if(!$transaction) {
                return;
            }
        } else {
            $submissionId = ArrayHelper::get($meta, 'submission_id');
            $transaction = Transaction::bySubmission($submissionId)
                ->where('id', $transactionId)
                ->where('payment_method', 'stripe')
                ->first();
        }

        if (!$transaction) {
            return;
        }

        // Ignore replayed/late events for terminal states; 'failed'/'requires_capture' stay live.
        if (in_array($transaction->status, ['paid', 'refunded', 'partially-refunded', 'cancelled'], true)) {
            return;
        }

        // A delayed method settles long after hosted Checkout completed, and this is the one event every documented
        // endpoint receives for it. Cards settle on the return redirect or checkout.session.completed; settling them
        // here as well would race those and fire the form actions twice.
        if ('onetime' === $transaction->transaction_type && $this->isDelayedCharge($charge)) {
            $result = $this->settleCheckoutSession($transaction);
            if ($result) {
                return $result;
            }
        }

        // We have the transaction so we have to update some fields
        $updateData = array(
            'status' => 'paid'
        );

        if (!$transaction->card_last_4) {
            if (!empty($charge->source->last4)) {
                $updateData['card_last_4'] = $charge->source->last4;
            } else if (!empty($charge->payment_method_details->card->last4)) {
                $updateData['card_last_4'] = $charge->payment_method_details->card->last4;
            }
        }
        if (!$transaction->card_brand) {
            if (!empty($charge->source->brand)) {
                $updateData['card_brand'] = $charge->source->brand;
            } else if (!empty($charge->payment_method_details->card->network)) {
                $updateData['card_brand'] = $charge->payment_method_details->card->network;
            }
        }

        if(!$transaction->charge_id) {
            $updateData['charge_id'] = $charge->payment_intent;
        }

        Transaction::where('id', $transaction->id)->update($updateData);

        // We have to fire transaction paid hook here

    }

    // False when the charge is not for an unfulfilled hosted Checkout entry, which leaves it to the plain transaction update.
    private function settleCheckoutSession($transaction)
    {
        $sessionId = Helper::getSubmissionMeta($transaction->submission_id, 'stripe_session_id');
        $submission = $sessionId ? Submission::find($transaction->submission_id) : null;

        if (!$submission || Helper::getSubmissionMeta($submission->id, 'is_form_action_fired') == 'yes') {
            return false;
        }

        // Nothing is marked paid until the session settles it, so an attempt that fails stays retryable on a resend.
        $session = CheckoutSession::retrieve($sessionId, ['expand' => ['subscription.latest_invoice.payment_intent', 'payment_intent']], $submission->form_id);

        if (!$session || is_wp_error($session)) {
            return new \WP_Error('stripe_settlement_retry', 'Unable to retrieve Stripe Checkout session.');
        }

        // The session's own intent decides whether the entry is paid; this event only prompts the check.
        (new StripeProcessor())->processStripeSession($session, $submission, $transaction);

        return true;
    }

    // A delayed first invoice settles before the entry is linked to its Stripe subscription, so the vendor-id lookup misses it.
    private function settleDelayedSubscriptionInvoice($invoice)
    {
        $meta = isset($invoice->subscription_details->metadata) ? (array) $invoice->subscription_details->metadata : [];

        $transaction = Transaction::bySubmission(intval(ArrayHelper::get($meta, 'submission_id')))
            ->where('id', intval(ArrayHelper::get($meta, 'transaction_id')))
            ->where('status', 'pending')
            ->first();

        if (!$transaction || empty($invoice->charge)) {
            return false;
        }

        ApiRequest::set_secret_key(StripeSettings::getSecretKey($transaction->form_id));
        $charge = ApiRequest::request([], 'charges/' . $invoice->charge, 'GET');

        if (!$charge || is_wp_error($charge)) {
            return new \WP_Error('stripe_settlement_retry', 'Unable to retrieve Stripe charge.');
        }

        return $this->isDelayedCharge($charge) ? $this->settleCheckoutSession($transaction) : false;
    }

    private function isDelayedCharge($charge)
    {
        $delayedMethods = ['acss_debit', 'au_becs_debit', 'bacs_debit', 'boleto', 'customer_balance', 'konbini', 'oxxo', 'sepa_debit', 'sofort', 'us_bank_account'];

        return isset($charge->payment_method_details->type) && in_array($charge->payment_method_details->type, $delayedMethods, true);
    }

    /*
     * Handle Subscription Payment IPN
     * Refactored in version 2.0
     */
    private function maybeHandleSubscriptionPayment($event)
    {
        $data = $event->data->object;

        $subscriptionId = false;
        if (property_exists($data, 'subscription')) {
            $subscriptionId = $data->subscription;
        }

        if (!$subscriptionId) {
            return;
        }

        $result = $this->settleDelayedSubscriptionInvoice($data);
        if ($result) {
            return $result;
        }

        $subscription = Subscription::byVendorSubscriptionId($subscriptionId)
            ->where('vendor_customer_id', $data->customer)
            ->first();

        if (!$subscription || 'cancelled' === $subscription->status) {
            return;
        }

        // Record still-due cycles for fixed plans completed under legacy counting.
        if ('completed' === $subscription->status) {
            if (!$subscription->bill_times || 'subscription_cycle' !== ($data->billing_reason ?? null)) {
                return;
            }

            $counter = new StripeProcessor();
            list($recordedInstallments) = $counter->getPaymentCountsAndTotal($subscription->id, 'stripe');
            if ($recordedInstallments >= $subscription->bill_times) {
                return;
            }
        }

        $submission = Submission::find($subscription->submission_id);

        if (!$submission) {
            return;
        }

        $processor = new StripeProcessor();
        $processor->setSubmissionId($submission->id);

        if ('trialling' === $subscription->status && 'subscription_cycle' === ($data->billing_reason ?? null)) {
            $subscription = $processor->updateSubscriptionStatus($subscription, 'active');
        }

        $transactionData = $this->createSubsTransactionDataFromInvoice($data, $subscription, $submission);

        // We may have an already exist session charge that we have to update
        $pendingTransaction = Transaction::bySubmission($submission->id)
            ->whereNull('charge_id')
            ->where('status', 'pending')
            ->first();

        // was: only pending rows; 6.2.13 and earlier recorded a $0 first invoice with no charge_id and status '0',
        // and the subscription kept that invoice, so a resend of its event must reconcile the row, not add one.
        if (!$pendingTransaction && empty($data->payment_intent) && $this->isStoredInitialInvoice($subscription, $data)) {
            $pendingTransaction = Transaction::bySubmission($submission->id)
                ->subscriptionType()
                ->where('subscription_id', $subscription->id)
                ->whereNull('charge_id')
                ->orderBy('id', 'ASC')
                ->first();
        }

        if($pendingTransaction) {
            unset($transactionData['transaction_hash']);
            unset($transactionData['created_at']);

            Transaction::where('id', $pendingTransaction->id)->update($transactionData);
        } else {
            $processor->recordSubscriptionCharge($subscription, $transactionData);
        }
    }

    private function isStoredInitialInvoice($subscription, $invoice)
    {
        // The accessor unserializes with classes disallowed; the incomplete object still exposes its fields as an array
        $stored = (array) $subscription->vendor_response;

        return !empty($stored['id']) && $stored['id'] === $invoice->id;
    }

    /*
     * Refactored at version 2.0
     * We are logging refunds now for both subscription and
     * One time payments
     */
    private function handleChargeRefund($event)
    {
        (new StripeProcessor())->handleRefund($event);
    }

    /*
     * Handle Subscription Canceled
     */
    private function handleSubscriptionCancelled($event)
    {
        $data = $event->data->object;
        $subscriptionId = $data->id;

        $subscription = Subscription::byVendorSubscriptionId($subscriptionId)
            ->where('status', '!=', 'completed')
            ->first();

        if (!$subscription || $subscription->status == 'cancelled') {
            return;
        }

        do_action_deprecated(
            'fluentform_form_submission_activity_start',
            [
                $subscription->form_id
            ],
            FLUENTFORM_FRAMEWORK_UPGRADE,
            'fluentform/form_submission_activity_start',
            'Use fluentform/form_submission_activity_start instead of fluentform_form_submission_activity_start.'
        );

        do_action('fluentform/form_submission_activity_start', $subscription->form_id);

        PaymentHelper::recordSubscriptionCancelled($subscription, $data);
    }


    private function handleChargeFailed($event)
    {
        $meta = (array) $event->data->object->metadata;
        $sessionId = Helper::getSubmissionMeta(intval(ArrayHelper::get($meta, 'submission_id')), 'stripe_session_id');

        // A card declined inside hosted Checkout is retried on the Checkout page, so only a failed delayed debit is final.
        if ($sessionId && $this->isDelayedCharge($event->data->object)) {
            $event->data->object = (object) ['id' => $sessionId, 'metadata' => $meta];
            $this->handleCheckoutSessionAsyncPaymentFailed($event);
        }
    }

    private function handleCheckoutSessionAsyncPaymentFailed($event)
    {
        $data = $event->data->object;
        $metaData = (array) $data->metadata;
        $formId = ArrayHelper::get($metaData, 'form_id');

        $session = CheckoutSession::retrieve($data->id, [], $formId);
        if (!$session || is_wp_error($session)) {
            return;
        }

        $submission = Submission::find(intval($session->client_reference_id));
        $transaction = $submission ? Transaction::bySubmission($submission->id)
            ->where('form_id', $submission->form_id)
            ->where('id', intval(ArrayHelper::get($metaData, 'transaction_id')))
            ->first() : null;
        if (!$submission || !$transaction) {
            return;
        }

        // A row already settled or reversed is never downgraded by a late or replayed failure event.
        $isStillAwaitingSettlement = !in_array($transaction->status, ['paid', 'failed'], true)
            && 'paid' !== $submission->payment_status
            && !PaymentHelper::isReversedPaymentStatus($submission->payment_status)
            && 'yes' !== Helper::getSubmissionMeta($submission->id, 'is_form_action_fired');
        if (!$isStillAwaitingSettlement) {
            return;
        }

        $processor = new StripeProcessor();
        $processor->setSubmissionId($submission->id);
        $processor->changeTransactionStatus($transaction->id, 'failed');
        $processor->changeSubmissionPaymentStatus('failed');

        do_action('fluentform/log_data', [
            'parent_source_id' => $submission->form_id,
            'source_type'      => 'submission_item',
            'source_id'        => $submission->id,
            'component'        => 'Payment',
            'status'           => 'error',
            'title'            => __('Stripe Payment Failed', 'fluentform'),
            'description'      => __('Stripe reported that the delayed payment did not complete.', 'fluentform'),
        ]);

        $processor->fireFailureHooks($submission, $transaction, $submission->form_id, $session, 'async_payment_failed');
    }

    private function handleCheckoutSessionCompleted($event)
    {
        $data = $event->data->object;

        $metaData = (array)$data->metadata;

        $formId = ArrayHelper::get($metaData, 'form_id');

        $session = CheckoutSession::retrieve($data->id, [
            'expand' => [
                'subscription.latest_invoice.payment_intent',
                'payment_intent'
            ]
        ], $formId);

        if (!$session || is_wp_error($session)) {
            return new \WP_Error('stripe_settlement_retry', 'Unable to retrieve Stripe Checkout session.');
        }

        $submissionId = intval($session->client_reference_id);
        if (!$session || !$submissionId) {
            return;
        }

        if (Helper::getSubmissionMeta($submissionId, 'is_form_action_fired') == 'yes') {
            return;
        }

        // let's get the pending submission
        $submission = Submission::find($submissionId);

        if (!$submission) {
            return;
        }

        $transactionId = ArrayHelper::get($metaData, 'transaction_id');

        if(!$transactionId) {
            return;
        }

        $transaction = Transaction::bySubmission($submission->id)
            ->where('form_id', $submission->form_id)
            ->where('id', $transactionId)
            ->first();

        if(!$transaction) {
            return; // not our transaction or transaction_status already paid
        }

        $returnData = (new StripeProcessor())->processStripeSession($session, $submission, $transaction);
    }

    /*
     *
     */
    public function retrive($eventId, $formId = false)
    {
        $api = new ApiRequest();
        $api::set_secret_key(StripeSettings::getSecretKey($formId));
        return $api::request([], 'events/' . $eventId, 'GET');
    }

    public function verifySignature($payload, $signature, $secret = '')
    {
        // SECURITY (FINDING-19): the signing secret is now supplied by the caller from the
        // fluentform_stripe_webhook_secret option instead of a shared hardcoded whsec_.
        if (!$secret) {
            return false;
        }

        // Extract timestamp and signatures from header
        $timestamp = self::getTimestamp($signature);
        $signatures = self::getSignatures($signature);

        if (-1 === $timestamp) {
            return false;
        }
        if (empty($signatures)) {
            return false;
        }

        $signedPayload = "{$timestamp}.{$payload}";

        if (!function_exists('hash_hmac')) {
            return false;
        }

        // Stripe signs "{timestamp}.{payload}", not the bare payload.
        $expectedSignature = \hash_hmac('sha256', $signedPayload, $secret);

        // Reject events older than 5 minutes to prevent replay attacks
        if (abs(time() - $timestamp) > 300) {
            return false;
        }

        foreach ($signatures as $signature) {
            if ($this->secureCompare($signature, $expectedSignature)) {
                return true;
            }
        }

        return false;
    }

    protected function getTimeStamp($signature)
    {
        $items = \explode(',', $signature);

        foreach ($items as $item) {
            $itemParts = \explode('=', $item, 2);
            if ('t' === $itemParts[0]) {
                if (!\is_numeric($itemParts[1])) {
                    return -1;
                }

                return (int)($itemParts[1]);
            }
        }

        return -1;
    }

    private function getSignatures($header, $scheme = 'v1')
    {
        $signatures = [];
        $items = \explode(',', $header);

        foreach ($items as $item) {
            $itemParts = \explode('=', $item, 2);
            if (\trim($itemParts[0]) === $scheme) {
                $signatures[] = $itemParts[1];
            }
        }

        return $signatures;
    }

    protected function secureCompare($a, $b)
    {
        if (function_exists('hash_equals')) {
            return \hash_equals($a, $b);
        }

        if (\strlen($a) !== \strlen($b)) {
            return false;
        }

        $result = 0;
        for ($i = 0; $i < \strlen($a); ++$i) {
            $result |= \ord($a[$i]) ^ \ord($b[$i]);
        }

        return 0 === $result;
    }

    protected function createSubsTransactionDataFromInvoice($invoice, $subscription, $submission)
    {
        $paymentIntent = false;
        if (empty($invoice->payment_intent)) {
            // was: null; a $0 invoice has no intent, and the return path stores the invoice id, so match on that
            $chargeId = $invoice->id;
        } elseif(!is_object($invoice->payment_intent)) {
            ApiRequest::set_secret_key(StripeSettings::getSecretKey($subscription->form_id));
            $paymentIntent = ApiRequest::request([], 'payment_intents/'.$invoice->payment_intent, 'GET');
            if(is_wp_error($paymentIntent)) {
                $paymentIntent = false;
            }
            $chargeId = $invoice->payment_intent;
        } else {
            $chargeId = $invoice->payment_intent->id;
            $paymentIntent = $invoice->payment_intent;
        }

        $paymentTotal = $invoice->amount_paid;
        if(PaymentHelper::isZeroDecimal($invoice->currency)) {
            $paymentTotal = $paymentTotal * 100;
        }

        $data = [
            'subscription_id' => $subscription->id,
            'form_id' => $subscription->form_id,
            'transaction_hash' => wp_generate_password(32, false),
            'user_id' => $submission->user_id,
            'submission_id' => $submission->id,
            'transaction_type' => 'subscription',
            'payment_method' => 'stripe',
            'card_last_4' => '',
            'card_brand' => '',
            'payer_name' => $invoice->customer_name,
            'payer_email' => $invoice->customer_email,
            'charge_id' => $chargeId,
            'payment_total' => $paymentTotal,
            'status' => 'paid',
            'currency' => strtoupper($invoice->currency),
            'payment_mode' => ($invoice->livemode) ? 'live' : 'test',
            'payment_note' => maybe_serialize($invoice),
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql'),
        ];

        if($paymentIntent && !empty($paymentIntent->charges->data[0]->payment_method_details->card)) {
            $card = $paymentIntent->charges->data[0]->payment_method_details->card;
            $data['card_brand'] = $card->brand;
            $data['card_last_4'] = $card->last4;
        }

        return $data;
    }
}
