<?php

use TEC\Common\Admin\Conditional_Content\Black_Friday;

/**
 * The template for the App Shop page.
 *
 * $main and $products must be defined before loading this file.
 */

// No direct access.
defined( 'ABSPATH' ) || exit;

$all_products = [
	'for-sale'  => [],
	'installed' => [],
];
foreach ( $products as $product ) {
	if ( $product->is_installed ) {
		$all_products['installed'][] = $product;
	} else {
		$all_products['for-sale'][] = $product;
	}
}

use Tribe\Admin\Troubleshooting;
?>

<div id="tribe-app-shop">
	<div class="tribe-notice-wrap">
		<?php
		/**
		 * Trigger the conditional content header notice.
		 *
		 * @since 6.8.2
		 */
		do_action( 'tec_conditional_content_header_notice' );
		tribe( Troubleshooting::class )->admin_notice( 'app-shop' );
		?>
		<div class="wp-header-end"></div>
	</div>

	<div class="tribe-header">
		<div class="content-wrapper">
			<div class="logo-word-mark">
				<img
					src="<?php echo esc_url( tribe_resource_url( 'images/logo/tec-brand.svg', false, null, $main ) ); ?>"
					alt="<?php esc_attr_e( 'The Events Calendar brand logo', 'tribe-common' ); ?>"
				/>
			</div>
		</div>
	</div>

	<div id="tribe-all-solutions" class="tribe-content">
		<img
			class="tribe-events-admin-graphic"
			src="<?php echo esc_url( tribe_resource_url( 'images/header/all-solutions.jpg', false, null, $main ) ); ?>"
			alt="<?php esc_attr_e( 'Shapes and lines for visual interest', 'tribe-common' ); ?>"
		/>
		<div class="content-wrapper">
			<div class="addon-grid">
				<?php foreach ( $all_products as $pr_status => $some_products ) : ?>
					<?php if ( 'for-sale' == $pr_status ) : ?>
						<h2><?php esc_html_e( 'One calendar. Countless ways to make it your own.', 'tribe-common' ); ?></h2>
						<p><?php esc_html_e( 'Calendars, ticketing, and powerful WordPress tools to manage your events from start to finish.', 'tribe-common' ); ?></p>
					<?php else : ?>
						<h2 class="already-installed"><?php esc_html_e( 'Already Installed', 'tribe-common' ); ?></h2>
					<?php endif; ?>

					<?php foreach ( $some_products as $product ) : ?>
						<div class="tribe-addon">
							<div class="headline">
								<img src="<?php echo esc_url( tribe_resource_url( $product->logo, false, null, $main ) ); ?>" alt="<?php esc_attr_e( 'TEC Logo', 'tribe-common' ); ?>" />
								<h3 <?php echo ( 'installed' == $pr_status || $product->free ) ? 'class="has-pill"' : ''; ?>><a href="<?php echo esc_url( $product->link ); ?>" target="_blank"><?php echo esc_html( $product->title ); ?></a></h3>

								<?php if ( 'installed' == $pr_status ) : ?>
									<span class="pill active"><?php esc_html_e( 'Active', 'tribe-common' ); ?></span>
								<?php elseif ( $product->free ) : ?>
									<span class="pill free"><?php esc_html_e( 'FREE', 'tribe-common' ); ?></span>
								<?php endif; ?>

							</div>
							<div class="promo-image">
								<a href="<?php echo esc_url( $product->link ); ?>" target="_blank"><img src="<?php echo esc_url( tribe_resource_url( $product->image, false, null, $main ) ); ?>" /></a>
							</div>

							<div class="description">
								<p><?php echo esc_html( $product->description ); ?></p>
							</div>

							<ul class="features">
								<?php foreach ( $product->features as $feature ) : ?>
									<li>
										<span class="check">
											<svg fill="none" height="12" viewBox="0 0 16 12" width="16" xmlns="http://www.w3.org/2000/svg"><path clip-rule="evenodd" d="m13.7357.374803-8.40784 8.402337-3.06361-3.06158c-.52424-.506-1.357557-.49877-1.872924.01626s-.522608 1.34779-.016275 1.87169l4.008209 4.00559c.52173.5212 1.36747.5212 1.8892 0l9.35244-9.34634c.5064-.5239.4991-1.356665-.0162-1.871692-.5154-.515027-1.3487-.522264-1.873-.016265z" fill="#3d54ff" fill-rule="evenodd"/></svg>
										</span><span class="feature-text">
											<?php echo esc_html( $feature ); ?>
										</span>
									</li>
								<?php endforeach; ?>
							</ul>

							<?php if ( 'installed' == $pr_status ) : ?>
								<a class="button" href="https://evnt.is/1aiz"><?php esc_html_e( 'Manage', 'tribe-common' ); ?></a>
							<?php else : ?>
								<a class="button" href="<?php echo esc_url( $product->link ); ?>"><?php esc_html_e( 'Learn More', 'tribe-common' ); ?></a>
							<?php endif; ?>

						</div>
					<?php endforeach; ?>
				<?php endforeach; ?>
			</div>
		</div>
	</div>

</div>
