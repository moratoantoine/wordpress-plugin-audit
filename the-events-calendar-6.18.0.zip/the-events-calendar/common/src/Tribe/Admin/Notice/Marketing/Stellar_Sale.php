<?php
/**
 * @deprecated 6.3.0
 */

namespace Tribe\Admin\Notice\Marketing;

defined( 'ABSPATH' ) || exit;

_deprecated_file( __FILE__, '6.3.0', 'No Replacement' );

/**
 * Class Stellar_Sale
 *
 * @since 4.14.2
 * @deprecated 6.3.0
 *
 * @package Tribe\Admin\Notice\Marketing
 */
class Stellar_Sale {
	/**
	 * @inheritdoc
	 *
	 * @param string $name      The name of the method.
	 * @param array  $arguments The arguments passed to the method.
	 * @return void
	 */
	public function __call( $name, $arguments ) {
		_deprecated_function( __METHOD__, '6.3.0', 'No replacement.' );
	}

	/**
	 * @inheritdoc
	 *
	 * @param string $name      The name of the method.
	 * @param array  $arguments The arguments passed to the method.
	 * @return void
	 */
	public static function __callStatic( $name, $arguments ) {
		_deprecated_function( __METHOD__, '6.3.0', 'No replacement.' );
	}
}
